"""
Dimensional Cortex - CRASH-PROOF DEBUG VERSION
===============================================
This version catches ALL errors and displays them on screen.
"""

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW, CENTER, BOLD
import traceback
import sys
import os
import logging

# Setup logging FIRST
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("DimensionalCortex")

# Track startup errors
STARTUP_ERRORS = []
TRINITY_AVAILABLE = False
UDAC_AVAILABLE = False
INJECTOR_AVAILABLE = False

# ============================================================================
# SAFE IMPORTS
# ============================================================================
def safe_import(description, import_func):
    """Safely execute an import and track errors."""
    global STARTUP_ERRORS
    try:
        result = import_func()
        logger.info(f"✓ {description}")
        return result
    except Exception as e:
        error = f"{description}: {str(e)}"
        STARTUP_ERRORS.append(error)
        logger.error(f"✗ {error}")
        logger.error(traceback.format_exc())
        return None

# Try importing Trinity modules
try:
    from dimensional_cortex.dimensional_memory_constant_standalone_demo import (
        start_memory_system, stop_memory_system
    )
    from dimensional_cortex.dimensional_processing_system_standalone_demo import (
        CrystalMemorySystem, GovernanceEngine, CrystalLevel
    )
    from dimensional_cortex.dimensional_energy_regulator_mobile import DimensionalEnergyRegulator
    TRINITY_AVAILABLE = True
    logger.info("✓ Trinity modules imported")
except Exception as e:
    STARTUP_ERRORS.append(f"Trinity import: {str(e)}")
    logger.error(f"✗ Trinity import failed: {e}")

# Try importing UDAC modules
try:
    from dimensional_cortex.udac_listener import (
        start_udac_listener,
        get_udac_stats,
        set_event_processor,
        set_injection_processor
    )
    UDAC_AVAILABLE = True
    logger.info("✓ UDAC listener imported")
except Exception as e:
    STARTUP_ERRORS.append(f"UDAC import: {str(e)}")
    logger.error(f"✗ UDAC import failed: {e}")

# Try importing Continuity Injector
try:
    from dimensional_cortex.continuity_injector import (
        ContinuityInjector,
        Platform,
        get_injector
    )
    INJECTOR_AVAILABLE = True
    logger.info("✓ Continuity Injector imported")
except Exception as e:
    STARTUP_ERRORS.append(f"Injector import: {str(e)}")
    logger.error(f"✗ Injector import failed: {e}")


# ============================================================================
# TRINITY MANAGER (Only if imports succeeded)
# ============================================================================
class TrinityManager:
    """Trinity system manager with crash protection."""

    def __init__(self):
        self.memory_governor = None
        self.memory_system = None
        self.crystal_system = None
        self.energy_regulator = None
        self.continuity_injector = None
        self.save_thread = None
        self.merge_thread = None
        self.running = False
        self.start_error = None
        self.conversations_processed = 0
        self.injections_performed = 0

    def start(self):
        if self.running:
            return True
        
        if not TRINITY_AVAILABLE:
            self.start_error = "Trinity modules not available"
            return False

        logger.info("=" * 50)
        logger.info("STARTING TRINITY")
        logger.info("=" * 50)

        try:
            # Memory Layer
            self.memory_governor, self.memory_system, self.save_thread, self.merge_thread = start_memory_system()
            logger.info("✓ Memory layer online")
            
            # Processing Layer
            governance = GovernanceEngine(data_theme="conversation")
            self.crystal_system = CrystalMemorySystem(governance_engine=governance)
            logger.info("✓ Processing layer online")
            
            # Energy Layer
            self.energy_regulator = DimensionalEnergyRegulator(conservation_limit=50.0, decay_rate=0.1)
            logger.info("✓ Energy layer online")
            
            # Continuity Injector
            if INJECTOR_AVAILABLE:
                self.continuity_injector = get_injector()
                self.continuity_injector.set_trinity(self)
                logger.info("✓ Injector connected")
            
            self.running = True
            logger.info("=" * 50)
            logger.info("TRINITY ONLINE")
            logger.info("=" * 50)
            return True

        except Exception as e:
            self.start_error = str(e)
            logger.error(f"Trinity start failed: {e}")
            logger.error(traceback.format_exc())
            return False

    def start_udac_listener(self):
        if not self.running or not UDAC_AVAILABLE:
            return False
        
        try:
            set_event_processor(self.process_capture_event)
            set_injection_processor(self.process_injection_request)
            start_udac_listener(port=7013)
            logger.info("✓ UDAC listener online on port 7013")
            return True
        except Exception as e:
            logger.error(f"UDAC listener failed: {e}")
            return False

    def process_capture_event(self, event_data: dict):
        """Process captured conversation."""
        if not self.running:
            return
        try:
            self.conversations_processed += 1
            # Simplified processing for stability
            text = event_data.get("text", "")
            platform = event_data.get("platform", "Unknown")
            logger.debug(f"Captured from {platform}: {text[:50]}...")
        except Exception as e:
            logger.error(f"Capture error: {e}")

    def process_injection_request(self, message: str, platform: str) -> dict:
        """Process injection request."""
        default = {
            "original_message": message,
            "injected_message": message,
            "injected": False,
            "relevance": 0.0,
            "context_summary": ""
        }
        
        if not self.running or not self.continuity_injector:
            return default
        
        try:
            # For now, just return the message unchanged
            # Full injection logic can be added once basic app works
            return default
        except Exception as e:
            logger.error(f"Injection error: {e}")
            return default

    def stop(self):
        if not self.running:
            return
        
        logger.info("Stopping Trinity...")
        try:
            if self.save_thread and self.merge_thread:
                stop_memory_system(self.save_thread, self.merge_thread)
        except Exception as e:
            logger.error(f"Stop error: {e}")
        
        self.running = False
        logger.info("Trinity stopped")

    def get_stats(self):
        if not self.running:
            return {
                'memory': {'total_nodes': 0},
                'crystals': {'total_crystals': 0},
                'conversations_processed': 0,
                'injections_performed': 0
            }
        
        try:
            return {
                'memory': {'total_nodes': len(self.memory_system.nodes) if self.memory_system else 0},
                'crystals': self.crystal_system.get_memory_stats() if self.crystal_system else {'total_crystals': 0},
                'conversations_processed': self.conversations_processed,
                'injections_performed': self.injections_performed
            }
        except Exception as e:
            logger.error(f"Stats error: {e}")
            return {
                'memory': {'total_nodes': 0},
                'crystals': {'total_crystals': 0},
                'conversations_processed': 0,
                'injections_performed': 0
            }


# Global instance
TRINITY = TrinityManager()


# ============================================================================
# MAIN APP
# ============================================================================
class DimensionalCortexApp(toga.App):
    
    def startup(self):
        """Safe startup with error handling."""
        logger.info("=" * 50)
        logger.info("APP STARTUP")
        logger.info("=" * 50)
        
        try:
            self.main_window = toga.MainWindow(title=self.formal_name)
            self.show_main_screen()
            self.main_window.show()
            logger.info("App startup complete")
        except Exception as e:
            logger.error(f"Startup failed: {e}")
            logger.error(traceback.format_exc())
            raise

    def show_main_screen(self):
        """Show the main diagnostic screen."""
        content = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#1a1a2e'))
        
        # Title
        content.add(toga.Label(
            '⚡ Dimensional Cortex',
            style=Pack(font_size=22, font_weight=BOLD, color='#667eea', padding_bottom=5)
        ))
        content.add(toga.Label(
            'Debug Edition v1.0',
            style=Pack(font_size=11, color='#888888', padding_bottom=15)
        ))
        
        # System info
        info_box = toga.Box(style=Pack(direction=COLUMN, padding=10, background_color='#252542'))
        info_box.add(toga.Label(f'Python: {sys.version.split()[0]}', style=Pack(color='#aaa', font_size=10)))
        info_box.add(toga.Label(f'Platform: {sys.platform}', style=Pack(color='#aaa', font_size=10)))
        content.add(info_box)
        
        # Module status
        content.add(toga.Label('Module Status:', style=Pack(color='#fff', font_weight=BOLD, padding_top=15, padding_bottom=5)))
        
        status_box = toga.Box(style=Pack(direction=COLUMN, padding=10, background_color='#252542'))
        
        trinity_status = "✓ Loaded" if TRINITY_AVAILABLE else "✗ Failed"
        trinity_color = "#10b981" if TRINITY_AVAILABLE else "#ef4444"
        status_box.add(toga.Label(f'Trinity: {trinity_status}', style=Pack(color=trinity_color, font_size=12)))
        
        udac_status = "✓ Loaded" if UDAC_AVAILABLE else "✗ Failed"
        udac_color = "#10b981" if UDAC_AVAILABLE else "#ef4444"
        status_box.add(toga.Label(f'UDAC: {udac_status}', style=Pack(color=udac_color, font_size=12)))
        
        injector_status = "✓ Loaded" if INJECTOR_AVAILABLE else "✗ Failed"
        injector_color = "#10b981" if INJECTOR_AVAILABLE else "#ef4444"
        status_box.add(toga.Label(f'Injector: {injector_status}', style=Pack(color=injector_color, font_size=12)))
        
        content.add(status_box)
        
        # Errors
        if STARTUP_ERRORS:
            content.add(toga.Label('Errors:', style=Pack(color='#ef4444', font_weight=BOLD, padding_top=15, padding_bottom=5)))
            
            error_box = toga.Box(style=Pack(direction=COLUMN, padding=10, background_color='#3d1f1f'))
            for error in STARTUP_ERRORS[:5]:  # Show max 5 errors
                error_text = error[:100] + "..." if len(error) > 100 else error
                error_box.add(toga.Label(error_text, style=Pack(color='#ff6b6b', font_size=9, padding_bottom=3)))
            content.add(error_box)
        
        # Status label for updates
        self.status_label = toga.Label(
            '',
            style=Pack(color='#ffa500', padding_top=15, font_size=11)
        )
        content.add(self.status_label)
        
        # Buttons
        content.add(toga.Box(style=Pack(height=15)))
        
        if TRINITY_AVAILABLE:
            start_btn = toga.Button(
                'START TRINITY',
                on_press=self.start_trinity,
                style=Pack(padding=12, background_color='#6366f1', flex=1)
            )
            content.add(start_btn)
        else:
            content.add(toga.Label(
                'Cannot start - Trinity modules failed to load',
                style=Pack(color='#ef4444', padding=10)
            ))
        
        content.add(toga.Box(style=Pack(height=10)))
        
        # Settings button
        settings_btn = toga.Button(
            'Open Accessibility Settings',
            on_press=self.open_accessibility_settings,
            style=Pack(padding=10, background_color='#333355')
        )
        content.add(settings_btn)
        
        # Wrap in scroll
        scroll = toga.ScrollContainer(horizontal=False, style=Pack(flex=1))
        scroll.content = content
        
        outer = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#1a1a2e'))
        outer.add(scroll)
        
        self.main_window.content = outer

    def start_trinity(self, widget):
        """Start Trinity system."""
        self.status_label.text = "Starting Trinity..."
        self.status_label.style.color = '#ffa500'
        
        try:
            if TRINITY.start():
                if TRINITY.start_udac_listener():
                    self.status_label.text = "✓ Trinity online! UDAC listening."
                    self.status_label.style.color = '#10b981'
                else:
                    self.status_label.text = "✓ Trinity online. UDAC failed."
                    self.status_label.style.color = '#ffa500'
            else:
                self.status_label.text = f"✗ Failed: {TRINITY.start_error}"
                self.status_label.style.color = '#ef4444'
        except Exception as e:
            self.status_label.text = f"✗ Error: {str(e)[:50]}"
            self.status_label.style.color = '#ef4444'
            logger.error(f"Start error: {e}")
            logger.error(traceback.format_exc())

    def open_accessibility_settings(self, widget):
        """Open Android accessibility settings."""
        self.status_label.text = "Opening settings..."
        
        try:
            from java import jclass
            Intent = jclass("android.content.Intent")
            Settings = jclass("android.provider.Settings")
            
            # Get the activity
            from android import PythonActivity
            activity = PythonActivity.mActivity
            
            intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            activity.startActivity(intent)
            
            self.status_label.text = "Settings opened"
            self.status_label.style.color = '#10b981'
        except Exception as e:
            # Try alternative method
            try:
                from jnius import autoclass
                Intent = autoclass('android.content.Intent')
                PythonActivity = autoclass('org.kivy.android.PythonActivity')
                
                intent = Intent("android.settings.ACCESSIBILITY_SETTINGS")
                PythonActivity.mActivity.startActivity(intent)
                
                self.status_label.text = "Settings opened"
                self.status_label.style.color = '#10b981'
            except Exception as e2:
                self.status_label.text = "Go to: Settings → Accessibility → UDAC"
                self.status_label.style.color = '#ffa500'
                logger.error(f"Settings open failed: {e}, {e2}")


def main():
    return DimensionalCortexApp('Dimensional Cortex', 'com.udacapp.udac')


if __name__ == '__main__':
    try:
        main().main_loop()
    except Exception as e:
        logger.error(f"FATAL: {e}")
        logger.error(traceback.format_exc())
        raise
