package org.beeware.android;

public interface IDrawHandler {
    public void handleDraw(android.graphics.Canvas canvas);
}
