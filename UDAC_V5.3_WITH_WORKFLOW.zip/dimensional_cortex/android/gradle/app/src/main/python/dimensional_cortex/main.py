"""
Dimensional Cortex - Backend Only
=================================

This module runs the Python backend services.
The UI is handled by native Android (MainActivity.java).

Services:
- UDAC HTTP Listener (receives events, provides context)
- Trinity Memory System (optional, for advanced context)
"""

import threading
import time
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("DimensionalCortex")

# Global state
_backend_running = False
_udac_thread = None


def start_backend():
    """Start all backend services."""
    global _backend_running, _udac_thread
    
    if _backend_running:
        logger.info("Backend already running")
        return
    
    logger.info("=" * 50)
    logger.info("  DIMENSIONAL CORTEX BACKEND STARTING")
    logger.info("=" * 50)
    
    try:
        # Start UDAC HTTP listener
        from dimensional_cortex.udac_listener import start_udac_listener
        _udac_thread = start_udac_listener(port=7013)
        logger.info("UDAC listener started on port 7013")
        
        _backend_running = True
        logger.info("Backend services online")
        
    except Exception as e:
        logger.error(f"Failed to start backend: {e}")
        import traceback
        traceback.print_exc()


def stop_backend():
    """Stop all backend services."""
    global _backend_running
    
    if not _backend_running:
        return
    
    logger.info("Stopping backend services...")
    
    try:
        from dimensional_cortex.udac_listener import stop_udac_listener
        stop_udac_listener()
    except:
        pass
    
    _backend_running = False
    logger.info("Backend stopped")


def is_backend_running():
    """Check if backend is running."""
    return _backend_running


# Auto-start when module loads (for Android)
def main():
    """Entry point - starts backend and keeps it running."""
    start_backend()
    
    # Keep the thread alive
    try:
        while _backend_running:
            time.sleep(1)
    except KeyboardInterrupt:
        stop_backend()


# Start backend when imported on Android
try:
    # Check if we're on Android
    import android
    logger.info("Running on Android - auto-starting backend")
    start_backend()
except ImportError:
    # Not on Android, don't auto-start
    pass


if __name__ == "__main__":
    main()
