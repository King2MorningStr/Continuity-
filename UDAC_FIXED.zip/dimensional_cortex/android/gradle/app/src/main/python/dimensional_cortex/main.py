"""
Dimensional Cortex - DEBUG VERSION WITH TOGGLES
================================================
Features:
1. All toggles restored (enable/disable, force mode, threshold)
2. Decision log viewer - see WHY injection happens or not
3. Verbose stats display
4. Manual test buttons
5. Aggressive injection mode
"""

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW, CENTER, BOLD
import asyncio
import threading
import time
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger("DimensionalCortex")

# Trinity imports
from dimensional_cortex.dimensional_memory_constant_standalone_demo import (
    start_memory_system, stop_memory_system
)
from dimensional_cortex.dimensional_processing_system_standalone_demo import (
    CrystalMemorySystem, GovernanceEngine, CrystalLevel
)
from dimensional_cortex.dimensional_energy_regulator_mobile import DimensionalEnergyRegulator

# UDAC imports
from dimensional_cortex.udac_listener import (
    start_udac_listener,
    get_udac_stats,
    set_event_processor,
    set_injection_processor
)

# Continuity Injector
from dimensional_cortex.continuity_injector import (
    ContinuityInjector,
    Platform,
    get_injector
)


class TrinityManager:
    """Trinity system manager with full debug support."""

    def __init__(self):
        self.memory_governor = None
        self.memory_system = None
        self.crystal_system = None
        self.energy_regulator = None
        self.continuity_injector = None
        
        self.save_thread = None
        self.merge_thread = None
        self.udac_thread = None
        
        self.running = False
        self._lock = threading.Lock()
        
        self.conversations_processed = 0
        self.crystals_evolved = 0
        self.injections_performed = 0
        
        # Debug tracking
        self.last_capture_text = ""
        self.last_injection_request = ""
        self.last_injection_result = None

    def start(self):
        if self.running:
            return

        logger.info("=" * 60)
        logger.info("TRINITY STARTING - DEBUG MODE")
        logger.info("=" * 60)

        try:
            # Memory Layer
            self.memory_governor, self.memory_system, self.save_thread, self.merge_thread = start_memory_system()
            logger.info("✓ Memory layer online")
            
            # Processing Layer
            governance = GovernanceEngine(data_theme="conversation")
            self.crystal_system = CrystalMemorySystem(governance_engine=governance)
            logger.info("✓ Processing layer online")
            
            # Energy Layer
            self.energy_regulator = DimensionalEnergyRegulator(conservation_limit=50.0, decay_rate=0.1)
            logger.info("✓ Energy layer online")
            
            # Continuity Injector
            self.continuity_injector = get_injector()
            self.continuity_injector.set_trinity(self)
            logger.info("✓ Injector connected (threshold: %.2f)", self.continuity_injector.min_relevance)
            
            self.running = True
            logger.info("=" * 60)
            logger.info("TRINITY ONLINE")
            logger.info("=" * 60)

        except Exception as e:
            logger.error("Start failed: %s", e, exc_info=True)
            self.stop()
            raise

    def start_udac_listener(self):
        if not self.running:
            return
        
        logger.info("Registering UDAC processors...")
        set_event_processor(self.process_capture_event)
        set_injection_processor(self.process_injection_request)
        
        self.udac_thread = start_udac_listener(port=7013)
        logger.info("✓ UDAC listener online on port 7013")

    def process_capture_event(self, event_data: dict):
        """Process captured conversation."""
        if not self.running:
            return

        with self._lock:
            try:
                platform = event_data.get("platform", "Unknown")
                text = event_data.get("text", "")
                timestamp = event_data.get("timestamp", time.time() * 1000)

                if not text or len(text) < 5:
                    return

                self.last_capture_text = f"{platform}: {text[:100]}"
                logger.info("CAPTURE: %s - %s", platform, text[:60])

                # Memory Layer
                self.memory_governor.ingest_data({
                    "text": text,
                    "source_doc": platform,
                    "timestamp": timestamp,
                })

                # Processing Layer
                crystal = self.crystal_system.use_crystal(
                    concept=f"PLATFORM_{platform}",
                    data={"text": text, "timestamp": timestamp}
                )

                if crystal:
                    content_hash = str(hash(text[:100]))[:8]
                    crystal.add_facet(
                        role=f"conv_{content_hash}", 
                        content=text[:500], 
                        confidence=0.7
                    )

                self.energy_regulator.step(dt=0.5)
                self.crystal_system.decay_all()
                self.conversations_processed += 1

            except Exception as e:
                logger.error("Capture error: %s", e, exc_info=True)

    def process_injection_request(self, message: str, platform: str) -> dict:
        """Process injection request - returns complete result."""
        logger.info("=" * 50)
        logger.info("INJECTION REQUEST")
        logger.info("  Message: %s", message[:60] if message else "EMPTY")
        logger.info("  Platform: %s", platform)
        logger.info("=" * 50)
        
        self.last_injection_request = f"{platform}: {message[:60]}"
        
        default_response = {
            "original_message": message,
            "injected_message": message,
            "context_block": "",
            "injected": False,
            "relevance": 0.0,
            "context_summary": "",
        }
        
        if not self.running:
            logger.warning("Trinity not running!")
            return default_response
            
        if not self.continuity_injector:
            logger.warning("Injector not available!")
            return default_response

        try:
            platform_map = {
                "chatgpt": Platform.CHATGPT,
                "claude": Platform.CLAUDE,
                "perplexity": Platform.PERPLEXITY,
                "gemini": Platform.GEMINI,
                "copilot": Platform.CHATGPT,
                "poe": Platform.CHATGPT,
                "characterai": Platform.CHATGPT,
                "pi": Platform.CHATGPT,
                "replika": Platform.CHATGPT,
            }
            platform_enum = platform_map.get(platform.lower(), Platform.CHATGPT)
            
            result = self.continuity_injector.inject(message, platform_enum)
            
            self.last_injection_result = result

            if result.was_injected:
                with self._lock:
                    self.injections_performed += 1

            response = {
                "original_message": result.original_message,
                "injected_message": result.injected_message,
                "context_block": result.context_block,
                "injected": result.was_injected,
                "relevance": result.relevance_score,
                "context_summary": result.context_summary,
            }
            
            logger.info("Response: injected=%s, relevance=%.2f", 
                       response["injected"], response["relevance"])
            
            return response

        except Exception as e:
            logger.error("Injection error: %s", e, exc_info=True)
            return default_response

    def stop(self):
        if not self.running:
            return
        
        logger.info("Trinity stopping...")
        try:
            if self.save_thread and self.merge_thread:
                stop_memory_system(self.save_thread, self.merge_thread)
        except Exception as e:
            logger.error("Stop error: %s", e)
        
        self.running = False

    def get_stats(self) -> dict:
        if not self.running:
            return {
                'memory': {'total_nodes': 0},
                'crystals': {'total_crystals': 0, 'level_distribution': {}},
                'conversations_processed': 0,
                'injections_performed': 0,
            }

        memory_stats = {
            'total_nodes': len(self.memory_system.nodes) if self.memory_system else 0
        }
        
        crystal_stats = (
            self.crystal_system.get_memory_stats() 
            if self.crystal_system 
            else {'total_crystals': 0, 'level_distribution': {}}
        )
        
        injector_stats = (
            self.continuity_injector.get_stats() 
            if self.continuity_injector 
            else {}
        )
        
        udac_stats = get_udac_stats()

        return {
            'memory': memory_stats,
            'crystals': crystal_stats,
            'conversations_processed': self.conversations_processed,
            'injections_performed': self.injections_performed,
            'injector': injector_stats,
            'udac': udac_stats,
            'last_capture': self.last_capture_text,
            'last_injection_request': self.last_injection_request,
        }


# Global instance
TRINITY = TrinityManager()


class DimensionalCortexApp(toga.App):
    def startup(self):
        self.main_window = toga.MainWindow(title=self.formal_name)
        self.on_exit = self.cleanup
        
        self.show_injections = True  # Show by default for debugging
        
        self.create_onboarding_screen()
        self.main_window.content = self.onboarding_box
        self.main_window.show()

    def cleanup(self, app):
        TRINITY.stop()
        return True

    def create_onboarding_screen(self):
        self.onboarding_box = toga.Box(style=Pack(direction=COLUMN, padding=20, alignment=CENTER, background_color='#0f0c29'))

        title = toga.Label('⚡ DIMENSIONAL CORTEX', style=Pack(padding_bottom=10, font_size=24, color='#667eea', font_weight=BOLD))
        tagline = toga.Label('Universal AI Continuity Engine', style=Pack(padding_bottom=10, font_size=14, color='#a0a0a0'))
        version = toga.Label('DEBUG MODE - Aggressive Injection', style=Pack(padding_bottom=20, font_size=12, color='#ffa500', font_weight=BOLD))
        
        self.onboarding_box.add(title)
        self.onboarding_box.add(tagline)
        self.onboarding_box.add(version)

        features = [
            '✓ Monitors ChatGPT, Claude, Perplexity, Gemini + more',
            '✓ Captures conversations → builds context',
            '✓ Injects continuity into your messages',
            '✓ Decision log shows WHY injection happens',
            '✓ All toggles accessible in Settings'
        ]

        feature_box = toga.Box(style=Pack(direction=COLUMN, padding=10, background_color='#302b63', flex=1))
        for f in features:
            feature_box.add(toga.Label(f, style=Pack(padding=5, color='#e0e0e0')))
        self.onboarding_box.add(feature_box)

        self.onboarding_box.add(toga.Box(style=Pack(height=10)))
        
        warning = toga.Label('⚠️ Enable Accessibility Service in Settings', style=Pack(color='#ff6b6b', padding=10))
        self.onboarding_box.add(warning)

        start_btn = toga.Button('START SYSTEM', on_press=self.start_system, style=Pack(padding=15, background_color='#667eea', color='white', font_weight=BOLD))
        self.onboarding_box.add(start_btn)

    def create_dashboard_screen(self):
        self.dashboard_box = toga.Box(style=Pack(direction=COLUMN, padding=10, background_color='#0f0c29'))

        # Header
        header = toga.Box(style=Pack(direction=ROW, padding_bottom=10))
        header.add(toga.Label('⚡ Dimensional Cortex', style=Pack(font_size=16, font_weight=BOLD, color='#667eea', flex=1)))
        self.status_badge = toga.Label('● ONLINE', style=Pack(color='#10a37f', font_weight=BOLD))
        header.add(self.status_badge)
        self.dashboard_box.add(header)

        # Stats Row 1
        row1 = toga.Box(style=Pack(direction=ROW, padding_bottom=6))
        self.memories_card = self.create_stat_card('MEMORIES', '0', 'nodes')
        self.crystals_card = self.create_stat_card('CRYSTALS', '0', 'active')
        row1.add(self.memories_card)
        row1.add(self.crystals_card)
        self.dashboard_box.add(row1)

        # Stats Row 2
        row2 = toga.Box(style=Pack(direction=ROW, padding_bottom=6))
        self.captured_card = self.create_stat_card('CAPTURED', '0', 'convos')
        self.injected_card = self.create_stat_card('INJECTED', '0', 'contexts')
        row2.add(self.captured_card)
        row2.add(self.injected_card)
        self.dashboard_box.add(row2)

        # Last Activity
        activity_box = toga.Box(style=Pack(direction=COLUMN, padding=8, background_color='#302b63', padding_bottom=6))
        activity_box.add(toga.Label('Last Capture', style=Pack(font_weight=BOLD, color='#e0e0e0', font_size=11)))
        self.activity_label = toga.Label('Waiting for AI conversations...', style=Pack(color='#a0a0a0', font_size=10))
        activity_box.add(self.activity_label)
        self.dashboard_box.add(activity_box)

        # Injection Status Box
        injection_box = toga.Box(style=Pack(direction=COLUMN, padding=8, background_color='#1a1a2e', padding_bottom=6))
        
        inj_header = toga.Box(style=Pack(direction=ROW))
        inj_header.add(toga.Label('Injection Status', style=Pack(font_weight=BOLD, color='#e0e0e0', font_size=11, flex=1)))
        self.view_toggle_btn = toga.Button('👁', on_press=self.toggle_view, style=Pack(padding=3))
        inj_header.add(self.view_toggle_btn)
        injection_box.add(inj_header)
        
        self.injection_status = toga.Label('Enabled | Threshold: 5%', style=Pack(color='#10a37f', font_size=10, padding_top=3))
        injection_box.add(self.injection_status)
        
        self.injection_detail = toga.Label('', style=Pack(color='#a0a0a0', font_size=9, padding_top=3))
        injection_box.add(self.injection_detail)
        
        self.dashboard_box.add(injection_box)

        # Navigation
        nav = toga.Box(style=Pack(direction=ROW, padding_top=8))
        nav.add(toga.Button('⚙️ Settings', on_press=self.go_to_settings, style=Pack(flex=1, padding=3)))
        nav.add(toga.Button('📜 Decisions', on_press=self.go_to_decisions, style=Pack(flex=1, padding=3)))
        nav.add(toga.Button('🧪 Test', on_press=self.run_test, style=Pack(flex=1, padding=3)))
        self.dashboard_box.add(nav)

        self.add_background_task(self.refresh_stats_loop)

    def create_stat_card(self, title: str, value: str, subtext: str) -> toga.Box:
        card = toga.Box(style=Pack(direction=COLUMN, padding=8, background_color='#1f1d2e', flex=1, padding_left=4, padding_right=4))
        card.add(toga.Label(title, style=Pack(font_size=9, color='#a0a0a0')))
        v_label = toga.Label(value, style=Pack(font_size=18, font_weight=BOLD, color='#e0e0e0', padding_top=2, padding_bottom=2))
        s_label = toga.Label(subtext, style=Pack(font_size=9, color='#a0a0a0'))
        card.add(v_label)
        card.add(s_label)
        card.value_label = v_label
        card.subtext_label = s_label
        return card

    def create_settings_screen(self):
        self.settings_box = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#0f0c29'))
        
        # Header
        header = toga.Box(style=Pack(direction=ROW, padding_bottom=15))
        header.add(toga.Button('← Back', on_press=self.go_to_dashboard, style=Pack(padding=5)))
        header.add(toga.Label('⚙️ Settings', style=Pack(font_size=18, font_weight=BOLD, color='#667eea', padding_left=10)))
        self.settings_box.add(header)

        # === INJECTION TOGGLES ===
        self.settings_box.add(toga.Label('INJECTION CONTROLS', style=Pack(font_weight=BOLD, color='#667eea', padding_bottom=8)))
        
        # Enable/Disable
        injection_enabled = True
        if TRINITY.continuity_injector:
            injection_enabled = TRINITY.continuity_injector.enabled
        self.injection_switch = toga.Switch(
            'Enable Injection', 
            value=injection_enabled,
            on_change=self.toggle_injection
        )
        self.settings_box.add(self.injection_switch)
        
        # Force Mode
        force_enabled = False
        if TRINITY.continuity_injector:
            force_enabled = TRINITY.continuity_injector.force_injection
        self.force_switch = toga.Switch(
            'Force Injection (ignore threshold)',
            value=force_enabled,
            on_change=self.toggle_force
        )
        self.settings_box.add(self.force_switch)
        
        self.settings_box.add(toga.Box(style=Pack(height=15)))
        
        # Threshold
        self.settings_box.add(toga.Label('Relevance Threshold', style=Pack(color='#e0e0e0', padding_bottom=5)))
        
        threshold_row = toga.Box(style=Pack(direction=ROW, padding_bottom=10))
        
        current_threshold = 0.05
        if TRINITY.continuity_injector:
            current_threshold = TRINITY.continuity_injector.min_relevance
        
        self.threshold_label = toga.Label(
            f'{current_threshold:.0%}',
            style=Pack(color='#667eea', font_weight=BOLD, padding_right=10, width=50)
        )
        threshold_row.add(self.threshold_label)
        
        threshold_row.add(toga.Button('−', on_press=self.decrease_threshold, style=Pack(padding=8, width=50)))
        threshold_row.add(toga.Button('+', on_press=self.increase_threshold, style=Pack(padding=8, width=50)))
        
        self.settings_box.add(threshold_row)
        
        self.settings_box.add(toga.Label('Lower = more injections\nHigher = only strong matches', style=Pack(color='#a0a0a0', font_size=10)))

        self.settings_box.add(toga.Box(style=Pack(height=20)))

        # === DEBUG TOGGLES ===
        self.settings_box.add(toga.Label('DEBUG OPTIONS', style=Pack(font_weight=BOLD, color='#667eea', padding_bottom=8)))
        
        debug_enabled = True
        if TRINITY.continuity_injector:
            debug_enabled = TRINITY.continuity_injector.debug_mode
        self.debug_switch = toga.Switch(
            'Debug Mode (verbose logging)',
            value=debug_enabled,
            on_change=self.toggle_debug
        )
        self.settings_box.add(self.debug_switch)

        self.settings_box.add(toga.Box(style=Pack(height=20)))

        # Clear buttons
        self.settings_box.add(toga.Label('DATA MANAGEMENT', style=Pack(font_weight=BOLD, color='#667eea', padding_bottom=8)))
        
        clear_row = toga.Box(style=Pack(direction=ROW, padding_bottom=10))
        clear_row.add(toga.Button('Clear Decision Log', on_press=self.clear_decisions, style=Pack(flex=1, padding=8)))
        self.settings_box.add(clear_row)
        
        clear_row2 = toga.Box(style=Pack(direction=ROW))
        clear_row2.add(toga.Button('Clear Injection History', on_press=self.clear_history, style=Pack(flex=1, padding=8)))
        self.settings_box.add(clear_row2)

    def create_decisions_screen(self):
        """Screen showing injection decision log."""
        self.decisions_box = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#0f0c29'))
        
        # Header
        header = toga.Box(style=Pack(direction=ROW, padding_bottom=10))
        header.add(toga.Button('← Back', on_press=self.go_to_dashboard, style=Pack(padding=5)))
        header.add(toga.Label('📜 Injection Decisions', style=Pack(font_size=16, font_weight=BOLD, color='#667eea', padding_left=10, flex=1)))
        header.add(toga.Button('🔄', on_press=self.refresh_decisions, style=Pack(padding=5)))
        self.decisions_box.add(header)
        
        # Legend
        legend = toga.Box(style=Pack(direction=ROW, padding_bottom=10))
        legend.add(toga.Label('✅ Injected', style=Pack(color='#10a37f', font_size=10, padding_right=10)))
        legend.add(toga.Label('⏭️ Skipped', style=Pack(color='#ffa500', font_size=10, padding_right=10)))
        legend.add(toga.Label('❌ Error', style=Pack(color='#ff6b6b', font_size=10)))
        self.decisions_box.add(legend)
        
        # Scroll container for decisions
        scroll = toga.ScrollContainer(horizontal=False, style=Pack(flex=1))
        self.decisions_content = toga.Box(style=Pack(direction=COLUMN))
        scroll.content = self.decisions_content
        self.decisions_box.add(scroll)
        
        self.populate_decisions()

    def populate_decisions(self):
        """Populate decision log."""
        # Clear existing
        while len(self.decisions_content.children) > 0:
            self.decisions_content.remove(self.decisions_content.children[0])
        
        if not TRINITY.continuity_injector:
            self.decisions_content.add(toga.Label('Injector not initialized', style=Pack(color='#a0a0a0', padding=10)))
            return
        
        decisions = TRINITY.continuity_injector.get_decision_log(30)
        
        if not decisions:
            self.decisions_content.add(toga.Label(
                'No decisions yet.\n\nUse an AI chat app (ChatGPT, Claude, etc.)\nto trigger injection attempts.\n\nOr tap "Test" on the dashboard.',
                style=Pack(color='#a0a0a0', padding=10)
            ))
            return
        
        for d in reversed(decisions):  # Most recent first
            card = toga.Box(style=Pack(direction=COLUMN, padding=8, background_color='#1f1d2e', padding_bottom=8))
            
            # Status icon and time
            if d["decision"] == "INJECTED":
                status_icon = "✅"
                status_color = "#10a37f"
            elif d["decision"] == "SKIPPED":
                status_icon = "⏭️"
                status_color = "#ffa500"
            else:
                status_icon = "❌"
                status_color = "#ff6b6b"
            
            header_row = toga.Box(style=Pack(direction=ROW))
            header_row.add(toga.Label(f'{status_icon} {d["time"]}', style=Pack(color=status_color, font_weight=BOLD, flex=1)))
            header_row.add(toga.Label(d["platform"], style=Pack(color='#667eea', font_size=10)))
            card.add(header_row)
            
            # Message
            card.add(toga.Label(f'"{d["message"]}"', style=Pack(color='#e0e0e0', font_size=10, padding_top=3)))
            
            # Reason
            card.add(toga.Label(d["reason"], style=Pack(color='#a0a0a0', font_size=9, padding_top=2)))
            
            # Stats
            trinity_status = "✓" if d["trinity_ok"] else "✗"
            stats_text = f'Rel: {d["relevance"]} | Matches: {d["matches"]} | Trinity: {trinity_status}'
            card.add(toga.Label(stats_text, style=Pack(color='#666', font_size=9, padding_top=2)))
            
            self.decisions_content.add(card)

    def refresh_decisions(self, widget):
        """Refresh decision log."""
        self.populate_decisions()

    # === HANDLERS ===

    def start_system(self, widget):
        try:
            TRINITY.start()
            TRINITY.start_udac_listener()
            self.create_dashboard_screen()
            self.main_window.content = self.dashboard_box
        except Exception as e:
            logger.error("Start failed: %s", e, exc_info=True)

    def go_to_dashboard(self, widget):
        if not hasattr(self, 'dashboard_box'):
            self.create_dashboard_screen()
        self.main_window.content = self.dashboard_box

    def go_to_settings(self, widget):
        self.create_settings_screen()
        self.main_window.content = self.settings_box

    def go_to_decisions(self, widget):
        self.create_decisions_screen()
        self.main_window.content = self.decisions_box

    def toggle_injection(self, widget):
        if TRINITY.continuity_injector:
            TRINITY.continuity_injector.configure(enabled=widget.value)
            logger.info("Injection %s", "enabled" if widget.value else "disabled")

    def toggle_force(self, widget):
        if TRINITY.continuity_injector:
            TRINITY.continuity_injector.configure(force_injection=widget.value)
            logger.info("Force injection %s", "enabled" if widget.value else "disabled")

    def toggle_debug(self, widget):
        if TRINITY.continuity_injector:
            TRINITY.continuity_injector.configure(debug_mode=widget.value)

    def decrease_threshold(self, widget):
        if TRINITY.continuity_injector:
            new_val = max(0.0, TRINITY.continuity_injector.min_relevance - 0.05)
            TRINITY.continuity_injector.configure(min_relevance=new_val)
            self.threshold_label.text = f'{new_val:.0%}'
            logger.info("Threshold decreased to %.0f%%", new_val * 100)

    def increase_threshold(self, widget):
        if TRINITY.continuity_injector:
            new_val = min(1.0, TRINITY.continuity_injector.min_relevance + 0.05)
            TRINITY.continuity_injector.configure(min_relevance=new_val)
            self.threshold_label.text = f'{new_val:.0%}'
            logger.info("Threshold increased to %.0f%%", new_val * 100)

    def clear_decisions(self, widget):
        if TRINITY.continuity_injector:
            TRINITY.continuity_injector.decision_log.clear()
            logger.info("Decision log cleared")
            # Refresh if on decisions screen
            if hasattr(self, 'decisions_content'):
                self.populate_decisions()

    def clear_history(self, widget):
        if TRINITY.continuity_injector:
            TRINITY.continuity_injector.clear_history()
            logger.info("Injection history cleared")

    def toggle_view(self, widget):
        self.show_injections = not self.show_injections

    def run_test(self, widget):
        """Manual test of injection pipeline."""
        logger.info("=" * 50)
        logger.info("MANUAL TEST TRIGGERED")
        logger.info("=" * 50)
        
        # Seed test data
        test_convos = [
            ("ChatGPT", "Python best practices include using virtual environments, following PEP8, and writing docstrings"),
            ("ChatGPT", "Design patterns like Singleton and Factory help organize code"),
            ("Claude", "Dimensional processing uses crystal structures for data organization"),
        ]
        
        for platform, text in test_convos:
            TRINITY.process_capture_event({
                "platform": platform,
                "text": text,
                "timestamp": time.time() * 1000
            })
        
        logger.info("Seeded %d test conversations", len(test_convos))
        
        # Small delay for processing
        time.sleep(0.5)
        
        # Test injection
        result = TRINITY.process_injection_request(
            "What were those Python tips?",
            "ChatGPT"
        )
        
        # Update UI
        if result.get("injected"):
            self.injection_detail.text = f"✅ TEST PASSED!\n{result.get('context_summary', '')}"
            self.injection_detail.style.color = '#10a37f'
        else:
            self.injection_detail.text = f"⚠️ No injection (relevance: {result.get('relevance', 0):.0%})\nCheck Decisions log for details"
            self.injection_detail.style.color = '#ffa500'

    async def refresh_stats_loop(self, app):
        while TRINITY.running:
            try:
                stats = TRINITY.get_stats()

                if hasattr(self, 'memories_card'):
                    self.memories_card.value_label.text = str(stats['memory']['total_nodes'])

                    total_crystals = stats['crystals'].get('total_crystals', 0)
                    self.crystals_card.value_label.text = str(total_crystals)

                    self.captured_card.value_label.text = str(stats['conversations_processed'])
                    self.injected_card.value_label.text = str(stats['injections_performed'])

                    # Last capture
                    last_capture = stats.get('last_capture', '')
                    if last_capture:
                        self.activity_label.text = last_capture[:80] + ('...' if len(last_capture) > 80 else '')
                    
                    # Injection status
                    injector = stats.get('injector', {})
                    if injector.get('enabled', True):
                        threshold = injector.get('min_relevance_threshold', 0.05)
                        force = injector.get('force_injection', False)
                        status_parts = [f"Enabled | Threshold: {threshold:.0%}"]
                        if force:
                            status_parts.append("| FORCE ON")
                        self.injection_status.text = ' '.join(status_parts)
                        self.injection_status.style.color = '#10a37f'
                    else:
                        self.injection_status.text = "DISABLED"
                        self.injection_status.style.color = '#ff6b6b'

                    # Show last injection if toggle is on
                    if self.show_injections and TRINITY.last_injection_result:
                        result = TRINITY.last_injection_result
                        if result.was_injected:
                            preview = result.context_block[:100].replace('\n', ' ')
                            self.injection_detail.text = f"Last: {preview}..."
                        else:
                            self.injection_detail.text = f"Last request: no injection (rel: {result.relevance_score:.0%})"

            except Exception as e:
                logger.error("Stats refresh error: %s", e)

            await asyncio.sleep(2)


def main():
    return DimensionalCortexApp('Dimensional Cortex', 'com.dimensionalcortex.dimensional_cortex')


if __name__ == '__main__':
    main().main_loop()
