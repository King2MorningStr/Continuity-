package com.udacapp.udac;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.system.Os;
import android.system.ErrnoException;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.chaquo.python.Kwarg;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.util.Iterator;
import java.util.List;

import com.udacapp.udac.R;

/**
 * Main entry Activity for the UDAC Android app.
 * 
 * This Activity:
 *  - Applies the app theme.
 *  - Creates a simple root LinearLayout.
 *  - Starts (or reuses) the Chaquopy Python runtime.
 *  - Passes any ENVIRON and ARGV data from the launching Intent.
 *  - Runs the Python main module specified by R.string.main_module.
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    // Exposed in case other components (or Python) need a reference.
    public static MainActivity singletonThis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate() start");

        // Switch from splash theme to the main app theme.
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);

        // Simple root layout; actual UI is driven from Python.
        LinearLayout layout = new LinearLayout(this);
        setContentView(layout);

        singletonThis = this;

        Intent intent = getIntent();

        // Apply environment variables from the launching Intent, if present.
        String environStr = intent.getStringExtra("org.beeware.ENVIRON");
        if (environStr != null) {
            try {
                JSONObject environJson = new JSONObject(environStr);
                Iterator<String> it = environJson.keys();
                while (it.hasNext()) {
                    String key = it.next();
                    String value = environJson.getString(key);
                    Os.setenv(key, value, true);
                }
            } catch (JSONException e) {
                throw new RuntimeException(e);
            } catch (ErrnoException e) {
                throw new RuntimeException(e);
            }
        }

        // Start or reuse the embedded Python runtime.
        Python py;
        if (Python.isStarted()) {
            Log.d(TAG, "Python already started");
            py = Python.getInstance();
        } else {
            Log.d(TAG, "Starting Python");
            AndroidPlatform platform = new AndroidPlatform(this);
            platform.redirectStdioToLogcat();
            Python.start(platform);
            py = Python.getInstance();

            // Populate sys.argv from the launching Intent, if present.
            String argvStr = intent.getStringExtra("org.beeware.ARGV");
            if (argvStr != null) {
                try {
                    JSONArray argvJson = new JSONArray(argvStr);
                    List<PyObject> sysArgv =
                        py.getModule("sys").get("argv").asList();
                    for (int i = 0; i < argvJson.length(); i++) {
                        sysArgv.add(PyObject.fromJava(argvJson.getString(i)));
                    }
                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        // Run the configured main Python module.
        Log.d(TAG, "Running main module " + getString(R.string.main_module));
        py.getModule("runpy").callAttr(
            "run_module",
            getString(R.string.main_module),
            new Kwarg("run_name", "__main__"),
            new Kwarg("alter_sys", true)
        );

        Log.d(TAG, "onCreate() complete");
    }

    @Override
    protected void onStart() {
        Log.d(TAG, "onStart() start");
        super.onStart();
        Log.d(TAG, "onStart() complete");
    }

    @Override
    protected void onResume() {
        Log.d(TAG, "onResume() start");
        super.onResume();
        Log.d(TAG, "onResume() complete");
    }

    @Override
    protected void onPause() {
        Log.d(TAG, "onPause() start");
        super.onPause();
        Log.d(TAG, "onPause() complete");
    }

    @Override
    protected void onStop() {
        Log.d(TAG, "onStop() start");
        super.onStop();
        Log.d(TAG, "onStop() complete");
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy() start");
        super.onDestroy();
        Log.d(TAG, "onDestroy() complete");
    }

    @Override
    protected void onRestart() {
        Log.d(TAG, "onRestart() start");
        super.onRestart();
        Log.d(TAG, "onRestart() complete");
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        Log.d(TAG, "onConfigurationChanged() start");
        super.onConfigurationChanged(newConfig);
        Log.d(TAG, "onConfigurationChanged() complete");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "onActivityResult() start");
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(TAG, "onActivityResult() complete");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        Log.d(TAG, "onRequestPermissionsResult() start");
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.d(TAG, "onRequestPermissionsResult() complete");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // No custom menu; fall back to default behavior.
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // No custom handling; fall back to default behavior.
        return super.onOptionsItemSelected(item);
    }
}
