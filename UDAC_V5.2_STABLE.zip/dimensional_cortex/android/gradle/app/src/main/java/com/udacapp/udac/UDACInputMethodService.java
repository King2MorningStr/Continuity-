package com.udacapp.udac;

import android.inputmethodservice.InputMethodService;
import android.inputmethodservice.Keyboard;
import android.inputmethodservice.KeyboardView;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

import org.json.JSONObject;

/**
 * UDAC Ghost Input Method Service
 * ================================
 * 
 * An invisible IME that injects continuity context into AI chat messages.
 * 
 * Features:
 * - Invisible injection (no visible UI unless toggled)
 * - Configurable injection threshold
 * - Force injection for debugging
 * - Auto-switches back to user's preferred keyboard
 */
public class UDACInputMethodService extends InputMethodService {

    private static final String TAG = "UDAC_IME";
    private static final String CONTEXT_ENDPOINT = "http://127.0.0.1:7013/udac/context";
    
    private ExecutorService executor;
    
    // ════════════════════════════════════════════════════════════════
    // STATIC INJECTION QUEUE (Set by AccessibilityService)
    // ════════════════════════════════════════════════════════════════
    
    private static volatile String pendingUserMessage = null;
    private static volatile String pendingPlatform = null;
    private static volatile boolean injectionScheduled = false;
    private static volatile boolean forceInjection = false;
    
    // Settings (controlled via Python backend)
    private static volatile boolean injectionEnabled = true;
    private static volatile boolean invisibleMode = true;
    private static volatile float injectionThreshold = 0.5f; // 0.0 - 1.0, relevance threshold
    
    // Stats
    private static int totalInjections = 0;
    private static int skippedInjections = 0;
    
    /**
     * Schedule an injection. Called by AccessibilityService when Send is detected.
     */
    public static void scheduleInjection(String userMessage, String platform) {
        pendingUserMessage = userMessage;
        pendingPlatform = platform;
        injectionScheduled = true;
        Log.i(TAG, "📋 Injection scheduled for " + platform);
    }
    
    /**
     * Force an injection regardless of threshold (for debugging)
     */
    public static void forceNextInjection() {
        forceInjection = true;
        Log.i(TAG, "🔧 Force injection enabled for next message");
    }
    
    /**
     * Update injection settings
     */
    public static void updateSettings(boolean enabled, boolean invisible, float threshold) {
        injectionEnabled = enabled;
        invisibleMode = invisible;
        injectionThreshold = Math.max(0.0f, Math.min(1.0f, threshold));
        Log.i(TAG, String.format("⚙️ Settings updated: enabled=%b, invisible=%b, threshold=%.2f",
                enabled, invisible, threshold));
    }
    
    /**
     * Get current stats
     */
    public static JSONObject getStats() {
        try {
            JSONObject stats = new JSONObject();
            stats.put("total_injections", totalInjections);
            stats.put("skipped_injections", skippedInjections);
            stats.put("injection_enabled", injectionEnabled);
            stats.put("invisible_mode", invisibleMode);
            stats.put("threshold", injectionThreshold);
            stats.put("pending", injectionScheduled);
            return stats;
        } catch (Exception e) {
            return new JSONObject();
        }
    }
    
    // ════════════════════════════════════════════════════════════════
    // LIFECYCLE
    // ════════════════════════════════════════════════════════════════

    @Override
    public void onCreate() {
        super.onCreate();
        executor = Executors.newSingleThreadExecutor();
        Log.i(TAG, "════════════════════════════════════════");
        Log.i(TAG, "  UDAC GHOST IME CREATED");
        Log.i(TAG, "  Invisible Mode: " + invisibleMode);
        Log.i(TAG, "════════════════════════════════════════");
    }

    @Override
    public View onCreateInputView() {
        // Return minimal/invisible view
        if (invisibleMode) {
            // Completely invisible - just a 1px transparent view
            View invisible = new View(this);
            invisible.setMinimumHeight(1);
            invisible.setMinimumWidth(1);
            invisible.setBackgroundColor(0x00000000); // Transparent
            return invisible;
        } else {
            // Debug mode - show a small indicator
            View debugView = new View(this);
            debugView.setMinimumHeight(50);
            debugView.setBackgroundColor(0xFF667eea); // Purple indicator
            return debugView;
        }
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        
        Log.d(TAG, "onStartInputView - checking for pending injection");
        
        if (injectionScheduled && injectionEnabled) {
            performInjection();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (executor != null) {
            executor.shutdown();
        }
        Log.i(TAG, "════════════════════════════════════════");
        Log.i(TAG, "  UDAC GHOST IME DESTROYED");
        Log.i(TAG, "  Total Injections: " + totalInjections);
        Log.i(TAG, "  Skipped: " + skippedInjections);
        Log.i(TAG, "════════════════════════════════════════");
    }

    // ════════════════════════════════════════════════════════════════
    // INJECTION LOGIC
    // ════════════════════════════════════════════════════════════════

    private void performInjection() {
        if (!injectionScheduled) return;
        
        final String userMessage = pendingUserMessage;
        final String platform = pendingPlatform;
        final boolean forced = forceInjection;
        
        // Reset flags
        injectionScheduled = false;
        forceInjection = false;
        pendingUserMessage = null;
        pendingPlatform = null;
        
        if (userMessage == null || userMessage.trim().isEmpty()) {
            Log.d(TAG, "Empty message, skipping injection");
            return;
        }
        
        Log.i(TAG, "════════════════════════════════════════");
        Log.i(TAG, "  PERFORMING INJECTION");
        Log.i(TAG, "  Platform: " + platform);
        Log.i(TAG, "  Message: " + truncate(userMessage, 40));
        Log.i(TAG, "  Forced: " + forced);
        Log.i(TAG, "════════════════════════════════════════");
        
        // Fetch context from Python backend
        executor.execute(() -> {
            String context = fetchContext(userMessage, platform, forced);
            
            if (context != null && !context.isEmpty()) {
                // Inject on main thread
                runOnMainThread(() -> injectText(context, userMessage));
            } else {
                Log.d(TAG, "No context to inject (below threshold or unavailable)");
                skippedInjections++;
                // Switch back to normal keyboard
                switchToNextInputMethod();
            }
        });
    }

    /**
     * Fetch continuity context from Python backend
     */
    private String fetchContext(String userMessage, String platform, boolean forced) {
        HttpURLConnection conn = null;
        try {
            JSONObject request = new JSONObject();
            request.put("user_message", userMessage);
            request.put("platform", platform);
            request.put("threshold", forced ? 0.0f : injectionThreshold);
            request.put("forced", forced);
            request.put("invisible_mode", invisibleMode);
            
            URL url = new URL(CONTEXT_ENDPOINT);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            
            try (OutputStream os = conn.getOutputStream()) {
                os.write(request.toString().getBytes(StandardCharsets.UTF_8));
            }
            
            int responseCode = conn.getResponseCode();
            if (responseCode == 200) {
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                
                JSONObject jsonResponse = new JSONObject(response.toString());
                
                // Check if injection should proceed
                boolean shouldInject = jsonResponse.optBoolean("inject", false);
                float relevance = (float) jsonResponse.optDouble("relevance", 0.0);
                
                Log.d(TAG, String.format("Context response: inject=%b, relevance=%.2f", 
                        shouldInject, relevance));
                
                if (shouldInject) {
                    return jsonResponse.optString("context", "");
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error fetching context: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
        
        return null;
    }

    /**
     * Inject the context + user message into the input field
     */
    private void injectText(String context, String userMessage) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) {
            Log.e(TAG, "No InputConnection available");
            switchToNextInputMethod();
            return;
        }
        
        try {
            // Build the full message
            String fullMessage;
            
            if (invisibleMode) {
                // Invisible injection - context is hidden in a way the AI understands
                // but doesn't clutter the visible message
                fullMessage = buildInvisibleContext(context) + userMessage;
            } else {
                // Visible injection - user can see the context prefix
                fullMessage = "[CONTEXT]\n" + context + "\n[/CONTEXT]\n\n" + userMessage;
            }
            
            // Clear existing text
            ic.beginBatchEdit();
            
            // Select all and delete
            ic.performContextMenuAction(android.R.id.selectAll);
            ic.commitText("", 1);
            
            // Insert the full message
            ic.commitText(fullMessage, 1);
            
            ic.endBatchEdit();
            
            totalInjections++;
            Log.i(TAG, "✅ Injection #" + totalInjections + " complete (" + fullMessage.length() + " chars)");
            
        } catch (Exception e) {
            Log.e(TAG, "Injection error: " + e.getMessage());
        }
        
        // Switch back to normal keyboard
        switchToNextInputMethod();
    }

    /**
     * Build invisible context that AI models understand but is minimally visible
     * Uses Unicode tricks and formatting that LLMs parse but users don't notice
     */
    private String buildInvisibleContext(String context) {
        if (context == null || context.isEmpty()) {
            return "";
        }
        
        // Method 1: Zero-width characters + minimal formatting
        // LLMs still process this text even though it's "hidden"
        
        // Use a very subtle prefix that LLMs understand
        StringBuilder sb = new StringBuilder();
        
        // Add context in a way that's processed but not prominent
        // Using a system-prompt style that most LLMs recognize
        sb.append("<!--CONTINUITY:");
        sb.append(context);
        sb.append("-->\n");
        
        return sb.toString();
    }

    /**
     * Switch to the next/default input method
     */
    private void switchToNextInputMethod() {
        try {
            // This switches to the next enabled IME
            switchToNextInputMethod(false);
            Log.d(TAG, "Switched to next input method");
        } catch (Exception e) {
            Log.e(TAG, "Error switching IME: " + e.getMessage());
        }
    }

    private void runOnMainThread(Runnable action) {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            action.run();
        } else {
            new android.os.Handler(android.os.Looper.getMainLooper()).post(action);
        }
    }

    private String truncate(String s, int max) {
        if (s == null) return "(null)";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}
