package com.udacapp.udac;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.inputmethod.InputMethodManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

/**
 * UDAC Accessibility Service V5
 * ==============================
 * 
 * Monitors AI chat apps and coordinates with Ghost IME for injection.
 * 
 * Flow:
 * 1. Capture text changes (conversation monitoring)
 * 2. Detect Send button clicks
 * 3. Trigger Ghost IME to inject continuity context
 * 4. IME injects and switches back to normal keyboard
 */
public class UDACAccessibilityService extends AccessibilityService {

    private static final String TAG = "UDAC";
    private static final String EVENT_ENDPOINT = "http://127.0.0.1:7013/udac/event";
    private static final String SETTINGS_ENDPOINT = "http://127.0.0.1:7013/udac/settings";
    
    // Target packages to monitor
    private static final Set<String> TARGET_PACKAGES = new HashSet<>();
    static {
        TARGET_PACKAGES.add("com.openai.chatgpt");
        TARGET_PACKAGES.add("com.anthropic.claude");
        TARGET_PACKAGES.add("ai.perplexity.app.android");
        TARGET_PACKAGES.add("ai.perplexity.app");
        TARGET_PACKAGES.add("com.google.android.apps.bard");
        TARGET_PACKAGES.add("com.google.android.apps.gemini");
        TARGET_PACKAGES.add("com.microsoft.bing");
        TARGET_PACKAGES.add("com.microsoft.copilot");
        TARGET_PACKAGES.add("com.quora.poe");
    }
    
    private static final Map<String, String> PLATFORM_NAMES = new HashMap<>();
    static {
        PLATFORM_NAMES.put("com.openai.chatgpt", "ChatGPT");
        PLATFORM_NAMES.put("com.anthropic.claude", "Claude");
        PLATFORM_NAMES.put("ai.perplexity.app.android", "Perplexity");
        PLATFORM_NAMES.put("ai.perplexity.app", "Perplexity");
        PLATFORM_NAMES.put("com.google.android.apps.bard", "Gemini");
        PLATFORM_NAMES.put("com.google.android.apps.gemini", "Gemini");
        PLATFORM_NAMES.put("com.microsoft.bing", "Copilot");
        PLATFORM_NAMES.put("com.microsoft.copilot", "Copilot");
        PLATFORM_NAMES.put("com.quora.poe", "Poe");
    }
    
    private ExecutorService executor;
    private Handler mainHandler;
    
    // State tracking
    private String currentPackage = "";
    private String lastUserMessage = "";
    private String lastCapturedHash = "";
    private long lastCaptureTime = 0;
    private long lastInjectionTime = 0;
    
    private static final long DEBOUNCE_MS = 500;
    private static final long INJECTION_COOLDOWN_MS = 2000;
    
    // Stats
    private int captureCount = 0;
    private int sendDetections = 0;
    private int injectionTriggers = 0;
    
    // Settings (synced from Python backend)
    private boolean injectionEnabled = true;
    private boolean invisibleMode = true;
    private float injectionThreshold = 0.5f;
    
    // Static instance for status checking
    private static UDACAccessibilityService instance;
    private static boolean isRunning = false;

    public static boolean isServiceRunning() {
        return isRunning && instance != null;
    }
    
    public static UDACAccessibilityService getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        
        try {
            executor = Executors.newFixedThreadPool(2);
            mainHandler = new Handler(Looper.getMainLooper());
            
            Log.i(TAG, "════════════════════════════════════════");
            Log.i(TAG, "  UDAC ACCESSIBILITY SERVICE V5");
            Log.i(TAG, "  Mode: Capture + Injection Coordinator");
            Log.i(TAG, "════════════════════════════════════════");
        } catch (Exception e) {
            Log.e(TAG, "onCreate error: " + e.getMessage());
        }
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        
        try {
            AccessibilityServiceInfo info = getServiceInfo();
            if (info == null) {
                info = new AccessibilityServiceInfo();
            }
            
            // Listen for text changes and clicks
            info.eventTypes = AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                    | AccessibilityEvent.TYPE_VIEW_CLICKED
                    | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
            
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                    | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            info.notificationTimeout = 50;
            
            setServiceInfo(info);
            isRunning = true;
            
            Log.i(TAG, "════════════════════════════════════════");
            Log.i(TAG, "  SERVICE CONNECTED & READY");
            Log.i(TAG, "  Injection: " + (injectionEnabled ? "ENABLED" : "DISABLED"));
            Log.i(TAG, "  Invisible: " + invisibleMode);
            Log.i(TAG, "  Threshold: " + injectionThreshold);
            Log.i(TAG, "════════════════════════════════════════");
            
            // Check if Ghost IME is enabled
            checkIMEStatus();
            
            // Sync settings from backend
            syncSettings();
            
            // Send startup event
            sendEvent("UDAC_SERVICE", "Service V5 connected", "startup");
            
        } catch (Exception e) {
            Log.e(TAG, "onServiceConnected error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void checkIMEStatus() {
        String enabledIMEs = Settings.Secure.getString(
            getContentResolver(),
            Settings.Secure.ENABLED_INPUT_METHODS
        );
        
        boolean imeEnabled = enabledIMEs != null && enabledIMEs.contains("UDACInputMethodService");
        
        if (imeEnabled) {
            Log.i(TAG, "✅ Ghost IME is enabled");
        } else {
            Log.w(TAG, "⚠️ Ghost IME not enabled - injection will not work");
            Log.w(TAG, "   Enable 'UDAC Ghost Keyboard' in Settings → Keyboards");
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        
        try {
            CharSequence pkgSeq = event.getPackageName();
            if (pkgSeq == null) return;
            
            String packageName = pkgSeq.toString();
            
            // Only process target apps
            if (!TARGET_PACKAGES.contains(packageName)) {
                return;
            }
            
            currentPackage = packageName;
            int eventType = event.getEventType();
            
            switch (eventType) {
                case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                    handleTextChange(event);
                    break;
                    
                case AccessibilityEvent.TYPE_VIEW_CLICKED:
                    handleClick(event, packageName);
                    break;
                    
                case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
                    handleContentChange(event, packageName);
                    break;
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Event processing error: " + e.getMessage());
        }
    }

    /**
     * Track text being typed by user
     */
    private void handleTextChange(AccessibilityEvent event) {
        AccessibilityNodeInfo source = event.getSource();
        if (source == null) return;
        
        try {
            if (source.isEditable()) {
                CharSequence text = source.getText();
                if (text != null) {
                    lastUserMessage = text.toString();
                    Log.d(TAG, "📝 User typing: '" + truncate(lastUserMessage, 50) + "'");
                }
            }
        } finally {
            source.recycle();
        }
    }

    /**
     * Detect Send button clicks - this is where we trigger injection
     */
    private void handleClick(AccessibilityEvent event, String packageName) {
        AccessibilityNodeInfo source = event.getSource();
        if (source == null) return;
        
        try {
            if (isSendButton(source)) {
                sendDetections++;
                String platform = PLATFORM_NAMES.getOrDefault(packageName, packageName);
                
                Log.i(TAG, "════════════════════════════════════════");
                Log.i(TAG, "  🚀 SEND BUTTON DETECTED #" + sendDetections);
                Log.i(TAG, "  Platform: " + platform);
                Log.i(TAG, "  Message: '" + truncate(lastUserMessage, 50) + "'");
                Log.i(TAG, "════════════════════════════════════════");
                
                // Trigger injection if enabled
                if (injectionEnabled && lastUserMessage != null && !lastUserMessage.trim().isEmpty()) {
                    triggerInjection(lastUserMessage, platform);
                }
                
                // Send event to backend
                sendEvent(platform, lastUserMessage, "send_detected");
            }
        } finally {
            source.recycle();
        }
    }

    /**
     * Check if a node looks like a Send button
     */
    private boolean isSendButton(AccessibilityNodeInfo node) {
        if (node == null) return false;
        
        String className = node.getClassName() != null ? node.getClassName().toString() : "";
        CharSequence contentDesc = node.getContentDescription();
        CharSequence text = node.getText();
        String viewId = node.getViewIdResourceName();
        
        // Check view ID
        if (viewId != null) {
            String id = viewId.toLowerCase();
            if (id.contains("send") || id.contains("submit") || id.contains("post") ||
                id.contains("arrow") || id.contains("fab") || id.contains("done") ||
                id.contains("composer_send") || id.contains("btn_send")) {
                return true;
            }
        }
        
        // Check content description
        if (contentDesc != null) {
            String desc = contentDesc.toString().toLowerCase();
            if (desc.contains("send") || desc.contains("submit") || desc.contains("post")) {
                return true;
            }
        }
        
        // Check text
        if (text != null) {
            String t = text.toString().toLowerCase().trim();
            if (t.equals("send") || t.equals("submit") || t.equals("post") || t.equals("→")) {
                return true;
            }
        }
        
        // Check for ImageButton/FAB with arrow icons (common send button pattern)
        if (className.contains("ImageButton") || className.contains("FloatingActionButton")) {
            // If it's clickable and in a chat app, likely a send button
            if (node.isClickable() && (contentDesc != null || viewId != null)) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Trigger the Ghost IME to inject continuity context
     */
    private void triggerInjection(String message, String platform) {
        // Check cooldown
        long now = System.currentTimeMillis();
        if (now - lastInjectionTime < INJECTION_COOLDOWN_MS) {
            Log.d(TAG, "Injection cooldown active, skipping");
            return;
        }
        lastInjectionTime = now;
        injectionTriggers++;
        
        Log.i(TAG, "🎯 Triggering injection #" + injectionTriggers);
        
        // Schedule injection in IME
        UDACInputMethodService.scheduleInjection(message, platform);
        
        // Update IME settings
        UDACInputMethodService.updateSettings(injectionEnabled, invisibleMode, injectionThreshold);
        
        // Show IME picker to activate Ghost IME
        // User needs to select it (or it auto-activates if set as default)
        showIMEPicker();
    }

    /**
     * Show IME picker to let user switch to Ghost IME
     */
    private void showIMEPicker() {
        try {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) {
                imm.showInputMethodPicker();
                Log.i(TAG, "📲 IME picker shown");
            }
        } catch (Exception e) {
            Log.e(TAG, "Error showing IME picker: " + e.getMessage());
        }
    }

    /**
     * Capture AI responses for context building
     */
    private void handleContentChange(AccessibilityEvent event, String packageName) {
        String text = extractText(event);
        if (text == null || text.trim().length() < 5) return;
        
        // Debounce
        String hash = String.valueOf(text.hashCode());
        long now = System.currentTimeMillis();
        if (hash.equals(lastCapturedHash) && (now - lastCaptureTime) < DEBOUNCE_MS) {
            return;
        }
        lastCapturedHash = hash;
        lastCaptureTime = now;
        
        // Skip if it's the user's own message
        if (lastUserMessage != null && !lastUserMessage.isEmpty()) {
            if (text.contains(lastUserMessage)) {
                return;
            }
        }
        
        captureCount++;
        String platform = PLATFORM_NAMES.getOrDefault(packageName, packageName);
        Log.d(TAG, "📥 Capture #" + captureCount + " from " + platform);
        
        sendEvent(platform, text, "content_captured");
    }

    private String extractText(AccessibilityEvent event) {
        StringBuilder sb = new StringBuilder();
        
        try {
            if (event.getText() != null) {
                for (CharSequence t : event.getText()) {
                    if (t != null && t.length() > 0) {
                        sb.append(t).append(" ");
                    }
                }
            }
            
            AccessibilityNodeInfo source = event.getSource();
            if (source != null) {
                try {
                    CharSequence text = source.getText();
                    if (text != null && text.length() > 0) {
                        if (sb.length() > 0) sb.append(" ");
                        sb.append(text);
                    }
                } finally {
                    source.recycle();
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Text extraction error: " + e.getMessage());
        }
        
        return sb.toString().trim();
    }

    /**
     * Send event to Python backend
     */
    private void sendEvent(String platform, String text, String eventType) {
        if (executor == null || executor.isShutdown()) return;
        
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject payload = new JSONObject();
                payload.put("source_app", platform);
                payload.put("text", text);
                payload.put("event_type", eventType);
                payload.put("timestamp", System.currentTimeMillis());
                payload.put("capture_count", captureCount);
                payload.put("injection_triggers", injectionTriggers);
                
                URL url = new URL(EVENT_ENDPOINT);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(3000);
                
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
                }
                
                conn.getResponseCode();
                
            } catch (Exception e) {
                // Backend may not be running
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    /**
     * Sync settings from Python backend
     */
    private void syncSettings() {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(SETTINGS_ENDPOINT);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(2000);
                conn.setReadTimeout(2000);
                
                if (conn.getResponseCode() == 200) {
                    BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();
                    
                    JSONObject settings = new JSONObject(response.toString());
                    
                    injectionEnabled = settings.optBoolean("injection_enabled", true);
                    invisibleMode = settings.optBoolean("invisible_mode", true);
                    injectionThreshold = (float) settings.optDouble("threshold", 0.5);
                    
                    Log.i(TAG, "⚙️ Settings synced: enabled=" + injectionEnabled + 
                          ", invisible=" + invisibleMode + ", threshold=" + injectionThreshold);
                }
            } catch (Exception e) {
                // Use defaults if backend unavailable
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    /**
     * Update settings (called from MainActivity)
     */
    public void updateSettings(boolean enabled, boolean invisible, float threshold) {
        this.injectionEnabled = enabled;
        this.invisibleMode = invisible;
        this.injectionThreshold = threshold;
        
        // Also update IME settings
        UDACInputMethodService.updateSettings(enabled, invisible, threshold);
        
        Log.i(TAG, "⚙️ Settings updated locally");
    }

    /**
     * Force next injection (for debugging)
     */
    public void forceInjection() {
        UDACInputMethodService.forceNextInjection();
        Log.i(TAG, "🔧 Force injection queued");
    }

    private String truncate(String s, int max) {
        if (s == null) return "(null)";
        s = s.replace("\n", " ").replace("\r", "");
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    @Override
    public void onInterrupt() {
        Log.w(TAG, "Service interrupted");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        instance = null;
        
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
        
        Log.i(TAG, "════════════════════════════════════════");
        Log.i(TAG, "  UDAC SERVICE DESTROYED");
        Log.i(TAG, "  Captures: " + captureCount);
        Log.i(TAG, "  Send detections: " + sendDetections);
        Log.i(TAG, "  Injection triggers: " + injectionTriggers);
        Log.i(TAG, "════════════════════════════════════════");
    }
}
