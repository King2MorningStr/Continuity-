"""
UDAC Listener V5 - With Context Generation
===========================================

HTTP server that:
1. Receives events from AccessibilityService
2. Provides context for injection (GET/POST /udac/context)
3. Manages settings (GET/POST /udac/settings)
"""

import json
import threading
import time
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Dict, Any, Optional, List

# ════════════════════════════════════════════════════════════════
# STATE MANAGEMENT
# ════════════════════════════════════════════════════════════════

_state_lock = threading.Lock()
_state = {
    # Event tracking
    "total_events": 0,
    "last_source": None,
    "last_text": "",
    "last_event_type": "",
    "platform_counts": {},  # packageName -> count
    
    # Injection stats
    "total_injections": 0,
    "skipped_injections": 0,
    
    # Conversation history (for context building)
    "conversation_history": [],  # List of {platform, role, text, timestamp}
    "max_history": 50,
    
    # Settings
    "injection_enabled": True,
    "invisible_mode": True,
    "threshold": 0.5,
}


def get_udac_stats() -> Dict[str, Any]:
    """Return current UDAC state."""
    with _state_lock:
        return {
            "total_events": _state["total_events"],
            "last_source": _state["last_source"],
            "last_text": _state["last_text"],
            "last_event_type": _state["last_event_type"],
            "platform_counts": dict(_state["platform_counts"]),
            "total_injections": _state["total_injections"],
            "skipped_injections": _state["skipped_injections"],
            "history_size": len(_state["conversation_history"]),
        }


def get_settings() -> Dict[str, Any]:
    """Return current settings."""
    with _state_lock:
        return {
            "injection_enabled": _state["injection_enabled"],
            "invisible_mode": _state["invisible_mode"],
            "threshold": _state["threshold"],
        }


def update_settings(settings: Dict[str, Any]):
    """Update settings."""
    with _state_lock:
        if "injection_enabled" in settings:
            _state["injection_enabled"] = bool(settings["injection_enabled"])
        if "invisible_mode" in settings:
            _state["invisible_mode"] = bool(settings["invisible_mode"])
        if "threshold" in settings:
            _state["threshold"] = max(0.0, min(1.0, float(settings["threshold"])))


def add_to_history(platform: str, text: str, role: str = "assistant"):
    """Add conversation to history."""
    with _state_lock:
        _state["conversation_history"].append({
            "platform": platform,
            "role": role,
            "text": text[:500],  # Truncate long texts
            "timestamp": time.time(),
        })
        
        # Trim history if too long
        while len(_state["conversation_history"]) > _state["max_history"]:
            _state["conversation_history"].pop(0)


def generate_context(user_message: str, platform: str, threshold: float, forced: bool) -> Dict[str, Any]:
    """
    Generate continuity context for injection.
    
    Returns:
        {
            "inject": bool,      # Whether to inject
            "relevance": float,  # 0.0 - 1.0 relevance score
            "context": str,      # The context to inject
        }
    """
    with _state_lock:
        history = list(_state["conversation_history"])
        invisible = _state["invisible_mode"]
    
    if not history:
        return {"inject": False, "relevance": 0.0, "context": ""}
    
    # ════════════════════════════════════════════════════════════════
    # CONTEXT BUILDING LOGIC
    # ════════════════════════════════════════════════════════════════
    
    # Filter relevant history
    relevant = []
    keywords = extract_keywords(user_message)
    
    for entry in reversed(history[-20:]):  # Last 20 entries
        # Skip very old entries (more than 1 hour)
        if time.time() - entry["timestamp"] > 3600:
            continue
            
        # Calculate relevance
        entry_keywords = extract_keywords(entry["text"])
        overlap = len(keywords & entry_keywords)
        
        if overlap > 0 or forced:
            relevance = min(1.0, overlap / max(1, len(keywords)) + 0.2)
            relevant.append({
                **entry,
                "relevance": relevance
            })
    
    if not relevant and not forced:
        return {"inject": False, "relevance": 0.0, "context": ""}
    
    # Sort by relevance
    relevant.sort(key=lambda x: x["relevance"], reverse=True)
    
    # Calculate overall relevance
    overall_relevance = sum(r["relevance"] for r in relevant[:5]) / max(1, min(5, len(relevant)))
    
    # Check threshold
    if overall_relevance < threshold and not forced:
        with _state_lock:
            _state["skipped_injections"] += 1
        return {"inject": False, "relevance": overall_relevance, "context": ""}
    
    # Build context string
    context_parts = []
    
    # Add platform context
    platforms_used = set(r["platform"] for r in relevant[:5])
    if len(platforms_used) > 1:
        context_parts.append(f"Cross-platform context from: {', '.join(platforms_used)}")
    
    # Add relevant conversation snippets
    for entry in relevant[:3]:  # Top 3 most relevant
        snippet = entry["text"][:200]
        if len(entry["text"]) > 200:
            snippet += "..."
        context_parts.append(f"[{entry['platform']}] {snippet}")
    
    context = "\n".join(context_parts)
    
    with _state_lock:
        _state["total_injections"] += 1
    
    return {
        "inject": True,
        "relevance": overall_relevance,
        "context": context,
    }


def extract_keywords(text: str) -> set:
    """Extract keywords from text for relevance matching."""
    if not text:
        return set()
    
    # Simple keyword extraction
    words = text.lower().split()
    
    # Filter out common words
    stopwords = {
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare',
        'ought', 'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by',
        'from', 'as', 'into', 'through', 'during', 'before', 'after', 'above',
        'below', 'between', 'under', 'again', 'further', 'then', 'once', 'here',
        'there', 'when', 'where', 'why', 'how', 'all', 'each', 'few', 'more',
        'most', 'other', 'some', 'such', 'no', 'nor', 'not', 'only', 'own',
        'same', 'so', 'than', 'too', 'very', 'just', 'and', 'but', 'if', 'or',
        'because', 'until', 'while', 'this', 'that', 'these', 'those', 'i', 'me',
        'my', 'you', 'your', 'he', 'him', 'his', 'she', 'her', 'it', 'its',
        'we', 'us', 'our', 'they', 'them', 'their', 'what', 'which', 'who',
    }
    
    keywords = set()
    for word in words:
        # Clean word
        word = ''.join(c for c in word if c.isalnum())
        if len(word) > 2 and word not in stopwords:
            keywords.add(word)
    
    return keywords


# ════════════════════════════════════════════════════════════════
# HTTP REQUEST HANDLER
# ════════════════════════════════════════════════════════════════

class UDACRequestHandler(BaseHTTPRequestHandler):
    
    def do_GET(self):
        """Handle GET requests."""
        if self.path == "/udac/settings":
            self._send_json(get_settings())
        elif self.path == "/udac/stats":
            self._send_json(get_udac_stats())
        else:
            self._send_error(404, "Not found")
    
    def do_POST(self):
        """Handle POST requests."""
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length)
        
        try:
            payload = json.loads(body.decode("utf-8")) if body else {}
        except json.JSONDecodeError:
            self._send_error(400, "Invalid JSON")
            return
        
        if self.path == "/udac/event":
            self._handle_event(payload)
        elif self.path == "/udac/context":
            self._handle_context_request(payload)
        elif self.path == "/udac/settings":
            self._handle_settings_update(payload)
        else:
            self._send_error(404, "Not found")
    
    def _handle_event(self, payload: Dict):
        """Handle incoming event from AccessibilityService."""
        text = (payload.get("text") or "").strip()
        source_app = (payload.get("source_app") or "").strip()
        event_type = (payload.get("event_type") or "").strip()
        
        with _state_lock:
            _state["total_events"] += 1
            _state["last_source"] = source_app or "unknown"
            _state["last_text"] = text
            _state["last_event_type"] = event_type
            
            if source_app:
                _state["platform_counts"][source_app] = (
                    _state["platform_counts"].get(source_app, 0) + 1
                )
        
        # Add to history if it's captured content
        if event_type == "content_captured" and text:
            add_to_history(source_app, text, "assistant")
        elif event_type == "send_detected" and text:
            add_to_history(source_app, text, "user")
        
        self._send_json({"status": "ok"})
    
    def _handle_context_request(self, payload: Dict):
        """Handle context generation request from IME."""
        user_message = payload.get("user_message", "")
        platform = payload.get("platform", "unknown")
        threshold = payload.get("threshold", 0.5)
        forced = payload.get("forced", False)
        
        result = generate_context(user_message, platform, threshold, forced)
        self._send_json(result)
    
    def _handle_settings_update(self, payload: Dict):
        """Handle settings update."""
        update_settings(payload)
        self._send_json({"status": "ok", **get_settings()})
    
    def _send_json(self, data: Dict):
        """Send JSON response."""
        response = json.dumps(data).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", len(response))
        self.end_headers()
        self.wfile.write(response)
    
    def _send_error(self, code: int, message: str):
        """Send error response."""
        self.send_response(code)
        self.end_headers()
        self.wfile.write(message.encode("utf-8"))
    
    def log_message(self, format, *args):
        """Silence default logging."""
        pass


# ════════════════════════════════════════════════════════════════
# SERVER MANAGEMENT
# ════════════════════════════════════════════════════════════════

_server = None
_server_thread = None


def start_udac_listener(port: int = 7013) -> threading.Thread:
    """Start the UDAC HTTP server."""
    global _server, _server_thread
    
    _server = HTTPServer(("127.0.0.1", port), UDACRequestHandler)
    
    def run():
        print(f"[UDAC] Server starting on http://127.0.0.1:{port}")
        _server.serve_forever()
    
    _server_thread = threading.Thread(target=run, daemon=True)
    _server_thread.start()
    
    print(f"[UDAC] Listener V5 online")
    print(f"[UDAC] Endpoints:")
    print(f"       POST /udac/event    - Receive events from Android")
    print(f"       POST /udac/context  - Generate injection context")
    print(f"       GET  /udac/settings - Get current settings")
    print(f"       POST /udac/settings - Update settings")
    print(f"       GET  /udac/stats    - Get statistics")
    
    return _server_thread


def stop_udac_listener():
    """Stop the UDAC HTTP server."""
    global _server
    if _server:
        _server.shutdown()
        print("[UDAC] Server stopped")
