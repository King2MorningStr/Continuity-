"""Entry point for dimensional_cortex package."""

from dimensional_cortex.main import start_backend

# Start backend services
start_backend()
