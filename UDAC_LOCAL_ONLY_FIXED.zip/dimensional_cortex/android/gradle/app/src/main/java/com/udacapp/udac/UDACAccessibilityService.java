package com.udacapp.udac;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.inputmethod.InputMethodManager;
import java.io.File;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

public class UDACAccessibilityService extends AccessibilityService {

    private static final String TAG = "UDACService";

    private final Set<String> TARGET_PACKAGES = new HashSet<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private String currentPackage = "";
    private boolean hasFocus = false;
    private boolean serviceActive = false;

    private Handler handler;

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());

        TARGET_PACKAGES.add("com.openai.chatgpt");
        TARGET_PACKAGES.add("com.anthropic.claude");
        TARGET_PACKAGES.add("ai.perplexity.app.android");
        TARGET_PACKAGES.add("ai.perplexity.app");
        TARGET_PACKAGES.add("com.google.android.apps.bard");
        TARGET_PACKAGES.add("com.google.android.apps.gemini");
        TARGET_PACKAGES.add("com.microsoft.bing");
        TARGET_PACKAGES.add("com.microsoft.copilot");
        TARGET_PACKAGES.add("com.quora.poe");

        Log.i(TAG, "UDAC Accessibility Service created (LOCAL ONLY MODE)");
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
                | AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.notificationTimeout = 50;
        info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;

        setServiceInfo(info);

        Log.i(TAG, "Accessibility Service connected");
    }

    private File getLogFile() {
        File dir = getExternalFilesDir(null);
        if (dir == null) {
            return null;
        }
        return new File(dir, "udac_continuity_log.jsonl");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) {
            return;
        }

        String pkg = event.getPackageName().toString();

        boolean relevant = TARGET_PACKAGES.contains(pkg);

        if (!relevant) {
            if (serviceActive) {
                serviceActive = false;
                Log.i(TAG, "UDAC deactivated (left target apps)");
            }
            return;
        }

        if (!serviceActive) {
            serviceActive = true;
            Log.i(TAG, "UDAC activated (entered target app: " + pkg + ")");
        }

        currentPackage = pkg;

        CharSequence text = event.getText() != null && event.getText().size() > 0
                ? event.getText().get(0)
                : null;

        if (text == null) {
            return;
        }

        logCaptureEvent(pkg, text.toString(), event.getEventType());
    }

    private void logCaptureEvent(String sourceApp, String text, int eventType) {
        executor.execute(() -> {
            try {
                JSONObject obj = new JSONObject();
                obj.put("source_app", sourceApp);
                obj.put("text", text);
                obj.put("event_type", eventType);
                obj.put("timestamp", System.currentTimeMillis());

                File logFile = getLogFile();
                if (logFile == null) {
                    Log.e(TAG, "Cannot write log: externalFilesDir null");
                    return;
                }

                FileWriter fw = new FileWriter(logFile, true);
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(obj.toString());
                bw.newLine();
                bw.close();
            } catch (Exception e) {
                Log.e(TAG, "Failed to write continuity log", e);
            }
        });
    }

    @Override
    public void onInterrupt() {
        Log.w(TAG, "UDAC Accessibility Service interrupted");
    }
}
