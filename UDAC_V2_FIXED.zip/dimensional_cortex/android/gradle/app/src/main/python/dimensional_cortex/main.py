"""
Dimensional Cortex - UDAC Continuity Engine
============================================
Simplified version for debugging blank screen issue.
"""

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW, CENTER, BOLD
import sys
import logging

# Setup logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("UDAC")

# Track what loaded
MODULES_LOADED = {
    'trinity': False,
    'udac': False,
    'injector': False
}
ERRORS = []

# Try imports
try:
    from dimensional_cortex.dimensional_memory_constant_standalone_demo import start_memory_system, stop_memory_system
    from dimensional_cortex.dimensional_processing_system_standalone_demo import CrystalMemorySystem, GovernanceEngine
    from dimensional_cortex.dimensional_energy_regulator_mobile import DimensionalEnergyRegulator
    MODULES_LOADED['trinity'] = True
    logger.info("Trinity modules loaded")
except Exception as e:
    ERRORS.append(f"Trinity: {e}")
    logger.error(f"Trinity load failed: {e}")

try:
    from dimensional_cortex.udac_listener import start_udac_listener, get_udac_stats
    MODULES_LOADED['udac'] = True
    logger.info("UDAC module loaded")
except Exception as e:
    ERRORS.append(f"UDAC: {e}")
    logger.error(f"UDAC load failed: {e}")

try:
    from dimensional_cortex.continuity_injector import get_injector, Platform
    MODULES_LOADED['injector'] = True
    logger.info("Injector module loaded")
except Exception as e:
    ERRORS.append(f"Injector: {e}")
    logger.error(f"Injector load failed: {e}")


class TrinityManager:
    """Manages Trinity system."""
    
    def __init__(self):
        self.running = False
        self.memory_system = None
        self.crystal_system = None
        self.energy_regulator = None
        self.error = None
    
    def start(self):
        if self.running:
            return True
        
        if not MODULES_LOADED['trinity']:
            self.error = "Trinity modules not loaded"
            return False
        
        try:
            logger.info("Starting Trinity...")
            
            # Memory
            self.memory_governor, self.memory_system, self.save_thread, self.merge_thread = start_memory_system()
            
            # Processing
            governance = GovernanceEngine(data_theme="conversation")
            self.crystal_system = CrystalMemorySystem(governance_engine=governance)
            
            # Energy
            self.energy_regulator = DimensionalEnergyRegulator(conservation_limit=50.0)
            
            self.running = True
            logger.info("Trinity online!")
            return True
            
        except Exception as e:
            self.error = str(e)
            logger.error(f"Trinity start failed: {e}")
            return False
    
    def get_stats(self):
        if not self.running:
            return {'nodes': 0, 'crystals': 0}
        
        try:
            return {
                'nodes': len(self.memory_system.nodes) if self.memory_system else 0,
                'crystals': len(self.crystal_system.crystals) if self.crystal_system else 0
            }
        except:
            return {'nodes': 0, 'crystals': 0}


# Global instance
TRINITY = TrinityManager()


class UDACApp(toga.App):
    """Main UDAC Application."""
    
    def startup(self):
        logger.info("=== UDAC App Starting ===")
        
        self.main_window = toga.MainWindow(title=self.formal_name)
        
        # Create main content
        main_box = toga.Box(style=Pack(
            direction=COLUMN,
            padding=20,
            background_color='#1a1a2e'
        ))
        
        # Title
        main_box.add(toga.Label(
            '⚡ UDAC Continuity Engine',
            style=Pack(
                font_size=20,
                font_weight=BOLD,
                color='#00d4aa',
                padding_bottom=5
            )
        ))
        
        main_box.add(toga.Label(
            'Universal AI Memory Bridge',
            style=Pack(font_size=12, color='#888888', padding_bottom=20)
        ))
        
        # Status section
        status_box = toga.Box(style=Pack(
            direction=COLUMN,
            padding=15,
            background_color='#252542'
        ))
        
        # Module status
        status_box.add(toga.Label(
            'Module Status:',
            style=Pack(font_weight=BOLD, color='#ffffff', padding_bottom=10)
        ))
        
        for name, loaded in MODULES_LOADED.items():
            icon = '✓' if loaded else '✗'
            color = '#00d4aa' if loaded else '#ff6b6b'
            status_box.add(toga.Label(
                f'{icon} {name.capitalize()}',
                style=Pack(color=color, padding_bottom=3)
            ))
        
        main_box.add(status_box)
        
        # Errors section
        if ERRORS:
            main_box.add(toga.Box(style=Pack(height=15)))
            error_box = toga.Box(style=Pack(
                direction=COLUMN,
                padding=10,
                background_color='#3d1f1f'
            ))
            error_box.add(toga.Label(
                'Errors:',
                style=Pack(font_weight=BOLD, color='#ff6b6b', padding_bottom=5)
            ))
            for err in ERRORS[:3]:
                error_box.add(toga.Label(
                    err[:60] + '...' if len(err) > 60 else err,
                    style=Pack(color='#ff9999', font_size=10, padding_bottom=2)
                ))
            main_box.add(error_box)
        
        # Status label
        main_box.add(toga.Box(style=Pack(height=15)))
        self.status_label = toga.Label(
            'Ready to start',
            style=Pack(color='#ffa500', padding_bottom=15)
        )
        main_box.add(self.status_label)
        
        # Start button
        if MODULES_LOADED['trinity']:
            start_btn = toga.Button(
                'START TRINITY',
                on_press=self.start_trinity,
                style=Pack(
                    padding=15,
                    background_color='#00d4aa',
                    color='#000000',
                    font_weight=BOLD
                )
            )
            main_box.add(start_btn)
        
        # Settings button
        main_box.add(toga.Box(style=Pack(height=10)))
        settings_btn = toga.Button(
            'Open Accessibility Settings',
            on_press=self.open_settings,
            style=Pack(padding=12, background_color='#333355')
        )
        main_box.add(settings_btn)
        
        # Python info
        main_box.add(toga.Box(style=Pack(height=20)))
        main_box.add(toga.Label(
            f'Python {sys.version.split()[0]}',
            style=Pack(color='#666666', font_size=10)
        ))
        
        self.main_window.content = main_box
        self.main_window.show()
        
        logger.info("=== UDAC App Started ===")
    
    def start_trinity(self, widget):
        self.status_label.text = 'Starting Trinity...'
        
        if TRINITY.start():
            self.status_label.text = '✓ Trinity Online!'
            self.status_label.style.color = '#00d4aa'
            
            # Start UDAC listener if available
            if MODULES_LOADED['udac']:
                try:
                    start_udac_listener(port=7013)
                    self.status_label.text = '✓ Trinity + UDAC Online!'
                except Exception as e:
                    logger.error(f"UDAC listener failed: {e}")
        else:
            self.status_label.text = f'✗ Failed: {TRINITY.error}'
            self.status_label.style.color = '#ff6b6b'
    
    def open_settings(self, widget):
        self.status_label.text = 'Go to: Settings → Accessibility → UDAC'
        self.status_label.style.color = '#ffa500'
        
        try:
            # Try to open settings programmatically
            from java import jclass
            Intent = jclass("android.content.Intent")
            
            # Get activity context
            from rubicon.java import JavaClass
            PythonActivity = JavaClass("org/beeware/android/MainActivity")
            activity = PythonActivity.singletonThis
            
            if activity:
                intent = Intent("android.settings.ACCESSIBILITY_SETTINGS")
                activity.startActivity(intent)
                self.status_label.text = 'Settings opened'
                self.status_label.style.color = '#00d4aa'
        except Exception as e:
            logger.error(f"Could not open settings: {e}")
            # Keep the manual instructions


def main():
    logger.info("main() called")
    return UDACApp(
        'UDAC Continuity',
        'com.udacapp.udac'
    )


# This is what gets called when run as __main__
if __name__ == '__main__':
    logger.info("__main__ executing")
    app = main()
    app.main_loop()
