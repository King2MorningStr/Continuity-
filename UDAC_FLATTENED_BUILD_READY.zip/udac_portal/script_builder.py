"""
Portal Script Builder - JavaScript Generation
=============================================
Generates JavaScript code for DOM observation and message injection.
"""

from typing import Optional
from udac_portal.platform_registry import AiWebPlatform


class PortalScriptBuilder:
    """
    Generates JavaScript code to inject into WebView for:
    - Observing user messages in DOM
    - Observing AI responses in DOM
    - Detecting live transcript chunks
    - Injecting enriched prompts
    """
    
    @staticmethod
    def build(platform: AiWebPlatform) -> str:
        """Build the complete observation script for a platform."""
        return f'''
(function() {{
    // UDAC Portal Bridge - {platform.name}
    // =====================================
    
    const CONFIG = {{
        inputSelector: `{platform.input_selector}`,
        sendSelector: `{platform.send_selector or ''}`,
        userMessageSelector: `{platform.user_message_selector}`,
        aiMessageSelector: `{platform.ai_message_selector}`,
        transcriptSelector: `{platform.transcript_selector or ''}`,
        liveIndicatorSelector: `{platform.live_mode_indicator_selector or ''}`,
    }};
    
    // Track seen messages to avoid duplicates
    const seenMessages = new Set();

// Selector helper: support fallback lists with "||"
function splitSelectors(sel) {
    if (!sel) return [];
    return sel.split('||').map(s => s.trim()).filter(Boolean);
}

function firstVisible(elements) {
    if (!elements || !elements.length) return null;
    for (const el of elements) {
        try {
            const style = window.getComputedStyle(el);
            if (style && style.display !== 'none' && style.visibility !== 'hidden') return el;
        } catch (e) {}
        return el;
    }
    return elements[0] || null;
}

function findFirst(sel) {
    const parts = splitSelectors(sel);
    for (const p of parts.length ? parts : [sel]) {
        const el = document.querySelector(p);
        if (el) return el;
    }
    return null;
}

function findAll(sel) {
    const parts = splitSelectors(sel);
    let all = [];
    for (const p of parts.length ? parts : [sel]) {
        all = all.concat(Array.from(document.querySelectorAll(p)));
    }
    return all;
}

    
    // Helper: Extract text from element
    function extractText(el) {{
        if (!el) return '';
        // Try innerText first, then textContent
        let text = (el.innerText || el.textContent || '').trim();
        // Clean up excessive whitespace
        return text.replace(/\\s+/g, ' ').substring(0, 10000);
    }}
    
    // Helper: Generate message hash for dedup
    function msgHash(text) {{
        let hash = 0;
        const sample = text.substring(0, 200);
        for (let i = 0; i < sample.length; i++) {{
            hash = ((hash << 5) - hash) + sample.charCodeAt(i);
            hash |= 0;
        }}
        return hash.toString();
    }}
    
    // 1. Observe User Messages
    function observeUserMessages() {{
        if (!CONFIG.userMessageSelector) return;
        
        const observer = new MutationObserver((mutations) => {{
            const userMsgs = findAll(CONFIG.userMessageSelector);
            userMsgs.forEach((el) => {{
                const text = extractText(el);
                if (!text || text.length < 2) return;
                
                const hash = 'user_' + msgHash(text);
                if (seenMessages.has(hash)) return;
                seenMessages.add(hash);
                
                // Limit seen messages set size
                if (seenMessages.size > 500) {{
                    const arr = Array.from(seenMessages);
                    seenMessages.clear();
                    arr.slice(-250).forEach(h => seenMessages.add(h));
                }}
                
                try {{
                    window.UDACBridge.onPlatformUserMessageDetected(text);
                }} catch(e) {{
                    console.log('[UDAC] Bridge not ready:', e);
                }}
            }});
        }});
        
        observer.observe(document.body, {{ 
            childList: true, 
            subtree: true,
            characterData: true
        }});
        console.log('[UDAC] User message observer started');
    }}
    
    // 2. Observe AI Messages
    function observeAiMessages() {{
        if (!CONFIG.aiMessageSelector) return;
        
        // Debounce to catch complete messages
        let aiDebounce = null;
        
        const observer = new MutationObserver((mutations) => {{
            clearTimeout(aiDebounce);
            aiDebounce = setTimeout(() => {{
                const aiMsgs = findAll(CONFIG.aiMessageSelector);
                aiMsgs.forEach((el) => {{
                    const text = extractText(el);
                    if (!text || text.length < 10) return;
                    
                    const hash = 'ai_' + msgHash(text);
                    if (seenMessages.has(hash)) return;
                    seenMessages.add(hash);
                    
                    try {{
                        window.UDACBridge.onPlatformAiMessageDetected(text);
                    }} catch(e) {{
                        console.log('[UDAC] Bridge not ready:', e);
                    }}
                }});
            }}, 500); // Wait 500ms for message to complete
        }});
        
        observer.observe(document.body, {{ 
            childList: true, 
            subtree: true,
            characterData: true
        }});
        console.log('[UDAC] AI message observer started');
    }}
    
    // 3. Observe Live Transcripts (Voice Mode)
    function observeTranscripts() {{
        if (!CONFIG.transcriptSelector) return;
        
        let lastTranscript = '';
        
        const checkTranscript = () => {{
            const el = findFirst(CONFIG.transcriptSelector);
            if (!el) return;
            
            const text = extractText(el);
            if (text && text !== lastTranscript && text.length > 3) {{
                const newText = text.replace(lastTranscript, '').trim();
                if (newText) {{
                    try {{
                        window.UDACBridge.onLiveTranscriptChunkDetected(newText);
                    }} catch(e) {{}}
                }}
                lastTranscript = text;
            }}
        }};
        
        // Poll for transcript changes (more reliable than mutation observer for some platforms)
        setInterval(checkTranscript, 200);
        
        // Also use mutation observer
        const observer = new MutationObserver(checkTranscript);
        const el = findFirst(CONFIG.transcriptSelector);
        if (el) {{
            observer.observe(el, {{ 
                childList: true, 
                subtree: true, 
                characterData: true 
            }});
        }}
        console.log('[UDAC] Transcript observer started');
    }}
    
    // 4. Watch Live Mode Indicator
    function watchLiveIndicator() {{
        if (!CONFIG.liveIndicatorSelector) return;
        
        let lastState = false;
        
        const checkState = () => {{
            const el = findFirst(CONFIG.liveIndicatorSelector);
            if (!el) return;
            
            // Check various indicators of "active" state
            const isActive = (
                el.classList.contains('active') ||
                el.classList.contains('is-live') ||
                el.classList.contains('recording') ||
                el.getAttribute('aria-pressed') === 'true' ||
                el.getAttribute('data-state') === 'active'
            );
            
            if (isActive !== lastState) {{
                lastState = isActive;
                try {{
                    window.UDACBridge.onLiveModeStateChanged(isActive);
                }} catch(e) {{}}
            }}
        }};
        
        // Poll periodically
        setInterval(checkState, 500);
        
        // Also use mutation observer
        const observer = new MutationObserver(checkState);
        const el = findFirst(CONFIG.liveIndicatorSelector);
        if (el) {{
            observer.observe(el, {{ 
                attributes: true, 
                attributeFilter: ['class', 'aria-pressed', 'data-state'] 
            }});
        }}
        console.log('[UDAC] Live indicator observer started');
    }}
    
    // Initialize all observers
    function init() {{
        console.log('[UDAC] Initializing Portal Bridge for {platform.name}');
        
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {{
            document.addEventListener('DOMContentLoaded', () => {{
                observeUserMessages();
                observeAiMessages();
                observeTranscripts();
                watchLiveIndicator();
            }});
        }} else {{
            observeUserMessages();
            observeAiMessages();
            observeTranscripts();
            watchLiveIndicator();
        }}
        
        console.log('[UDAC] Portal Bridge initialized');
    }}
    
    init();
}})();
'''

    @staticmethod
    def build_send_prompt_script(platform: AiWebPlatform, text: str) -> str:
        """Build script to inject and send a prompt."""
        # Escape the text for JavaScript
        escaped_text = text.replace('\\', '\\\\').replace('`', '\\`').replace('$', '\\$')
        
        return f'''
(function() {{
    const text = `{escaped_text}`;
    const inputSelector = `{platform.input_selector}`;
    const sendSelector = `{platform.send_selector or ''}`;
    
    // Find input element (supports fallback lists with "||")
    const parts = (inputSelector || '').split('||').map(s => s.trim()).filter(Boolean);
    let input = null;
    for (const p of (parts.length ? parts : [inputSelector])) { input = document.querySelector(p); if (input) break; }

    if (!input) {{
        console.error('[UDAC] Input element not found:', inputSelector);
        return false;
    }}
    
    // Set value based on element type
    if (input.tagName === 'TEXTAREA' || input.tagName === 'INPUT') {{
        // Standard input/textarea
        input.value = text;
        input.dispatchEvent(new Event('input', {{ bubbles: true }}));
    }} else if (input.contentEditable === 'true' || input.getAttribute('contenteditable') === 'true') {{
        // ContentEditable div (Claude, Gemini, etc.)
        input.innerHTML = '';
        input.textContent = text;
        
        // Trigger React/Vue events
        input.dispatchEvent(new InputEvent('input', {{ 
            bubbles: true, 
            data: text,
            inputType: 'insertText'
        }}));
        
        // Also try setting via execCommand for some frameworks
        input.focus();
        document.execCommand('selectAll', false, null);
        document.execCommand('insertText', false, text);
    }} else {{
        // Fallback
        input.textContent = text;
        input.dispatchEvent(new Event('input', {{ bubbles: true }}));
    }}
    
    // Focus the input
    input.focus();
    
    // Trigger send after a short delay
    setTimeout(() => {{
        if (sendSelector) {{
            const sendParts = (sendSelector || '').split('||').map(s => s.trim()).filter(Boolean);
            let sendBtn = null;
            for (const p of (sendParts.length ? sendParts : [sendSelector])) { sendBtn = document.querySelector(p); if (sendBtn) break; }
            if (sendBtn && !sendBtn.disabled) {{
                sendBtn.click();
                console.log('[UDAC] Send button clicked');
                return true;
            }}
        }}
        
        // Fallback: Try Enter key
        const enterEvent = new KeyboardEvent('keydown', {{
            key: 'Enter',
            code: 'Enter',
            keyCode: 13,
            which: 13,
            bubbles: true
        }});
        input.dispatchEvent(enterEvent);
        console.log('[UDAC] Enter key dispatched');
    }}, 100);
    
    return true;
}})();
'''

    @staticmethod
    def build_get_input_content_script(platform: AiWebPlatform) -> str:
        """Build script to get current input field content."""
        return f'''
(function() {{
    const inputSelector = `{platform.input_selector}`;
    const input = document.querySelector(inputSelector);
    if (!input) return '';
    
    if (input.tagName === 'TEXTAREA' || input.tagName === 'INPUT') {{
        return input.value || '';
    }} else {{
        return input.textContent || input.innerText || '';
    }}
}})();
'''

    @staticmethod
    def build_clear_input_script(platform: AiWebPlatform) -> str:
        """Build script to clear input field."""
        return f'''
(function() {{
    const inputSelector = `{platform.input_selector}`;
    const input = document.querySelector(inputSelector);
    if (!input) return false;
    
    if (input.tagName === 'TEXTAREA' || input.tagName === 'INPUT') {{
        input.value = '';
    }} else {{
        input.innerHTML = '';
        input.textContent = '';
    }}
    input.dispatchEvent(new Event('input', {{ bubbles: true }}));
    return true;
}})();
'''

    @staticmethod
    def build_check_page_ready_script() -> str:
        """Build script to check if page is ready for interaction."""
        return '''
(function() {
    // Check if basic page elements are loaded
    const body = document.body;
    if (!body) return { ready: false, reason: 'no_body' };
    
    // Check for common loading indicators
    const loadingIndicators = document.querySelectorAll(
        '[class*="loading"], [class*="spinner"], [aria-busy="true"]'
    );
    
    const isLoading = Array.from(loadingIndicators).some(el => {
        const style = window.getComputedStyle(el);
        return style.display !== 'none' && style.visibility !== 'hidden';
    });
    
    if (isLoading) return { ready: false, reason: 'loading' };
    
    return { ready: true };
})();
'''
