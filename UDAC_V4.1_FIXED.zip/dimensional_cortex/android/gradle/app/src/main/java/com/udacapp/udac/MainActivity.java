package com.udacapp.udac;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.system.Os;
import android.system.ErrnoException;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.chaquo.python.Kwarg;
import com.chaquo.python.PyException;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "UDAC";
    private Python py;
    private PyObject trinityModule;
    private PyObject trinity;
    
    private TextView statusText;
    private TextView statsText;
    private Button startButton;
    private Button settingsButton;
    
    private Handler handler = new Handler(Looper.getMainLooper());
    private boolean trinityRunning = false;

    public static MainActivity singletonThis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.i(TAG, "onCreate() start");
        super.onCreate(savedInstanceState);
        singletonThis = this;
        
        // Create native Android UI
        createNativeUI();
        
        // Initialize Python in background
        new Thread(() -> {
            initializePython();
        }).start();
        
        Log.i(TAG, "onCreate() complete");
    }
    
    private void createNativeUI() {
        // Main container
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(Color.parseColor("#1a1a2e"));
        
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(dp(20), dp(20), dp(20), dp(20));
        
        // Title
        TextView title = new TextView(this);
        title.setText("⚡ UDAC Continuity Engine");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 24);
        title.setTextColor(Color.parseColor("#00d4aa"));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(5));
        mainLayout.addView(title);
        
        // Subtitle
        TextView subtitle = new TextView(this);
        subtitle.setText("Universal AI Memory Bridge");
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        subtitle.setTextColor(Color.parseColor("#888888"));
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, dp(30));
        mainLayout.addView(subtitle);
        
        // Status card
        LinearLayout statusCard = createCard();
        
        TextView statusLabel = new TextView(this);
        statusLabel.setText("System Status");
        statusLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        statusLabel.setTextColor(Color.WHITE);
        statusLabel.setPadding(0, 0, 0, dp(10));
        statusCard.addView(statusLabel);
        
        statusText = new TextView(this);
        statusText.setText("Initializing Python...");
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        statusText.setTextColor(Color.parseColor("#ffa500"));
        statusCard.addView(statusText);
        
        mainLayout.addView(statusCard);
        
        // Stats card
        LinearLayout statsCard = createCard();
        
        TextView statsLabel = new TextView(this);
        statsLabel.setText("Trinity Stats");
        statsLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        statsLabel.setTextColor(Color.WHITE);
        statsLabel.setPadding(0, 0, 0, dp(10));
        statsCard.addView(statsLabel);
        
        statsText = new TextView(this);
        statsText.setText("Not started");
        statsText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        statsText.setTextColor(Color.parseColor("#888888"));
        statsCard.addView(statsText);
        
        mainLayout.addView(statsCard);
        
        // Start button
        startButton = new Button(this);
        startButton.setText("START TRINITY");
        startButton.setBackgroundColor(Color.parseColor("#00d4aa"));
        startButton.setTextColor(Color.BLACK);
        startButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        startButton.setPadding(dp(20), dp(15), dp(20), dp(15));
        startButton.setEnabled(false);
        
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        btnParams.setMargins(0, dp(20), 0, dp(10));
        startButton.setLayoutParams(btnParams);
        
        startButton.setOnClickListener(v -> startTrinity());
        mainLayout.addView(startButton);
        
        // Accessibility settings button
        settingsButton = new Button(this);
        settingsButton.setText("OPEN ACCESSIBILITY SETTINGS");
        settingsButton.setBackgroundColor(Color.parseColor("#333355"));
        settingsButton.setTextColor(Color.WHITE);
        settingsButton.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        settingsButton.setPadding(dp(20), dp(12), dp(20), dp(12));
        
        LinearLayout.LayoutParams settingsBtnParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        settingsBtnParams.setMargins(0, dp(5), 0, dp(20));
        settingsButton.setLayoutParams(settingsBtnParams);
        
        settingsButton.setOnClickListener(v -> openAccessibilitySettings());
        mainLayout.addView(settingsButton);
        
        // Instructions
        TextView instructions = new TextView(this);
        instructions.setText(
            "Setup Instructions:\n\n" +
            "1. Tap 'Open Accessibility Settings'\n" +
            "2. Find 'UDAC Continuity' and enable it\n" +
            "3. Return here and tap 'Start Trinity'\n" +
            "4. Open ChatGPT, Claude, or Perplexity\n" +
            "5. UDAC will capture conversations automatically"
        );
        instructions.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        instructions.setTextColor(Color.parseColor("#888888"));
        instructions.setPadding(dp(10), dp(10), dp(10), dp(10));
        instructions.setBackgroundColor(Color.parseColor("#252542"));
        mainLayout.addView(instructions);
        
        // Version info
        TextView version = new TextView(this);
        version.setText("UDAC v1.0 • Native UI");
        version.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
        version.setTextColor(Color.parseColor("#666666"));
        version.setGravity(Gravity.CENTER);
        version.setPadding(0, dp(20), 0, 0);
        mainLayout.addView(version);
        
        scrollView.addView(mainLayout);
        setContentView(scrollView);
    }
    
    private LinearLayout createCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(Color.parseColor("#252542"));
        card.setPadding(dp(15), dp(15), dp(15), dp(15));
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        params.setMargins(0, 0, 0, dp(15));
        card.setLayoutParams(params);
        
        return card;
    }
    
    private int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()
        );
    }
    
    private void initializePython() {
        try {
            Log.i(TAG, "Initializing Python...");
            
            if (!Python.isStarted()) {
                AndroidPlatform platform = new AndroidPlatform(this);
                platform.redirectStdioToLogcat();
                Python.start(platform);
            }
            
            py = Python.getInstance();
            Log.i(TAG, "Python started successfully");
            
            // Try to import Trinity modules
            try {
                trinityModule = py.getModule("dimensional_cortex.dimensional_memory_constant_standalone_demo");
                Log.i(TAG, "Trinity module imported");
                
                handler.post(() -> {
                    statusText.setText("✓ Python ready\n✓ Trinity modules loaded");
                    statusText.setTextColor(Color.parseColor("#00d4aa"));
                    startButton.setEnabled(true);
                });
                
            } catch (PyException e) {
                Log.e(TAG, "Trinity import failed: " + e.getMessage());
                handler.post(() -> {
                    statusText.setText("✓ Python ready\n✗ Trinity import failed:\n" + e.getMessage());
                    statusText.setTextColor(Color.parseColor("#ffa500"));
                    startButton.setEnabled(true); // Still allow trying
                });
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Python init failed: " + e.getMessage());
            handler.post(() -> {
                statusText.setText("✗ Python init failed:\n" + e.getMessage());
                statusText.setTextColor(Color.parseColor("#ff6b6b"));
            });
        }
    }
    
    private void startTrinity() {
        if (py == null) {
            Toast.makeText(this, "Python not ready", Toast.LENGTH_SHORT).show();
            return;
        }
        
        startButton.setEnabled(false);
        startButton.setText("STARTING...");
        statusText.setText("Starting Trinity system...");
        statusText.setTextColor(Color.parseColor("#ffa500"));
        
        new Thread(() -> {
            try {
                Log.i(TAG, "Starting Trinity...");
                
                // Start memory system
                PyObject memoryModule = py.getModule("dimensional_cortex.dimensional_memory_constant_standalone_demo");
                PyObject result = memoryModule.callAttr("start_memory_system");
                Log.i(TAG, "Memory system started");
                
                // Start UDAC listener
                try {
                    PyObject udacModule = py.getModule("dimensional_cortex.udac_listener");
                    udacModule.callAttr("start_udac_listener", 7013);
                    Log.i(TAG, "UDAC listener started on port 7013");
                } catch (Exception e) {
                    Log.w(TAG, "UDAC listener failed: " + e.getMessage());
                }
                
                trinityRunning = true;
                
                handler.post(() -> {
                    statusText.setText("✓ Trinity ONLINE\n✓ Memory system active\n✓ UDAC listener on port 7013");
                    statusText.setTextColor(Color.parseColor("#00d4aa"));
                    startButton.setText("TRINITY RUNNING");
                    startButton.setBackgroundColor(Color.parseColor("#00aa88"));
                    statsText.setText("Waiting for conversations...");
                    
                    // Start stats update loop
                    startStatsUpdater();
                });
                
            } catch (Exception e) {
                Log.e(TAG, "Trinity start failed: " + e.getMessage());
                e.printStackTrace();
                
                handler.post(() -> {
                    statusText.setText("✗ Trinity start failed:\n" + e.getMessage());
                    statusText.setTextColor(Color.parseColor("#ff6b6b"));
                    startButton.setText("RETRY");
                    startButton.setEnabled(true);
                });
            }
        }).start();
    }
    
    private void startStatsUpdater() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (trinityRunning && py != null) {
                    try {
                        PyObject udacModule = py.getModule("dimensional_cortex.udac_listener");
                        PyObject stats = udacModule.callAttr("get_udac_stats");
                        
                        int totalEvents = stats.callAttr("get", "total_events").toInt();
                        String lastSource = "";
                        PyObject lastSourceObj = stats.callAttr("get", "last_source");
                        if (lastSourceObj != null && !lastSourceObj.toString().equals("None")) {
                            lastSource = lastSourceObj.toString();
                        }
                        
                        String statsStr = "Events captured: " + totalEvents;
                        if (!lastSource.isEmpty()) {
                            statsStr += "\nLast source: " + lastSource;
                        }
                        
                        final String finalStats = statsStr;
                        handler.post(() -> statsText.setText(finalStats));
                        
                    } catch (Exception e) {
                        Log.w(TAG, "Stats update failed: " + e.getMessage());
                    }
                    
                    handler.postDelayed(this, 2000);
                }
            }
        }, 2000);
    }
    
    private void openAccessibilitySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Go to Settings → Accessibility → UDAC", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        trinityRunning = false;
        Log.i(TAG, "MainActivity destroyed");
    }
}
