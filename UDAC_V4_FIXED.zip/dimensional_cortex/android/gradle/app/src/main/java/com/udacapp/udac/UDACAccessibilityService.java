package com.udacapp.udac;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

/**
 * UDAC Accessibility Service - Simplified & Crash-Proof
 * ======================================================
 * 
 * This service monitors AI chat apps and captures conversations.
 * It sends events to the Python backend via HTTP POST to localhost.
 */
public class UDACAccessibilityService extends AccessibilityService {

    private static final String TAG = "UDAC";
    private static final String EVENT_ENDPOINT = "http://127.0.0.1:7013/udac/event";
    
    // Target packages to monitor
    private static final Set<String> TARGET_PACKAGES = new HashSet<>();
    static {
        TARGET_PACKAGES.add("com.openai.chatgpt");
        TARGET_PACKAGES.add("com.anthropic.claude");
        TARGET_PACKAGES.add("ai.perplexity.app.android");
        TARGET_PACKAGES.add("ai.perplexity.app");
        TARGET_PACKAGES.add("com.google.android.apps.bard");
        TARGET_PACKAGES.add("com.google.android.apps.gemini");
        TARGET_PACKAGES.add("com.microsoft.bing");
        TARGET_PACKAGES.add("com.microsoft.copilot");
        TARGET_PACKAGES.add("com.quora.poe");
    }
    
    private static final Map<String, String> PLATFORM_NAMES = new HashMap<>();
    static {
        PLATFORM_NAMES.put("com.openai.chatgpt", "ChatGPT");
        PLATFORM_NAMES.put("com.anthropic.claude", "Claude");
        PLATFORM_NAMES.put("ai.perplexity.app.android", "Perplexity");
        PLATFORM_NAMES.put("ai.perplexity.app", "Perplexity");
        PLATFORM_NAMES.put("com.google.android.apps.bard", "Gemini");
        PLATFORM_NAMES.put("com.google.android.apps.gemini", "Gemini");
        PLATFORM_NAMES.put("com.microsoft.bing", "Copilot");
        PLATFORM_NAMES.put("com.microsoft.copilot", "Copilot");
        PLATFORM_NAMES.put("com.quora.poe", "Poe");
    }
    
    private ExecutorService executor;
    private Handler mainHandler;
    
    // State tracking
    private String currentPackage = "";
    private String lastCapturedHash = "";
    private long lastCaptureTime = 0;
    
    private static final long DEBOUNCE_MS = 500;
    
    // Stats
    private int captureCount = 0;
    
    // Static reference for status checking
    private static UDACAccessibilityService instance;
    private static boolean isRunning = false;

    public static boolean isServiceRunning() {
        return isRunning && instance != null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        
        try {
            executor = Executors.newSingleThreadExecutor();
            mainHandler = new Handler(Looper.getMainLooper());
            
            Log.i(TAG, "════════════════════════════════════════");
            Log.i(TAG, "  UDAC ACCESSIBILITY SERVICE CREATED");
            Log.i(TAG, "════════════════════════════════════════");
        } catch (Exception e) {
            Log.e(TAG, "onCreate error: " + e.getMessage());
        }
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        
        try {
            // Configure the service
            AccessibilityServiceInfo info = getServiceInfo();
            if (info == null) {
                info = new AccessibilityServiceInfo();
            }
            
            // Listen for these event types
            info.eventTypes = AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                    | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
            
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS;
            info.notificationTimeout = 100;
            
            setServiceInfo(info);
            
            isRunning = true;
            
            Log.i(TAG, "════════════════════════════════════════");
            Log.i(TAG, "  UDAC SERVICE CONNECTED & READY");
            Log.i(TAG, "  Monitoring: ChatGPT, Claude, Perplexity");
            Log.i(TAG, "════════════════════════════════════════");
            
            // Send startup event
            sendEvent("UDAC_SERVICE", "Service connected and ready", "startup");
            
        } catch (Exception e) {
            Log.e(TAG, "onServiceConnected error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        
        try {
            CharSequence pkgSeq = event.getPackageName();
            if (pkgSeq == null) return;
            
            String packageName = pkgSeq.toString();
            
            // Only process target apps
            if (!TARGET_PACKAGES.contains(packageName)) {
                return;
            }
            
            currentPackage = packageName;
            String platform = PLATFORM_NAMES.getOrDefault(packageName, packageName);
            
            // Extract text from the event
            String text = extractText(event);
            if (text == null || text.trim().length() < 3) {
                return;
            }
            
            // Debounce to avoid duplicate captures
            String hash = String.valueOf(text.hashCode());
            long now = System.currentTimeMillis();
            if (hash.equals(lastCapturedHash) && (now - lastCaptureTime) < DEBOUNCE_MS) {
                return;
            }
            lastCapturedHash = hash;
            lastCaptureTime = now;
            
            // Log and send
            captureCount++;
            Log.d(TAG, "📥 [" + platform + "] #" + captureCount + ": " + truncate(text, 60));
            
            sendEvent(platform, text, getEventTypeName(event.getEventType()));
            
        } catch (Exception e) {
            Log.e(TAG, "Event processing error: " + e.getMessage());
        }
    }

    private String extractText(AccessibilityEvent event) {
        StringBuilder sb = new StringBuilder();
        
        try {
            // Get text from event
            if (event.getText() != null) {
                for (CharSequence t : event.getText()) {
                    if (t != null && t.length() > 0) {
                        sb.append(t).append(" ");
                    }
                }
            }
            
            // Get text from source node
            AccessibilityNodeInfo source = event.getSource();
            if (source != null) {
                try {
                    CharSequence text = source.getText();
                    if (text != null && text.length() > 0) {
                        if (sb.length() > 0) sb.append(" ");
                        sb.append(text);
                    }
                    
                    // Also check content description
                    CharSequence desc = source.getContentDescription();
                    if (desc != null && desc.length() > 0) {
                        if (sb.length() > 0) sb.append(" ");
                        sb.append(desc);
                    }
                } finally {
                    source.recycle();
                }
            }
        } catch (Exception e) {
            Log.w(TAG, "Text extraction error: " + e.getMessage());
        }
        
        return sb.toString().trim();
    }

    private void sendEvent(String platform, String text, String eventType) {
        if (executor == null || executor.isShutdown()) {
            return;
        }
        
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject payload = new JSONObject();
                payload.put("source_app", platform);
                payload.put("text", text);
                payload.put("event_type", eventType);
                payload.put("timestamp", System.currentTimeMillis());
                payload.put("capture_count", captureCount);
                
                URL url = new URL(EVENT_ENDPOINT);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);
                conn.setConnectTimeout(3000);
                conn.setReadTimeout(3000);
                
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
                }
                
                int responseCode = conn.getResponseCode();
                if (responseCode == 200) {
                    Log.d(TAG, "✓ Event sent successfully");
                } else {
                    Log.w(TAG, "Event send got response: " + responseCode);
                }
                
            } catch (Exception e) {
                // Backend might not be running - this is OK
                Log.d(TAG, "Event send failed (backend may not be running): " + e.getMessage());
            } finally {
                if (conn != null) {
                    try {
                        conn.disconnect();
                    } catch (Exception ignored) {}
                }
            }
        });
    }

    private String getEventTypeName(int eventType) {
        switch (eventType) {
            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                return "text_changed";
            case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
                return "content_changed";
            case AccessibilityEvent.TYPE_VIEW_CLICKED:
                return "clicked";
            case AccessibilityEvent.TYPE_VIEW_FOCUSED:
                return "focused";
            default:
                return "event_" + eventType;
        }
    }

    private String truncate(String s, int max) {
        if (s == null) return "(null)";
        s = s.replace("\n", " ").replace("\r", "");
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    @Override
    public void onInterrupt() {
        Log.w(TAG, "Service interrupted");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        instance = null;
        
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
        
        Log.i(TAG, "════════════════════════════════════════");
        Log.i(TAG, "  UDAC SERVICE DESTROYED");
        Log.i(TAG, "  Total captures: " + captureCount);
        Log.i(TAG, "════════════════════════════════════════");
    }
}
