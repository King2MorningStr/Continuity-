package com.udacapp.udac;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

// Direct Chaquopy imports - no reflection needed!
import com.chaquo.python.Python;
import com.chaquo.python.PyObject;
import com.chaquo.python.android.AndroidPlatform;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

/**
 * UDAC Main Activity V5.4
 * ========================
 * 
 * Native Android UI with proper Chaquopy Python backend.
 * Uses direct imports instead of reflection.
 */
public class MainActivity extends Activity {

    private static final String TAG = "UDAC_Main";
    private static final String PREFS_NAME = "udac_prefs";
    
    // Colors
    private static final int COLOR_BG = 0xFF0f0c29;
    private static final int COLOR_CARD = 0xFF1f1d2e;
    private static final int COLOR_ACCENT = 0xFF667eea;
    private static final int COLOR_TEXT = 0xFFe0e0e0;
    private static final int COLOR_TEXT_DIM = 0xFFa0a0a0;
    private static final int COLOR_SUCCESS = 0xFF10a37f;
    private static final int COLOR_WARNING = 0xFFf59e0b;
    private static final int COLOR_ERROR = 0xFFef4444;
    
    // UI Elements
    private TextView statusAccessibility;
    private TextView statusIME;
    private TextView statusBackend;
    private TextView statsCaptures;
    private TextView statsInjections;
    private TextView lastActivityText;
    
    // Injection Preview UI
    private TextView injectionTagLabel;
    private TextView injectionPreviewText;
    private boolean injectionExpanded = false;
    private String currentPendingContext = "";
    
    private Switch switchInjection;
    private Switch switchInvisible;
    private SeekBar seekThreshold;
    private TextView thresholdValue;
    private Button btnForceInject;
    
    // State
    private SharedPreferences prefs;
    private Handler handler;
    private ExecutorService executor;
    private boolean isRunning = false;
    private boolean pythonStarted = false;
    private String pythonError = null;
    
    // Settings
    private boolean injectionEnabled = true;
    private boolean invisibleMode = true;
    private float injectionThreshold = 0.5f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        Log.i(TAG, "════════════════════════════════════════");
        Log.i(TAG, "  UDAC V5.4 STARTING");
        Log.i(TAG, "════════════════════════════════════════");
        
        try {
            prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            handler = new Handler(Looper.getMainLooper());
            executor = Executors.newFixedThreadPool(2);
            
            // Load saved settings
            loadSettings();
            
            // Build UI FIRST
            setContentView(buildUI());
            
            Log.i(TAG, "UI built successfully");
            
            // Start Python backend
            startPythonBackend();
            
            // Start status updates
            startStatusUpdates();
            
            Log.i(TAG, "onCreate completed successfully");
            
        } catch (Exception e) {
            Log.e(TAG, "onCreate error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Start Python backend using Chaquopy directly
     */
    private void startPythonBackend() {
        executor.execute(() -> {
            try {
                Log.i(TAG, "Starting Python backend...");
                
                // Initialize Python if not started
                if (!Python.isStarted()) {
                    Log.d(TAG, "Initializing Python...");
                    Python.start(new AndroidPlatform(this));
                }
                
                Python py = Python.getInstance();
                Log.d(TAG, "Python instance obtained");
                
                // Import and start our backend module
                PyObject mainModule = py.getModule("dimensional_cortex.main");
                Log.d(TAG, "Main module imported");
                
                // Call start_backend()
                mainModule.callAttr("start_backend");
                
                pythonStarted = true;
                pythonError = null;
                Log.i(TAG, "✅ Python backend started successfully");
                
                handler.post(() -> {
                    if (statusBackend != null) {
                        statusBackend.setText("● RUNNING");
                        statusBackend.setTextColor(COLOR_SUCCESS);
                    }
                });
                
            } catch (Exception e) {
                pythonError = e.getMessage();
                pythonStarted = false;
                Log.e(TAG, "Python startup error: " + e.getMessage());
                e.printStackTrace();
                
                handler.post(() -> {
                    if (statusBackend != null) {
                        statusBackend.setText("✗ " + (pythonError != null ? pythonError : "Error"));
                        statusBackend.setTextColor(COLOR_ERROR);
                    }
                });
            }
        });
    }

    private void loadSettings() {
        injectionEnabled = prefs.getBoolean("injection_enabled", true);
        invisibleMode = prefs.getBoolean("invisible_mode", true);
        injectionThreshold = prefs.getFloat("threshold", 0.5f);
    }

    private void saveSettings() {
        prefs.edit()
            .putBoolean("injection_enabled", injectionEnabled)
            .putBoolean("invisible_mode", invisibleMode)
            .putFloat("threshold", injectionThreshold)
            .apply();
        
        // Update accessibility service if running
        UDACAccessibilityService service = UDACAccessibilityService.getInstance();
        if (service != null) {
            service.updateSettings(injectionEnabled, invisibleMode, injectionThreshold);
        }
    }

    private View buildUI() {
        // Root ScrollView
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(COLOR_BG);
        scrollView.setFillViewport(true);
        
        // Main container
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(16), dp(16), dp(16), dp(16));
        
        // ════════════════════════════════════════════════════════════════
        // HEADER
        // ════════════════════════════════════════════════════════════════
        
        TextView title = new TextView(this);
        title.setText("⚡ UDAC V5");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        title.setTextColor(COLOR_ACCENT);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        main.addView(title);
        
        TextView subtitle = new TextView(this);
        subtitle.setText("Universal AI Continuity with Injection");
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        subtitle.setTextColor(COLOR_TEXT_DIM);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, dp(20));
        main.addView(subtitle);
        
        // ════════════════════════════════════════════════════════════════
        // STATUS CARD
        // ════════════════════════════════════════════════════════════════
        
        LinearLayout statusCard = createCard("Service Status");
        
        statusAccessibility = addStatusRow(statusCard, "Accessibility Service", "Checking...");
        statusIME = addStatusRow(statusCard, "Ghost Keyboard (IME)", "Checking...");
        statusBackend = addStatusRow(statusCard, "Python Backend", "Starting...");
        
        main.addView(statusCard);
        
        // ════════════════════════════════════════════════════════════════
        // INJECTION CONTROLS CARD
        // ════════════════════════════════════════════════════════════════
        
        LinearLayout controlsCard = createCard("Injection Controls");
        
        // Injection ON/OFF
        LinearLayout injectionRow = new LinearLayout(this);
        injectionRow.setOrientation(LinearLayout.HORIZONTAL);
        injectionRow.setPadding(0, dp(8), 0, dp(8));
        
        TextView injectionLabel = new TextView(this);
        injectionLabel.setText("Enable Injection");
        injectionLabel.setTextColor(COLOR_TEXT);
        injectionLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        injectionLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        injectionRow.addView(injectionLabel);
        
        switchInjection = new Switch(this);
        switchInjection.setChecked(injectionEnabled);
        switchInjection.setOnCheckedChangeListener((btn, checked) -> {
            injectionEnabled = checked;
            saveSettings();
            updateControlsUI();
            toast(checked ? "Injection enabled" : "Injection disabled");
        });
        injectionRow.addView(switchInjection);
        controlsCard.addView(injectionRow);
        
        // Invisible Mode
        LinearLayout invisibleRow = new LinearLayout(this);
        invisibleRow.setOrientation(LinearLayout.HORIZONTAL);
        invisibleRow.setPadding(0, dp(8), 0, dp(8));
        
        TextView invisibleLabel = new TextView(this);
        invisibleLabel.setText("Invisible Mode");
        invisibleLabel.setTextColor(COLOR_TEXT);
        invisibleLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        invisibleLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        invisibleRow.addView(invisibleLabel);
        
        switchInvisible = new Switch(this);
        switchInvisible.setChecked(invisibleMode);
        switchInvisible.setOnCheckedChangeListener((btn, checked) -> {
            invisibleMode = checked;
            saveSettings();
            toast(checked ? "Context hidden" : "Context visible");
        });
        invisibleRow.addView(switchInvisible);
        controlsCard.addView(invisibleRow);
        
        TextView invisibleHint = new TextView(this);
        invisibleHint.setText("When ON, context uses HTML comments");
        invisibleHint.setTextColor(COLOR_TEXT_DIM);
        invisibleHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        invisibleHint.setPadding(0, 0, 0, dp(12));
        controlsCard.addView(invisibleHint);
        
        // Threshold Slider
        TextView thresholdLabel = new TextView(this);
        thresholdLabel.setText("Relevance Threshold");
        thresholdLabel.setTextColor(COLOR_TEXT);
        thresholdLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        thresholdLabel.setPadding(0, dp(8), 0, dp(4));
        controlsCard.addView(thresholdLabel);
        
        LinearLayout thresholdRow = new LinearLayout(this);
        thresholdRow.setOrientation(LinearLayout.HORIZONTAL);
        thresholdRow.setGravity(Gravity.CENTER_VERTICAL);
        
        seekThreshold = new SeekBar(this);
        seekThreshold.setMax(100);
        seekThreshold.setProgress((int)(injectionThreshold * 100));
        seekThreshold.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        seekThreshold.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                injectionThreshold = progress / 100f;
                thresholdValue.setText(String.format("%.0f%%", injectionThreshold * 100));
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                saveSettings();
            }
        });
        thresholdRow.addView(seekThreshold);
        
        thresholdValue = new TextView(this);
        thresholdValue.setText(String.format("%.0f%%", injectionThreshold * 100));
        thresholdValue.setTextColor(COLOR_ACCENT);
        thresholdValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        thresholdValue.setTypeface(null, Typeface.BOLD);
        thresholdValue.setPadding(dp(12), 0, 0, 0);
        thresholdRow.addView(thresholdValue);
        
        controlsCard.addView(thresholdRow);
        
        TextView thresholdHint = new TextView(this);
        thresholdHint.setText("Lower = more injections, Higher = only relevant");
        thresholdHint.setTextColor(COLOR_TEXT_DIM);
        thresholdHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        thresholdHint.setPadding(0, dp(4), 0, dp(12));
        controlsCard.addView(thresholdHint);
        
        // Force Injection Button
        btnForceInject = new Button(this);
        btnForceInject.setText("🔧 FORCE NEXT INJECTION");
        btnForceInject.setTextColor(Color.WHITE);
        btnForceInject.setBackgroundColor(COLOR_WARNING);
        btnForceInject.setPadding(dp(16), dp(12), dp(16), dp(12));
        btnForceInject.setOnClickListener(v -> forceInjection());
        controlsCard.addView(btnForceInject);
        
        main.addView(controlsCard);
        
        // ════════════════════════════════════════════════════════════════
        // STATS CARD
        // ════════════════════════════════════════════════════════════════
        
        LinearLayout statsCard = createCard("Activity");
        
        statsCaptures = addStatusRow(statsCard, "Captures", "0");
        statsInjections = addStatusRow(statsCard, "Injections", "0");
        
        TextView lastActivityLabel = new TextView(this);
        lastActivityLabel.setText("Last Activity:");
        lastActivityLabel.setTextColor(COLOR_TEXT_DIM);
        lastActivityLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        lastActivityLabel.setPadding(0, dp(12), 0, dp(4));
        statsCard.addView(lastActivityLabel);
        
        lastActivityText = new TextView(this);
        lastActivityText.setText("Waiting...");
        lastActivityText.setTextColor(COLOR_TEXT);
        lastActivityText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        statsCard.addView(lastActivityText);
        
        main.addView(statsCard);
        
        // ════════════════════════════════════════════════════════════════
        // INJECTION PREVIEW CARD (Expandable)
        // ════════════════════════════════════════════════════════════════
        
        LinearLayout previewCard = createCard("Pending Injection");
        
        // Tappable header row
        LinearLayout previewHeader = new LinearLayout(this);
        previewHeader.setOrientation(LinearLayout.HORIZONTAL);
        previewHeader.setGravity(Gravity.CENTER_VERTICAL);
        
        injectionTagLabel = new TextView(this);
        injectionTagLabel.setText("▶ [UDAC Continuity]");
        injectionTagLabel.setTextColor(COLOR_ACCENT);
        injectionTagLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        injectionTagLabel.setTypeface(null, Typeface.BOLD);
        injectionTagLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        previewHeader.addView(injectionTagLabel);
        
        TextView tapHint = new TextView(this);
        tapHint.setText("tap to expand");
        tapHint.setTextColor(COLOR_TEXT_DIM);
        tapHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        previewHeader.addView(tapHint);
        
        previewCard.addView(previewHeader);
        
        // Separator line
        View separator = new View(this);
        separator.setBackgroundColor(0xFF333355);
        LinearLayout.LayoutParams sepParams = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
        sepParams.topMargin = dp(8);
        sepParams.bottomMargin = dp(8);
        separator.setLayoutParams(sepParams);
        previewCard.addView(separator);
        
        // Preview text (starts collapsed)
        injectionPreviewText = new TextView(this);
        injectionPreviewText.setText("No context pending...");
        injectionPreviewText.setTextColor(COLOR_TEXT);
        injectionPreviewText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        injectionPreviewText.setMaxLines(2);
        injectionPreviewText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        injectionPreviewText.setLineSpacing(dp(2), 1.0f);
        previewCard.addView(injectionPreviewText);
        
        // Make card tappable for expand/collapse
        previewCard.setOnClickListener(v -> toggleInjectionPreview());
        previewCard.setClickable(true);
        previewCard.setFocusable(true);
        
        main.addView(previewCard);
        
        // ════════════════════════════════════════════════════════════════
        // SETUP BUTTONS
        // ════════════════════════════════════════════════════════════════
        
        LinearLayout setupCard = createCard("Setup");
        
        Button btnAccessibility = createButton("Open Accessibility Settings", COLOR_ACCENT);
        btnAccessibility.setOnClickListener(v -> openAccessibilitySettings());
        setupCard.addView(btnAccessibility);
        
        Button btnKeyboard = createButton("Open Keyboard Settings", COLOR_ACCENT);
        btnKeyboard.setOnClickListener(v -> openKeyboardSettings());
        LinearLayout.LayoutParams kbParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        kbParams.topMargin = dp(8);
        btnKeyboard.setLayoutParams(kbParams);
        setupCard.addView(btnKeyboard);
        
        main.addView(setupCard);
        
        // ════════════════════════════════════════════════════════════════
        // FOOTER
        // ════════════════════════════════════════════════════════════════
        
        TextView footer = new TextView(this);
        footer.setText("UDAC V5.4 • Dimensional Cortex\nPython + Trinity Backend");
        footer.setTextColor(COLOR_TEXT_DIM);
        footer.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(20), 0, dp(20));
        main.addView(footer);
        
        scrollView.addView(main);
        return scrollView;
    }

    private LinearLayout createCard(String title) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_CARD);
        bg.setCornerRadius(dp(12));
        card.setBackground(bg);
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.bottomMargin = dp(16);
        card.setLayoutParams(params);
        
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(COLOR_ACCENT);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        titleView.setTypeface(null, Typeface.BOLD);
        titleView.setPadding(0, 0, 0, dp(12));
        card.addView(titleView);
        
        return card;
    }

    private TextView addStatusRow(LinearLayout parent, String label, String initialValue) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));
        
        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(COLOR_TEXT_DIM);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        labelView.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(labelView);
        
        TextView valueView = new TextView(this);
        valueView.setText(initialValue);
        valueView.setTextColor(COLOR_TEXT);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        valueView.setTypeface(null, Typeface.BOLD);
        row.addView(valueView);
        
        parent.addView(row);
        return valueView;
    }

    private Button createButton(String text, int color) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setAllCaps(false);
        
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(8));
        btn.setBackground(bg);
        
        btn.setPadding(dp(16), dp(14), dp(16), dp(14));
        
        return btn;
    }

    private void updateControlsUI() {
        boolean enabled = injectionEnabled;
        switchInvisible.setEnabled(enabled);
        seekThreshold.setEnabled(enabled);
        btnForceInject.setEnabled(enabled);
        
        float alpha = enabled ? 1.0f : 0.5f;
        switchInvisible.setAlpha(alpha);
        seekThreshold.setAlpha(alpha);
        btnForceInject.setAlpha(alpha);
    }

    private void startStatusUpdates() {
        isRunning = true;
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                updateStatus();
                handler.postDelayed(this, 2000);
            }
        });
    }

    private void updateStatus() {
        try {
            // Accessibility Service status
            boolean accessibilityEnabled = isAccessibilityServiceEnabled();
            statusAccessibility.setText(accessibilityEnabled ? "● RUNNING" : "○ DISABLED");
            statusAccessibility.setTextColor(accessibilityEnabled ? COLOR_SUCCESS : COLOR_ERROR);
            
            // IME status
            boolean imeEnabled = isIMEEnabled();
            statusIME.setText(imeEnabled ? "● ENABLED" : "○ DISABLED");
            statusIME.setTextColor(imeEnabled ? COLOR_SUCCESS : COLOR_WARNING);
            
            // Backend status - check via HTTP
            if (pythonStarted) {
                checkBackendStatus();
            } else if (pythonError != null) {
                statusBackend.setText("✗ " + pythonError);
                statusBackend.setTextColor(COLOR_ERROR);
            }
        } catch (Exception e) {
            Log.e(TAG, "Status update error: " + e.getMessage());
        }
    }

    private boolean isAccessibilityServiceEnabled() {
        try {
            String enabledServices = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            );
            return enabledServices != null && enabledServices.contains(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isIMEEnabled() {
        try {
            String enabledIMEs = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_INPUT_METHODS
            );
            return enabledIMEs != null && enabledIMEs.contains("UDACInputMethodService");
        } catch (Exception e) {
            return false;
        }
    }

    private void checkBackendStatus() {
        executor.execute(() -> {
            boolean connected = false;
            int captures = 0;
            int injections = 0;
            String lastText = "";
            String lastSource = "";
            String pendingContext = "";
            
            try {
                URL url = new URL("http://127.0.0.1:7013/udac/stats");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(1000);
                conn.setReadTimeout(1000);
                
                if (conn.getResponseCode() == 200) {
                    connected = true;
                    
                    java.io.BufferedReader reader = new java.io.BufferedReader(
                        new java.io.InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                    }
                    reader.close();
                    
                    JSONObject stats = new JSONObject(sb.toString());
                    captures = stats.optInt("total_events", 0);
                    injections = stats.optInt("total_injections", 0);
                    lastText = stats.optString("last_text", "");
                    lastSource = stats.optString("last_source", "");
                    pendingContext = stats.optString("pending_context", "");
                }
                conn.disconnect();
            } catch (Exception e) {
                // Not connected
            }
            
            final boolean isConnected = connected;
            final int finalCaptures = captures;
            final int finalInjections = injections;
            final String finalLastText = lastText;
            final String finalLastSource = lastSource;
            final String finalPendingContext = pendingContext;
            
            handler.post(() -> {
                if (statusBackend != null) {
                    statusBackend.setText(isConnected ? "● CONNECTED" : "● RUNNING (no HTTP)");
                    statusBackend.setTextColor(isConnected ? COLOR_SUCCESS : COLOR_WARNING);
                }
                
                if (statsCaptures != null) statsCaptures.setText(String.valueOf(finalCaptures));
                if (statsInjections != null) statsInjections.setText(String.valueOf(finalInjections));
                
                if (lastActivityText != null && finalLastSource != null && !finalLastSource.isEmpty()) {
                    String snippet = finalLastText;
                    if (snippet.length() > 50) {
                        snippet = snippet.substring(0, 50) + "...";
                    }
                    lastActivityText.setText(finalLastSource + ": " + snippet);
                }
                
                // Update injection preview
                updateInjectionPreview(finalPendingContext);
            });
        });
    }

    private void forceInjection() {
        UDACAccessibilityService service = UDACAccessibilityService.getInstance();
        if (service != null) {
            service.forceInjection();
            toast("Force injection enabled");
        } else {
            toast("Accessibility service not running");
        }
    }

    private void openAccessibilitySettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
        } catch (Exception e) {
            toast("Cannot open settings");
        }
    }

    private void openKeyboardSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS);
            startActivity(intent);
        } catch (Exception e) {
            toast("Cannot open settings");
        }
    }

    private void toast(String message) {
        try {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Log.e(TAG, "Toast error: " + e.getMessage());
        }
    }
    
    /**
     * Toggle the injection preview between collapsed (2 lines) and expanded (full)
     */
    private void toggleInjectionPreview() {
        injectionExpanded = !injectionExpanded;
        
        if (injectionExpanded) {
            // Expand - show full context
            injectionTagLabel.setText("▼ [UDAC Continuity]");
            injectionPreviewText.setMaxLines(50);
            injectionPreviewText.setEllipsize(null);
            
            // Show full context
            if (currentPendingContext != null && !currentPendingContext.isEmpty()) {
                injectionPreviewText.setText(currentPendingContext);
            }
        } else {
            // Collapse - show preview only
            injectionTagLabel.setText("▶ [UDAC Continuity]");
            injectionPreviewText.setMaxLines(2);
            injectionPreviewText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        }
    }
    
    /**
     * Update injection preview with current pending context
     */
    private void updateInjectionPreview(String context) {
        currentPendingContext = context;
        
        handler.post(() -> {
            if (injectionPreviewText != null) {
                if (context == null || context.isEmpty()) {
                    injectionPreviewText.setText("No context pending...");
                    injectionPreviewText.setTextColor(COLOR_TEXT_DIM);
                } else {
                    injectionPreviewText.setText(context);
                    injectionPreviewText.setTextColor(COLOR_TEXT);
                }
            }
        });
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isRunning = false;
        if (executor != null && !executor.isShutdown()) {
            executor.shutdown();
        }
    }
}
