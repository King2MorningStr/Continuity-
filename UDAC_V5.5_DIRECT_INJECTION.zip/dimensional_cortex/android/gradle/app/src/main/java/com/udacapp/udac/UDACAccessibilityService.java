package com.udacapp.udac;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

/**
 * UDAC Accessibility Service V5.5
 * ================================
 * 
 * DIRECT INJECTION via Accessibility APIs - no IME switching needed!
 * 
 * New approach:
 * 1. Monitor text input fields in AI chat apps
 * 2. When user pauses typing, fetch context from Python backend
 * 3. Use AccessibilityNodeInfo.ACTION_SET_TEXT to inject context
 * 4. Context is prepended invisibly before user's message
 * 
 * This is MUCH more reliable than the IME approach!
 */
public class UDACAccessibilityService extends AccessibilityService {

    private static final String TAG = "UDAC";
    private static final String EVENT_ENDPOINT = "http://127.0.0.1:7013/udac/event";
    private static final String CONTEXT_ENDPOINT = "http://127.0.0.1:7013/udac/context";
    private static final String SETTINGS_ENDPOINT = "http://127.0.0.1:7013/udac/settings";
    
    // Target packages to monitor
    private static final Set<String> TARGET_PACKAGES = new HashSet<>();
    static {
        TARGET_PACKAGES.add("com.openai.chatgpt");
        TARGET_PACKAGES.add("com.anthropic.claude");
        TARGET_PACKAGES.add("ai.perplexity.app.android");
        TARGET_PACKAGES.add("ai.perplexity.app");
        TARGET_PACKAGES.add("com.google.android.apps.bard");
        TARGET_PACKAGES.add("com.google.android.apps.gemini");
        TARGET_PACKAGES.add("com.microsoft.bing");
        TARGET_PACKAGES.add("com.microsoft.copilot");
        TARGET_PACKAGES.add("com.quora.poe");
    }
    
    private static final Map<String, String> PLATFORM_NAMES = new HashMap<>();
    static {
        PLATFORM_NAMES.put("com.openai.chatgpt", "ChatGPT");
        PLATFORM_NAMES.put("com.anthropic.claude", "Claude");
        PLATFORM_NAMES.put("ai.perplexity.app.android", "Perplexity");
        PLATFORM_NAMES.put("ai.perplexity.app", "Perplexity");
        PLATFORM_NAMES.put("com.google.android.apps.bard", "Gemini");
        PLATFORM_NAMES.put("com.google.android.apps.gemini", "Gemini");
        PLATFORM_NAMES.put("com.microsoft.bing", "Copilot");
        PLATFORM_NAMES.put("com.microsoft.copilot", "Copilot");
        PLATFORM_NAMES.put("com.quora.poe", "Poe");
    }
    
    private ExecutorService executor;
    private Handler mainHandler;
    
    // State tracking
    private String currentPackage = "";
    private String lastUserMessage = "";
    private String lastCapturedHash = "";
    private long lastCaptureTime = 0;
    private long lastInjectionTime = 0;
    private AccessibilityNodeInfo lastInputField = null;
    private boolean contextInjected = false;
    
    private static final long DEBOUNCE_MS = 500;
    private static final long INJECTION_COOLDOWN_MS = 5000;
    private static final long TYPING_PAUSE_MS = 1500; // Inject after user pauses typing
    
    // Stats
    private int captureCount = 0;
    private int sendDetections = 0;
    private int injectionCount = 0;
    
    // Settings
    private boolean injectionEnabled = true;
    private boolean invisibleMode = true;
    private float injectionThreshold = 0.5f;
    private boolean forceNextInjection = false;
    
    // Floating inject button
    private View floatingButton;
    private WindowManager windowManager;
    private boolean floatingButtonVisible = false;
    
    // Static instance
    private static UDACAccessibilityService instance;
    private static boolean isRunning = false;

    public static boolean isServiceRunning() {
        return isRunning && instance != null;
    }
    
    public static UDACAccessibilityService getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        
        try {
            executor = Executors.newFixedThreadPool(2);
            mainHandler = new Handler(Looper.getMainLooper());
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            
            Log.i(TAG, "════════════════════════════════════════");
            Log.i(TAG, "  UDAC V5.5 - DIRECT INJECTION");
            Log.i(TAG, "  No IME switching required!");
            Log.i(TAG, "════════════════════════════════════════");
        } catch (Exception e) {
            Log.e(TAG, "onCreate error: " + e.getMessage());
        }
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        
        try {
            AccessibilityServiceInfo info = getServiceInfo();
            if (info == null) {
                info = new AccessibilityServiceInfo();
            }
            
            // Listen for text changes, clicks, and focus
            info.eventTypes = AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED
                    | AccessibilityEvent.TYPE_VIEW_CLICKED
                    | AccessibilityEvent.TYPE_VIEW_FOCUSED
                    | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
            
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                    | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
                    | AccessibilityServiceInfo.FLAG_INPUT_METHOD_EDITOR;
            info.notificationTimeout = 50;
            
            setServiceInfo(info);
            isRunning = true;
            
            Log.i(TAG, "════════════════════════════════════════");
            Log.i(TAG, "  SERVICE CONNECTED & READY");
            Log.i(TAG, "  Direct Injection: ENABLED");
            Log.i(TAG, "════════════════════════════════════════");
            
            syncSettings();
            sendEvent("UDAC_SERVICE", "V5.5 connected - Direct Injection", "startup");
            
        } catch (Exception e) {
            Log.e(TAG, "onServiceConnected error: " + e.getMessage());
        }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        
        try {
            CharSequence pkgSeq = event.getPackageName();
            if (pkgSeq == null) return;
            
            String packageName = pkgSeq.toString();
            
            // Only process target apps
            if (!TARGET_PACKAGES.contains(packageName)) {
                hideFloatingButton();
                return;
            }
            
            currentPackage = packageName;
            int eventType = event.getEventType();
            
            switch (eventType) {
                case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                    handleTextChange(event, packageName);
                    break;
                    
                case AccessibilityEvent.TYPE_VIEW_CLICKED:
                    handleClick(event, packageName);
                    break;
                    
                case AccessibilityEvent.TYPE_VIEW_FOCUSED:
                    handleFocus(event, packageName);
                    break;
                    
                case AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED:
                    handleContentChange(event, packageName);
                    break;
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Event error: " + e.getMessage());
        }
    }

    /**
     * Track text being typed and schedule injection
     */
    private void handleTextChange(AccessibilityEvent event, String packageName) {
        AccessibilityNodeInfo source = event.getSource();
        if (source == null) return;
        
        try {
            if (source.isEditable()) {
                CharSequence text = source.getText();
                if (text != null) {
                    String newText = text.toString();
                    
                    // Check if this is new user input (not our injection)
                    if (!newText.startsWith("<!--CONTINUITY:") && !newText.equals(lastUserMessage)) {
                        lastUserMessage = newText;
                        lastInputField = source;
                        contextInjected = false; // Reset injection flag for new message
                        
                        Log.d(TAG, "📝 User typing: '" + truncate(lastUserMessage, 50) + "'");
                        
                        // Show floating inject button if enabled
                        if (injectionEnabled && lastUserMessage.length() > 10) {
                            showFloatingButton();
                        }
                        
                        // Schedule auto-injection after pause
                        scheduleAutoInjection(source, packageName);
                    }
                }
                return; // Don't recycle if we're keeping reference
            }
        } catch (Exception e) {
            Log.e(TAG, "Text change error: " + e.getMessage());
        }
        
        source.recycle();
    }

    /**
     * Schedule injection after user pauses typing
     */
    private void scheduleAutoInjection(AccessibilityNodeInfo inputField, String packageName) {
        mainHandler.removeCallbacksAndMessages("auto_inject");
        
        mainHandler.postDelayed(() -> {
            // Only auto-inject if threshold is low or forced
            if (forceNextInjection || injectionThreshold < 0.3) {
                performDirectInjection(inputField, packageName);
            }
        }, TYPING_PAUSE_MS);
    }

    /**
     * Handle focus on input field - show inject button
     */
    private void handleFocus(AccessibilityEvent event, String packageName) {
        AccessibilityNodeInfo source = event.getSource();
        if (source == null) return;
        
        try {
            if (source.isEditable()) {
                lastInputField = source;
                if (injectionEnabled) {
                    showFloatingButton();
                }
                return;
            }
        } catch (Exception e) {
            Log.e(TAG, "Focus error: " + e.getMessage());
        }
        
        source.recycle();
    }

    /**
     * Detect Send button clicks
     */
    private void handleClick(AccessibilityEvent event, String packageName) {
        AccessibilityNodeInfo source = event.getSource();
        if (source == null) return;
        
        try {
            if (isSendButton(source)) {
                sendDetections++;
                String platform = PLATFORM_NAMES.getOrDefault(packageName, packageName);
                
                Log.i(TAG, "════════════════════════════════════════");
                Log.i(TAG, "  🚀 SEND DETECTED #" + sendDetections);
                Log.i(TAG, "  Platform: " + platform);
                Log.i(TAG, "  Injected: " + contextInjected);
                Log.i(TAG, "════════════════════════════════════════");
                
                sendEvent(platform, lastUserMessage, "send_detected");
                
                // Reset for next message
                lastUserMessage = "";
                contextInjected = false;
                hideFloatingButton();
            }
        } finally {
            source.recycle();
        }
    }

    /**
     * THE KEY METHOD: Direct text injection via Accessibility API
     */
    private void performDirectInjection(AccessibilityNodeInfo inputField, String packageName) {
        if (!injectionEnabled) return;
        if (contextInjected) return;
        if (lastUserMessage == null || lastUserMessage.trim().isEmpty()) return;
        
        // Check cooldown
        long now = System.currentTimeMillis();
        if (now - lastInjectionTime < INJECTION_COOLDOWN_MS && !forceNextInjection) {
            Log.d(TAG, "Injection cooldown active");
            return;
        }
        
        String platform = PLATFORM_NAMES.getOrDefault(packageName, packageName);
        
        Log.i(TAG, "════════════════════════════════════════");
        Log.i(TAG, "  💉 DIRECT INJECTION STARTING");
        Log.i(TAG, "  Platform: " + platform);
        Log.i(TAG, "  Message: '" + truncate(lastUserMessage, 40) + "'");
        Log.i(TAG, "════════════════════════════════════════");
        
        // Fetch context from Python backend
        executor.execute(() -> {
            String context = fetchContext(lastUserMessage, platform);
            
            if (context != null && !context.isEmpty()) {
                mainHandler.post(() -> {
                    injectTextDirectly(inputField, context, lastUserMessage);
                });
            } else {
                Log.d(TAG, "No context to inject (below threshold)");
            }
            
            forceNextInjection = false;
        });
    }

    /**
     * Inject text directly into the input field using ACTION_SET_TEXT
     */
    private void injectTextDirectly(AccessibilityNodeInfo inputField, String context, String userMessage) {
        if (inputField == null) {
            Log.e(TAG, "No input field available");
            return;
        }
        
        try {
            // Build the injected message
            String injectedMessage;
            
            if (invisibleMode) {
                // TRULY INVISIBLE: Use zero-width characters + minimal markers
                // LLMs process this text but users barely notice it
                injectedMessage = buildInvisibleContext(context) + userMessage;
            } else {
                // Visible: Clear prefix
                injectedMessage = "[CONTEXT]\n" + context + "\n[/CONTEXT]\n\n" + userMessage;
            }
            
            // Use ACTION_SET_TEXT to replace the text
            Bundle args = new Bundle();
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, injectedMessage);
            
            boolean success = inputField.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
            
            if (success) {
                injectionCount++;
                lastInjectionTime = System.currentTimeMillis();
                contextInjected = true;
                
                Log.i(TAG, "✅ INJECTION #" + injectionCount + " SUCCESS!");
                Log.i(TAG, "   Injected " + injectedMessage.length() + " chars");
                
                // Send stats to backend
                sendEvent(currentPackage, "Injection successful", "injection_complete");
                
                // Brief toast feedback
                mainHandler.post(() -> {
                    try {
                        Toast.makeText(this, "⚡ Context injected", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {}
                });
                
            } else {
                Log.e(TAG, "❌ ACTION_SET_TEXT failed");
                
                // Fallback: Try paste approach
                tryPasteInjection(injectedMessage);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Injection error: " + e.getMessage());
        }
    }

    /**
     * Fallback injection using clipboard paste
     */
    private void tryPasteInjection(String text) {
        try {
            android.content.ClipboardManager clipboard = 
                (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            android.content.ClipData clip = android.content.ClipData.newPlainText("udac", text);
            clipboard.setPrimaryClip(clip);
            
            // Try to paste
            if (lastInputField != null) {
                lastInputField.performAction(AccessibilityNodeInfo.ACTION_PASTE);
                Log.i(TAG, "Fallback paste attempted");
            }
        } catch (Exception e) {
            Log.e(TAG, "Paste fallback failed: " + e.getMessage());
        }
    }

    /**
     * Fetch context from Python backend
     */
    private String fetchContext(String userMessage, String platform) {
        HttpURLConnection conn = null;
        try {
            JSONObject request = new JSONObject();
            request.put("user_message", userMessage);
            request.put("platform", platform);
            request.put("threshold", forceNextInjection ? 0.0f : injectionThreshold);
            request.put("forced", forceNextInjection);
            
            URL url = new URL(CONTEXT_ENDPOINT);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            conn.setDoOutput(true);
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            
            try (OutputStream os = conn.getOutputStream()) {
                os.write(request.toString().getBytes(StandardCharsets.UTF_8));
            }
            
            if (conn.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                
                JSONObject json = new JSONObject(response.toString());
                
                if (json.optBoolean("inject", false)) {
                    return json.optString("context", "");
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Context fetch error: " + e.getMessage());
        } finally {
            if (conn != null) conn.disconnect();
        }
        
        return null;
    }

    /**
     * Show floating inject button
     */
    private void showFloatingButton() {
        if (floatingButtonVisible) return;
        if (!Settings.canDrawOverlays(this)) {
            Log.w(TAG, "No overlay permission for floating button");
            return;
        }
        
        mainHandler.post(() -> {
            try {
                if (floatingButton == null) {
                    Button btn = new Button(this);
                    btn.setText("⚡");
                    btn.setTextSize(20);
                    btn.setBackgroundColor(0xFF667eea);
                    btn.setTextColor(0xFFFFFFFF);
                    btn.setAlpha(0.9f);
                    
                    btn.setOnClickListener(v -> {
                        Log.i(TAG, "Floating button clicked - forcing injection");
                        forceNextInjection = true;
                        if (lastInputField != null) {
                            performDirectInjection(lastInputField, currentPackage);
                        }
                    });
                    
                    floatingButton = btn;
                }
                
                WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    120, 120,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
                );
                params.gravity = Gravity.END | Gravity.CENTER_VERTICAL;
                params.x = 20;
                
                windowManager.addView(floatingButton, params);
                floatingButtonVisible = true;
                
            } catch (Exception e) {
                Log.e(TAG, "Floating button error: " + e.getMessage());
            }
        });
    }

    /**
     * Hide floating inject button
     */
    private void hideFloatingButton() {
        if (!floatingButtonVisible) return;
        
        mainHandler.post(() -> {
            try {
                if (floatingButton != null && floatingButton.getParent() != null) {
                    windowManager.removeView(floatingButton);
                }
                floatingButtonVisible = false;
            } catch (Exception e) {}
        });
    }

    /**
     * Capture AI responses
     */
    private void handleContentChange(AccessibilityEvent event, String packageName) {
        String text = extractText(event);
        if (text == null || text.trim().length() < 10) return;
        
        // Debounce
        String hash = String.valueOf(text.hashCode());
        long now = System.currentTimeMillis();
        if (hash.equals(lastCapturedHash) && (now - lastCaptureTime) < DEBOUNCE_MS) {
            return;
        }
        lastCapturedHash = hash;
        lastCaptureTime = now;
        
        // Skip user's own message
        if (lastUserMessage != null && !lastUserMessage.isEmpty() && text.contains(lastUserMessage)) {
            return;
        }
        
        // Skip injected content
        if (text.contains("<!--CONTINUITY:") || text.contains("[CONTEXT]")) {
            return;
        }
        
        captureCount++;
        String platform = PLATFORM_NAMES.getOrDefault(packageName, packageName);
        Log.d(TAG, "📥 Capture #" + captureCount + " from " + platform);
        
        sendEvent(platform, text, "content_captured");
    }

    private boolean isSendButton(AccessibilityNodeInfo node) {
        if (node == null) return false;
        
        String viewId = node.getViewIdResourceName();
        CharSequence contentDesc = node.getContentDescription();
        CharSequence text = node.getText();
        
        if (viewId != null) {
            String id = viewId.toLowerCase();
            if (id.contains("send") || id.contains("submit") || id.contains("post") ||
                id.contains("composer_send") || id.contains("btn_send")) {
                return true;
            }
        }
        
        if (contentDesc != null) {
            String desc = contentDesc.toString().toLowerCase();
            if (desc.contains("send") || desc.contains("submit")) {
                return true;
            }
        }
        
        if (text != null) {
            String t = text.toString().toLowerCase().trim();
            if (t.equals("send") || t.equals("submit")) {
                return true;
            }
        }
        
        return false;
    }

    private String extractText(AccessibilityEvent event) {
        StringBuilder sb = new StringBuilder();
        
        try {
            if (event.getText() != null) {
                for (CharSequence t : event.getText()) {
                    if (t != null) sb.append(t).append(" ");
                }
            }
        } catch (Exception e) {}
        
        return sb.toString().trim();
    }

    private void sendEvent(String platform, String text, String eventType) {
        if (executor == null || executor.isShutdown()) return;
        
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject payload = new JSONObject();
                payload.put("source_app", platform);
                payload.put("text", text);
                payload.put("event_type", eventType);
                payload.put("timestamp", System.currentTimeMillis());
                
                URL url = new URL(EVENT_ENDPOINT);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(2000);
                
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
                }
                
                conn.getResponseCode();
            } catch (Exception e) {
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private void syncSettings() {
        executor.execute(() -> {
            try {
                URL url = new URL(SETTINGS_ENDPOINT);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(2000);
                
                if (conn.getResponseCode() == 200) {
                    BufferedReader reader = new BufferedReader(
                        new InputStreamReader(conn.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) sb.append(line);
                    reader.close();
                    
                    JSONObject settings = new JSONObject(sb.toString());
                    injectionEnabled = settings.optBoolean("injection_enabled", true);
                    invisibleMode = settings.optBoolean("invisible_mode", true);
                    injectionThreshold = (float) settings.optDouble("threshold", 0.5);
                }
                conn.disconnect();
            } catch (Exception e) {}
        });
    }

    public void updateSettings(boolean enabled, boolean invisible, float threshold) {
        this.injectionEnabled = enabled;
        this.invisibleMode = invisible;
        this.injectionThreshold = threshold;
    }

    public void forceInjection() {
        forceNextInjection = true;
        if (lastInputField != null && currentPackage != null) {
            performDirectInjection(lastInputField, currentPackage);
        }
    }

    /**
     * Build invisible context with user-friendly tag.
     * 
     * User sees: [UDAC Continuity]
     * LLM receives: Hidden context encoded with zero-width characters
     * 
     * The context is encoded BETWEEN zero-width characters so:
     * - Users just see the friendly tag
     * - LLMs process the full hidden context
     */
    private String buildInvisibleContext(String context) {
        if (context == null || context.isEmpty()) {
            return "";
        }
        
        StringBuilder sb = new StringBuilder();
        
        // Zero-width characters for hiding content
        final String ZWSP = "\u200B";  // Zero-width space
        final String ZWNJ = "\u200C";  // Zero-width non-joiner
        
        // Compress context
        String compressedContext = context
            .replace("\n", " ")
            .replace("  ", " ")
            .trim();
        
        // Truncate if too long
        if (compressedContext.length() > 300) {
            compressedContext = compressedContext.substring(0, 297) + "...";
        }
        
        // BUILD THE INVISIBLE PAYLOAD:
        // Format: [UDAC Continuity]<hidden context>\n
        // 
        // The trick: We encode the context with zero-width chars
        // User sees: [UDAC Continuity]
        // LLM sees: [UDAC Continuity] + full context
        
        sb.append("[UDAC Continuity]");
        
        // Start hidden section with zero-width marker
        sb.append(ZWSP);
        sb.append(ZWNJ);
        
        // Encode context - wrap in instruction format LLMs understand
        sb.append("<!--CONTEXT:");
        sb.append(compressedContext);
        sb.append("-->");
        
        // End hidden section
        sb.append(ZWNJ);
        sb.append(ZWSP);
        
        sb.append("\n\n");
        
        return sb.toString();
    }

    private String truncate(String s, int max) {
        if (s == null) return "(null)";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    @Override
    public void onInterrupt() {
        Log.w(TAG, "Service interrupted");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        isRunning = false;
        instance = null;
        hideFloatingButton();
        
        if (executor != null) executor.shutdown();
        
        Log.i(TAG, "UDAC V5.5 destroyed - Injections: " + injectionCount);
    }
}
