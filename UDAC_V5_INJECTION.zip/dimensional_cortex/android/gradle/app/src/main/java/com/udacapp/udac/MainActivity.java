package com.udacapp.udac;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.json.JSONObject;

/**
 * UDAC Main Activity V5
 * ======================
 * 
 * Native Android UI with injection controls:
 * - Injection ON/OFF toggle
 * - Invisible mode toggle
 * - Threshold slider
 * - Force injection button
 * - Service status indicators
 */
public class MainActivity extends Activity {

    private static final String TAG = "UDAC_Main";
    private static final String PREFS_NAME = "udac_prefs";
    private static final String SETTINGS_ENDPOINT = "http://127.0.0.1:7013/udac/settings";
    
    // Colors
    private static final int COLOR_BG = 0xFF0f0c29;
    private static final int COLOR_CARD = 0xFF1f1d2e;
    private static final int COLOR_ACCENT = 0xFF667eea;
    private static final int COLOR_TEXT = 0xFFe0e0e0;
    private static final int COLOR_TEXT_DIM = 0xFFa0a0a0;
    private static final int COLOR_SUCCESS = 0xFF10a37f;
    private static final int COLOR_WARNING = 0xFFf59e0b;
    private static final int COLOR_ERROR = 0xFFef4444;
    
    // UI Elements
    private TextView statusAccessibility;
    private TextView statusIME;
    private TextView statusBackend;
    private TextView statsCaptures;
    private TextView statsInjections;
    private TextView lastActivityText;
    
    private Switch switchInjection;
    private Switch switchInvisible;
    private SeekBar seekThreshold;
    private TextView thresholdValue;
    private Button btnForceInject;
    
    // State
    private SharedPreferences prefs;
    private Handler handler;
    private ExecutorService executor;
    private boolean isRunning = false;
    
    // Settings
    private boolean injectionEnabled = true;
    private boolean invisibleMode = true;
    private float injectionThreshold = 0.5f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        handler = new Handler(Looper.getMainLooper());
        executor = Executors.newSingleThreadExecutor();
        
        // Load saved settings
        loadSettings();
        
        // Build UI
        setContentView(buildUI());
        
        // Start status updates
        startStatusUpdates();
    }

    private void loadSettings() {
        injectionEnabled = prefs.getBoolean("injection_enabled", true);
        invisibleMode = prefs.getBoolean("invisible_mode", true);
        injectionThreshold = prefs.getFloat("threshold", 0.5f);
    }

    private void saveSettings() {
        prefs.edit()
            .putBoolean("injection_enabled", injectionEnabled)
            .putBoolean("invisible_mode", invisibleMode)
            .putFloat("threshold", injectionThreshold)
            .apply();
        
        // Sync to backend
        syncSettingsToBackend();
        
        // Update accessibility service if running
        UDACAccessibilityService service = UDACAccessibilityService.getInstance();
        if (service != null) {
            service.updateSettings(injectionEnabled, invisibleMode, injectionThreshold);
        }
    }

    private View buildUI() {
        // Root ScrollView
        ScrollView scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(COLOR_BG);
        scrollView.setFillViewport(true);
        
        // Main container
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        main.setPadding(dp(16), dp(16), dp(16), dp(16));
        
        // ════════════════════════════════════════════════════════════════
        // HEADER
        // ════════════════════════════════════════════════════════════════
        
        TextView title = new TextView(this);
        title.setText("⚡ UDAC V5");
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        title.setTextColor(COLOR_ACCENT);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        main.addView(title);
        
        TextView subtitle = new TextView(this);
        subtitle.setText("Universal AI Continuity with Injection");
        subtitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        subtitle.setTextColor(COLOR_TEXT_DIM);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 0, 0, dp(20));
        main.addView(subtitle);
        
        // ════════════════════════════════════════════════════════════════
        // STATUS CARD
        // ════════════════════════════════════════════════════════════════
        
        LinearLayout statusCard = createCard("Service Status");
        
        statusAccessibility = addStatusRow(statusCard, "Accessibility Service", "Checking...");
        statusIME = addStatusRow(statusCard, "Ghost Keyboard (IME)", "Checking...");
        statusBackend = addStatusRow(statusCard, "Python Backend", "Checking...");
        
        main.addView(statusCard);
        
        // ════════════════════════════════════════════════════════════════
        // INJECTION CONTROLS CARD
        // ════════════════════════════════════════════════════════════════
        
        LinearLayout controlsCard = createCard("Injection Controls");
        
        // Injection ON/OFF
        LinearLayout injectionRow = new LinearLayout(this);
        injectionRow.setOrientation(LinearLayout.HORIZONTAL);
        injectionRow.setPadding(0, dp(8), 0, dp(8));
        
        TextView injectionLabel = new TextView(this);
        injectionLabel.setText("Enable Injection");
        injectionLabel.setTextColor(COLOR_TEXT);
        injectionLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        injectionLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        injectionRow.addView(injectionLabel);
        
        switchInjection = new Switch(this);
        switchInjection.setChecked(injectionEnabled);
        switchInjection.setOnCheckedChangeListener((btn, checked) -> {
            injectionEnabled = checked;
            saveSettings();
            updateControlsUI();
            toast(checked ? "Injection enabled" : "Injection disabled");
        });
        injectionRow.addView(switchInjection);
        controlsCard.addView(injectionRow);
        
        // Invisible Mode
        LinearLayout invisibleRow = new LinearLayout(this);
        invisibleRow.setOrientation(LinearLayout.HORIZONTAL);
        invisibleRow.setPadding(0, dp(8), 0, dp(8));
        
        TextView invisibleLabel = new TextView(this);
        invisibleLabel.setText("Invisible Mode");
        invisibleLabel.setTextColor(COLOR_TEXT);
        invisibleLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        invisibleLabel.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        invisibleRow.addView(invisibleLabel);
        
        switchInvisible = new Switch(this);
        switchInvisible.setChecked(invisibleMode);
        switchInvisible.setOnCheckedChangeListener((btn, checked) -> {
            invisibleMode = checked;
            saveSettings();
            toast(checked ? "Context hidden from user" : "Context visible to user");
        });
        invisibleRow.addView(switchInvisible);
        controlsCard.addView(invisibleRow);
        
        TextView invisibleHint = new TextView(this);
        invisibleHint.setText("When ON, context is injected invisibly using HTML comments");
        invisibleHint.setTextColor(COLOR_TEXT_DIM);
        invisibleHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        invisibleHint.setPadding(0, 0, 0, dp(12));
        controlsCard.addView(invisibleHint);
        
        // Threshold Slider
        TextView thresholdLabel = new TextView(this);
        thresholdLabel.setText("Relevance Threshold");
        thresholdLabel.setTextColor(COLOR_TEXT);
        thresholdLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        thresholdLabel.setPadding(0, dp(8), 0, dp(4));
        controlsCard.addView(thresholdLabel);
        
        LinearLayout thresholdRow = new LinearLayout(this);
        thresholdRow.setOrientation(LinearLayout.HORIZONTAL);
        thresholdRow.setGravity(Gravity.CENTER_VERTICAL);
        
        seekThreshold = new SeekBar(this);
        seekThreshold.setMax(100);
        seekThreshold.setProgress((int)(injectionThreshold * 100));
        seekThreshold.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        seekThreshold.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                injectionThreshold = progress / 100f;
                thresholdValue.setText(String.format("%.0f%%", injectionThreshold * 100));
            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                saveSettings();
            }
        });
        thresholdRow.addView(seekThreshold);
        
        thresholdValue = new TextView(this);
        thresholdValue.setText(String.format("%.0f%%", injectionThreshold * 100));
        thresholdValue.setTextColor(COLOR_ACCENT);
        thresholdValue.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        thresholdValue.setTypeface(null, Typeface.BOLD);
        thresholdValue.setPadding(dp(12), 0, 0, 0);
        thresholdRow.addView(thresholdValue);
        
        controlsCard.addView(thresholdRow);
        
        TextView thresholdHint = new TextView(this);
        thresholdHint.setText("Lower = inject more often, Higher = only highly relevant context");
        thresholdHint.setTextColor(COLOR_TEXT_DIM);
        thresholdHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        thresholdHint.setPadding(0, dp(4), 0, dp(12));
        controlsCard.addView(thresholdHint);
        
        // Force Injection Button
        btnForceInject = new Button(this);
        btnForceInject.setText("🔧 FORCE NEXT INJECTION");
        btnForceInject.setTextColor(Color.WHITE);
        btnForceInject.setBackgroundColor(COLOR_WARNING);
        btnForceInject.setPadding(dp(16), dp(12), dp(16), dp(12));
        btnForceInject.setOnClickListener(v -> forceInjection());
        controlsCard.addView(btnForceInject);
        
        TextView forceHint = new TextView(this);
        forceHint.setText("For debugging: Next message will inject regardless of threshold");
        forceHint.setTextColor(COLOR_TEXT_DIM);
        forceHint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        forceHint.setPadding(0, dp(4), 0, 0);
        controlsCard.addView(forceHint);
        
        main.addView(controlsCard);
        
        // ════════════════════════════════════════════════════════════════
        // STATS CARD
        // ════════════════════════════════════════════════════════════════
        
        LinearLayout statsCard = createCard("Activity");
        
        statsCaptures = addStatusRow(statsCard, "Conversations Captured", "0");
        statsInjections = addStatusRow(statsCard, "Injections Performed", "0");
        
        TextView lastActivityLabel = new TextView(this);
        lastActivityLabel.setText("Last Activity:");
        lastActivityLabel.setTextColor(COLOR_TEXT_DIM);
        lastActivityLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        lastActivityLabel.setPadding(0, dp(12), 0, dp(4));
        statsCard.addView(lastActivityLabel);
        
        lastActivityText = new TextView(this);
        lastActivityText.setText("Waiting for activity...");
        lastActivityText.setTextColor(COLOR_TEXT);
        lastActivityText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        statsCard.addView(lastActivityText);
        
        main.addView(statsCard);
        
        // ════════════════════════════════════════════════════════════════
        // SETUP BUTTONS
        // ════════════════════════════════════════════════════════════════
        
        LinearLayout setupCard = createCard("Setup");
        
        Button btnAccessibility = createButton("Open Accessibility Settings", COLOR_ACCENT);
        btnAccessibility.setOnClickListener(v -> openAccessibilitySettings());
        setupCard.addView(btnAccessibility);
        
        Button btnKeyboard = createButton("Open Keyboard Settings", COLOR_ACCENT);
        btnKeyboard.setOnClickListener(v -> openKeyboardSettings());
        LinearLayout.LayoutParams kbParams = (LinearLayout.LayoutParams) btnKeyboard.getLayoutParams();
        if (kbParams == null) kbParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        kbParams.topMargin = dp(8);
        btnKeyboard.setLayoutParams(kbParams);
        setupCard.addView(btnKeyboard);
        
        Button btnSwitchIME = createButton("Show Keyboard Picker", 0xFF764ba2);
        btnSwitchIME.setOnClickListener(v -> showKeyboardPicker());
        LinearLayout.LayoutParams imeParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        imeParams.topMargin = dp(8);
        btnSwitchIME.setLayoutParams(imeParams);
        setupCard.addView(btnSwitchIME);
        
        main.addView(setupCard);
        
        // ════════════════════════════════════════════════════════════════
        // FOOTER
        // ════════════════════════════════════════════════════════════════
        
        TextView footer = new TextView(this);
        footer.setText("UDAC V5 • Dimensional Cortex\nCapture + Inject AI Continuity");
        footer.setTextColor(COLOR_TEXT_DIM);
        footer.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(20), 0, dp(20));
        main.addView(footer);
        
        scrollView.addView(main);
        return scrollView;
    }

    private LinearLayout createCard(String title) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(COLOR_CARD);
        bg.setCornerRadius(dp(12));
        card.setBackground(bg);
        
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        params.bottomMargin = dp(16);
        card.setLayoutParams(params);
        
        TextView titleView = new TextView(this);
        titleView.setText(title);
        titleView.setTextColor(COLOR_ACCENT);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        titleView.setTypeface(null, Typeface.BOLD);
        titleView.setPadding(0, 0, 0, dp(12));
        card.addView(titleView);
        
        return card;
    }

    private TextView addStatusRow(LinearLayout parent, String label, String initialValue) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(6), 0, dp(6));
        
        TextView labelView = new TextView(this);
        labelView.setText(label);
        labelView.setTextColor(COLOR_TEXT_DIM);
        labelView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        labelView.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        row.addView(labelView);
        
        TextView valueView = new TextView(this);
        valueView.setText(initialValue);
        valueView.setTextColor(COLOR_TEXT);
        valueView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        valueView.setTypeface(null, Typeface.BOLD);
        row.addView(valueView);
        
        parent.addView(row);
        return valueView;
    }

    private Button createButton(String text, int color) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextColor(Color.WHITE);
        btn.setAllCaps(false);
        
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(8));
        btn.setBackground(bg);
        
        btn.setPadding(dp(16), dp(14), dp(16), dp(14));
        
        return btn;
    }

    private void updateControlsUI() {
        boolean enabled = injectionEnabled;
        switchInvisible.setEnabled(enabled);
        seekThreshold.setEnabled(enabled);
        btnForceInject.setEnabled(enabled);
        
        float alpha = enabled ? 1.0f : 0.5f;
        switchInvisible.setAlpha(alpha);
        seekThreshold.setAlpha(alpha);
        btnForceInject.setAlpha(alpha);
    }

    private void startStatusUpdates() {
        isRunning = true;
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (!isRunning) return;
                updateStatus();
                handler.postDelayed(this, 2000);
            }
        });
    }

    private void updateStatus() {
        // Accessibility Service status
        boolean accessibilityEnabled = isAccessibilityServiceEnabled();
        statusAccessibility.setText(accessibilityEnabled ? "● RUNNING" : "○ DISABLED");
        statusAccessibility.setTextColor(accessibilityEnabled ? COLOR_SUCCESS : COLOR_ERROR);
        
        // IME status
        boolean imeEnabled = isIMEEnabled();
        statusIME.setText(imeEnabled ? "● ENABLED" : "○ DISABLED");
        statusIME.setTextColor(imeEnabled ? COLOR_SUCCESS : COLOR_WARNING);
        
        // Backend status (async check)
        checkBackendStatus();
    }

    private boolean isAccessibilityServiceEnabled() {
        String enabledServices = Settings.Secure.getString(
            getContentResolver(),
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        return enabledServices != null && enabledServices.contains(getPackageName());
    }

    private boolean isIMEEnabled() {
        String enabledIMEs = Settings.Secure.getString(
            getContentResolver(),
            Settings.Secure.ENABLED_INPUT_METHODS
        );
        return enabledIMEs != null && enabledIMEs.contains("UDACInputMethodService");
    }

    private void checkBackendStatus() {
        executor.execute(() -> {
            boolean connected = false;
            try {
                URL url = new URL(SETTINGS_ENDPOINT);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setConnectTimeout(1000);
                conn.setReadTimeout(1000);
                connected = conn.getResponseCode() == 200;
                conn.disconnect();
            } catch (Exception e) {
                // Not connected
            }
            
            final boolean isConnected = connected;
            handler.post(() -> {
                statusBackend.setText(isConnected ? "● CONNECTED" : "○ NOT RUNNING");
                statusBackend.setTextColor(isConnected ? COLOR_SUCCESS : COLOR_WARNING);
            });
        });
    }

    private void syncSettingsToBackend() {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                JSONObject settings = new JSONObject();
                settings.put("injection_enabled", injectionEnabled);
                settings.put("invisible_mode", invisibleMode);
                settings.put("threshold", injectionThreshold);
                
                URL url = new URL(SETTINGS_ENDPOINT);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);
                conn.setConnectTimeout(2000);
                
                try (OutputStream os = conn.getOutputStream()) {
                    os.write(settings.toString().getBytes(StandardCharsets.UTF_8));
                }
                
                conn.getResponseCode();
                Log.d(TAG, "Settings synced to backend");
                
            } catch (Exception e) {
                Log.w(TAG, "Failed to sync settings: " + e.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }

    private void forceInjection() {
        UDACAccessibilityService service = UDACAccessibilityService.getInstance();
        if (service != null) {
            service.forceInjection();
            toast("Force injection enabled for next message");
        } else {
            toast("Accessibility service not running");
        }
    }

    private void openAccessibilitySettings() {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        startActivity(intent);
    }

    private void openKeyboardSettings() {
        Intent intent = new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS);
        startActivity(intent);
    }

    private void showKeyboardPicker() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) {
            imm.showInputMethodPicker();
        }
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, value, getResources().getDisplayMetrics()
        );
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isRunning = false;
        if (executor != null) {
            executor.shutdown();
        }
    }
}
