"""
Dimensional Cortex - Production Release
========================================
Universal AI Continuity Engine

Features:
- Scrollable screens
- Settings with injection visibility toggle
- Threshold adjustment slider
- Platform collection toggles (all on by default)
- Working Android settings buttons
"""

import toga
from toga.style import Pack
from toga.style.pack import COLUMN, ROW, CENTER, LEFT, RIGHT, BOLD
import asyncio
import threading
import time
import logging
import json
import os

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("DimensionalCortex")

# ============================================================================
# SETTINGS STORAGE
# ============================================================================
class AppSettings:
    """Persistent settings manager"""
    
    DEFAULT_SETTINGS = {
        "show_injections": False,  # Toggle to see invisible injections
        "injection_threshold": 0.5,  # 0.0 to 1.0 - when to inject context
        "platforms": {
            "chatgpt": True,
            "claude": True,
            "perplexity": True,
            "gemini": True,
            "copilot": True,
        },
        "auto_inject": True,
        "capture_enabled": True,
    }
    
    def __init__(self):
        self.settings = self.DEFAULT_SETTINGS.copy()
        self.settings["platforms"] = self.DEFAULT_SETTINGS["platforms"].copy()
        self._load()
    
    def _get_settings_path(self):
        try:
            from platformdirs import user_data_dir
            app_dir = user_data_dir("Dimensional Cortex", "Sunni")
            os.makedirs(app_dir, exist_ok=True)
            return os.path.join(app_dir, "settings.json")
        except:
            return "settings.json"
    
    def _load(self):
        try:
            path = self._get_settings_path()
            if os.path.exists(path):
                with open(path, 'r') as f:
                    saved = json.load(f)
                    self.settings.update(saved)
                logger.info(f"Settings loaded from {path}")
        except Exception as e:
            logger.warning(f"Could not load settings: {e}")
    
    def save(self):
        try:
            path = self._get_settings_path()
            with open(path, 'w') as f:
                json.dump(self.settings, f, indent=2)
            logger.info("Settings saved")
        except Exception as e:
            logger.error(f"Could not save settings: {e}")
    
    def get(self, key, default=None):
        return self.settings.get(key, default)
    
    def set(self, key, value):
        self.settings[key] = value
        self.save()
    
    def is_platform_enabled(self, platform):
        return self.settings.get("platforms", {}).get(platform, True)
    
    def set_platform_enabled(self, platform, enabled):
        if "platforms" not in self.settings:
            self.settings["platforms"] = {}
        self.settings["platforms"][platform] = enabled
        self.save()

# Global settings instance
SETTINGS = AppSettings()

# ============================================================================
# ANDROID HELPERS
# ============================================================================
def open_accessibility_settings():
    """Open Android accessibility settings."""
    try:
        from jnius import autoclass
        Intent = autoclass('android.content.Intent')
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        intent = Intent("android.settings.ACCESSIBILITY_SETTINGS")
        PythonActivity.mActivity.startActivity(intent)
        return True
    except:
        try:
            from android.content import Intent
            from android import mActivity
            intent = Intent("android.settings.ACCESSIBILITY_SETTINGS")
            mActivity.startActivity(intent)
            return True
        except Exception as e:
            logger.error(f"Failed to open accessibility: {e}")
            return False

def open_keyboard_settings():
    """Open Android keyboard settings."""
    try:
        from jnius import autoclass
        Intent = autoclass('android.content.Intent')
        PythonActivity = autoclass('org.kivy.android.PythonActivity')
        intent = Intent("android.settings.INPUT_METHOD_SETTINGS")
        PythonActivity.mActivity.startActivity(intent)
        return True
    except:
        try:
            from android.content import Intent
            from android import mActivity
            intent = Intent("android.settings.INPUT_METHOD_SETTINGS")
            mActivity.startActivity(intent)
            return True
        except Exception as e:
            logger.error(f"Failed to open keyboard settings: {e}")
            return False

# ============================================================================
# TRINITY IMPORTS
# ============================================================================
try:
    from dimensional_cortex.dimensional_memory_constant_standalone_demo import (
        start_memory_system, stop_memory_system
    )
    from dimensional_cortex.dimensional_processing_system_standalone_demo import (
        CrystalMemorySystem, GovernanceEngine
    )
    from dimensional_cortex.dimensional_energy_regulator_mobile import DimensionalEnergyRegulator
    from dimensional_cortex.udac_listener import start_udac_listener, get_udac_stats
    TRINITY_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Trinity modules not available: {e}")
    TRINITY_AVAILABLE = False

# ============================================================================
# TRINITY MANAGER
# ============================================================================
class TrinityManager:
    def __init__(self):
        self.memory_governor = None
        self.memory_system = None
        self.crystal_system = None
        self.energy_regulator = None
        self.save_thread = None
        self.merge_thread = None
        self.running = False
        self._stop_event = threading.Event()
        self.start_time = None
        self.conversations_processed = 0
        self.injections_performed = 0
        self.last_capture = ""
        self.injection_history = []  # Track injections for visibility
        self.trade_credits = 0

    def start(self):
        if self.running:
            return True
        if not TRINITY_AVAILABLE:
            logger.error("Trinity modules not available!")
            return False

        logger.info("Starting Trinity system...")
        self._stop_event.clear()

        try:
            self.memory_governor, self.memory_system, self.save_thread, self.merge_thread = start_memory_system()
            governance = GovernanceEngine(data_theme="conversation")
            self.crystal_system = CrystalMemorySystem(governance_engine=governance)
            self.energy_regulator = DimensionalEnergyRegulator(conservation_limit=50.0, decay_rate=0.1)
            
            self.keepalive_thread = threading.Thread(target=self._keepalive_loop, daemon=True)
            self.keepalive_thread.start()
            
            self.running = True
            self.start_time = time.time()
            logger.info("Trinity system ONLINE")
            return True
        except Exception as e:
            logger.error(f"Start failed: {e}")
            return False

    def _keepalive_loop(self):
        while not self._stop_event.is_set():
            try:
                if self.running and self.energy_regulator:
                    self.energy_regulator.step(dt=1.0)
                if self.running and self.crystal_system:
                    self.crystal_system.decay_all()
            except Exception as e:
                logger.error(f"Keepalive error: {e}")
            for _ in range(10):
                if self._stop_event.is_set():
                    break
                time.sleep(1)

    def start_udac_listener(self):
        if not self.running:
            return
        try:
            start_udac_listener(port=7013)
            logger.info("UDAC listener on port 7013")
        except Exception as e:
            logger.error(f"UDAC listener failed: {e}")

    def stop(self):
        if not self.running:
            return
        self._stop_event.set()
        try:
            if self.save_thread and self.merge_thread:
                stop_memory_system(self.save_thread, self.merge_thread)
        except Exception as e:
            logger.error(f"Stop error: {e}")
        self.running = False

    def record_injection(self, platform, context_text):
        """Record an injection for history/visibility"""
        self.injections_performed += 1
        self.injection_history.append({
            "time": time.time(),
            "platform": platform,
            "text": context_text[:200],  # Truncate for storage
        })
        # Keep only last 50 injections
        if len(self.injection_history) > 50:
            self.injection_history.pop(0)

    def get_stats(self) -> dict:
        if not self.running:
            return {'memory_nodes': 0, 'crystals': 0, 'quasi_crystals': 0,
                    'conversations': 0, 'injections': 0, 'uptime': 0}
        uptime = int(time.time() - self.start_time) if self.start_time else 0
        memory_nodes = len(self.memory_system.nodes) if self.memory_system else 0
        crystal_stats = self.crystal_system.get_memory_stats() if self.crystal_system else {}
        crystals = crystal_stats.get('total_crystals', 0)
        quasi = crystal_stats.get('level_distribution', {}).get('QUASI', 0)
        return {
            'memory_nodes': memory_nodes, 'crystals': crystals, 'quasi_crystals': quasi,
            'conversations': self.conversations_processed, 'injections': self.injections_performed,
            'uptime': uptime, 'last_capture': self.last_capture,
        }

TRINITY = TrinityManager()

# ============================================================================
# MAIN APP
# ============================================================================
class DimensionalCortexApp(toga.App):
    
    def startup(self):
        self.main_window = toga.MainWindow(title=self.formal_name)
        self.on_exit = self.cleanup
        self.show_onboarding()
        self.main_window.show()

    def cleanup(self, app):
        TRINITY.stop()
        return True

    # ========================================================================
    # ONBOARDING SCREEN
    # ========================================================================
    def show_onboarding(self):
        outer = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#0d0d14'))
        scroll = toga.ScrollContainer(horizontal=False, style=Pack(flex=1))
        content = toga.Box(style=Pack(direction=COLUMN, padding=20, background_color='#0d0d14'))
        
        content.add(toga.Box(style=Pack(height=20, background_color='#0d0d14')))
        
        # Lightning icon
        icon_row = toga.Box(style=Pack(direction=ROW, background_color='#0d0d14'))
        icon_row.add(toga.Box(style=Pack(flex=1, background_color='#0d0d14')))
        icon_row.add(toga.Label('⚡', style=Pack(font_size=60, color='#f5a623')))
        icon_row.add(toga.Box(style=Pack(flex=1, background_color='#0d0d14')))
        content.add(icon_row)
        
        content.add(toga.Box(style=Pack(height=15, background_color='#0d0d14')))
        
        # Title
        title_row = toga.Box(style=Pack(direction=ROW, background_color='#0d0d14'))
        title_row.add(toga.Box(style=Pack(flex=1, background_color='#0d0d14')))
        title_row.add(toga.Label('DIMENSIONAL CORTEX', style=Pack(font_size=22, font_weight=BOLD, color='#ffffff')))
        title_row.add(toga.Box(style=Pack(flex=1, background_color='#0d0d14')))
        content.add(title_row)
        
        # Tagline
        tag_row = toga.Box(style=Pack(direction=ROW, background_color='#0d0d14'))
        tag_row.add(toga.Box(style=Pack(flex=1, background_color='#0d0d14')))
        tag_row.add(toga.Label('Universal AI Continuity Engine', style=Pack(font_size=14, color='#8888aa')))
        tag_row.add(toga.Box(style=Pack(flex=1, background_color='#0d0d14')))
        content.add(tag_row)
        
        content.add(toga.Box(style=Pack(height=25, background_color='#0d0d14')))
        
        # Features
        features_card = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#1a1a2e'))
        features = [
            ('🔄', 'Cross-platform memory', 'ChatGPT ↔ Claude ↔ Perplexity'),
            ('🧠', 'Dimensional processing', 'Concepts evolve and connect'),
            ('👻', 'Invisible injection', 'Context added seamlessly'),
            ('🔒', '100% local', 'Your data stays on device'),
        ]
        for emoji, title, desc in features:
            row = toga.Box(style=Pack(direction=ROW, padding=8, background_color='#1a1a2e'))
            row.add(toga.Label(emoji, style=Pack(font_size=22, padding_right=12, color='#ffffff')))
            col = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#1a1a2e'))
            col.add(toga.Label(title, style=Pack(font_weight=BOLD, color='#ffffff', font_size=14)))
            col.add(toga.Label(desc, style=Pack(color='#8888aa', font_size=12)))
            row.add(col)
            features_card.add(row)
        content.add(features_card)
        
        content.add(toga.Box(style=Pack(height=25, background_color='#0d0d14')))
        
        # Setup instructions
        content.add(toga.Label('Before starting, enable:', style=Pack(color='#aaaacc', font_size=13, padding_bottom=12)))
        
        acc_btn = toga.Button('① ENABLE ACCESSIBILITY SERVICE →', on_press=self.on_accessibility_click,
                              style=Pack(padding=14, background_color='#252545'))
        content.add(acc_btn)
        content.add(toga.Box(style=Pack(height=10, background_color='#0d0d14')))
        
        ime_btn = toga.Button('② ENABLE UDAC KEYBOARD →', on_press=self.on_keyboard_click,
                              style=Pack(padding=14, background_color='#252545'))
        content.add(ime_btn)
        content.add(toga.Box(style=Pack(height=8, background_color='#0d0d14')))
        
        self.setup_status = toga.Label('', style=Pack(color='#f5a623', font_size=12))
        content.add(self.setup_status)
        
        content.add(toga.Box(style=Pack(height=25, background_color='#0d0d14')))
        
        start_btn = toga.Button('START ENGINE', on_press=self.on_start_click,
                                style=Pack(padding=18, background_color='#6366f1'))
        content.add(start_btn)
        
        content.add(toga.Box(style=Pack(height=15, background_color='#0d0d14')))
        
        ver_row = toga.Box(style=Pack(direction=ROW, background_color='#0d0d14'))
        ver_row.add(toga.Box(style=Pack(flex=1, background_color='#0d0d14')))
        ver_row.add(toga.Label('v1.0.0 • Made with ⚡ by Sunni', style=Pack(color='#555577', font_size=11)))
        ver_row.add(toga.Box(style=Pack(flex=1, background_color='#0d0d14')))
        content.add(ver_row)
        
        content.add(toga.Box(style=Pack(height=30, background_color='#0d0d14')))
        
        scroll.content = content
        outer.add(scroll)
        self.main_window.content = outer

    # ========================================================================
    # DASHBOARD SCREEN
    # ========================================================================
    def show_dashboard(self):
        outer = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#0d0d14'))
        scroll = toga.ScrollContainer(horizontal=False, style=Pack(flex=1))
        content = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#0d0d14'))
        
        # Header
        header = toga.Box(style=Pack(direction=ROW, padding_bottom=15, background_color='#0d0d14'))
        header.add(toga.Label('⚡', style=Pack(font_size=28, padding_right=10, color='#f5a623')))
        header.add(toga.Label('Dimensional Cortex', style=Pack(font_size=20, font_weight=BOLD, color='#ffffff', flex=1)))
        self.status_label = toga.Label('● Online', style=Pack(color='#10b981', font_weight=BOLD, font_size=13))
        header.add(self.status_label)
        content.add(header)
        
        # Stats Row 1
        row1 = toga.Box(style=Pack(direction=ROW, padding_bottom=10, background_color='#0d0d14'))
        self.memories_value, mem_card = self._make_stat_card('MEMORIES', '0', 'nodes')
        self.crystals_value, cry_card = self._make_stat_card('CRYSTALS', '0', 'active')
        row1.add(mem_card)
        row1.add(toga.Box(style=Pack(width=10, background_color='#0d0d14')))
        row1.add(cry_card)
        content.add(row1)
        
        # Stats Row 2
        row2 = toga.Box(style=Pack(direction=ROW, padding_bottom=15, background_color='#0d0d14'))
        self.captured_value, cap_card = self._make_stat_card('CAPTURED', '0', 'convos')
        self.injected_value, inj_card = self._make_stat_card('INJECTED', '0', 'contexts')
        row2.add(cap_card)
        row2.add(toga.Box(style=Pack(width=10, background_color='#0d0d14')))
        row2.add(inj_card)
        content.add(row2)
        
        # Activity
        activity = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#1a1a2e'))
        act_head = toga.Box(style=Pack(direction=ROW, background_color='#1a1a2e'))
        act_head.add(toga.Label('Recent Activity', style=Pack(font_weight=BOLD, color='#ffffff', font_size=14, flex=1)))
        self.uptime_label = toga.Label('0m', style=Pack(color='#8888aa', font_size=12))
        act_head.add(self.uptime_label)
        activity.add(act_head)
        self.activity_text = toga.Label('Waiting for AI conversations...', style=Pack(color='#aaaacc', font_size=12, padding_top=8))
        activity.add(self.activity_text)
        content.add(activity)
        
        content.add(toga.Box(style=Pack(height=15, background_color='#0d0d14')))
        
        # Nav buttons
        nav1 = toga.Box(style=Pack(direction=ROW, padding_bottom=10, background_color='#0d0d14'))
        nav1.add(self._make_nav_btn('⚙️ Settings', self.show_settings))
        nav1.add(toga.Box(style=Pack(width=10, background_color='#0d0d14')))
        nav1.add(self._make_nav_btn('📜 History', self.show_history))
        content.add(nav1)
        
        nav2 = toga.Box(style=Pack(direction=ROW, padding_bottom=10, background_color='#0d0d14'))
        nav2.add(self._make_nav_btn('💎 Trade', self.show_trade))
        nav2.add(toga.Box(style=Pack(width=10, background_color='#0d0d14')))
        nav2.add(self._make_nav_btn('⚡ Upgrade', self.show_upgrade))
        content.add(nav2)
        
        test_btn = toga.Button('🧪 Run Test', on_press=self.run_test, style=Pack(padding=12, background_color='#252545'))
        content.add(test_btn)
        
        content.add(toga.Box(style=Pack(height=30, background_color='#0d0d14')))
        
        scroll.content = content
        outer.add(scroll)
        self.main_window.content = outer
        self.add_background_task(self.refresh_loop)

    def _make_stat_card(self, title, value, subtitle):
        card = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#1a1a2e', flex=1))
        card.add(toga.Label(title, style=Pack(color='#8888aa', font_size=10)))
        val_label = toga.Label(value, style=Pack(color='#ffffff', font_size=28, font_weight=BOLD, padding_top=5, padding_bottom=5))
        card.add(val_label)
        card.add(toga.Label(subtitle, style=Pack(color='#8888aa', font_size=10)))
        return val_label, card

    def _make_nav_btn(self, text, handler):
        return toga.Button(text, on_press=handler, style=Pack(flex=1, padding=14, background_color='#1a1a2e'))

    # ========================================================================
    # SETTINGS SCREEN - FULL FEATURED
    # ========================================================================
    def show_settings(self, widget=None):
        outer = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#0d0d14'))
        scroll = toga.ScrollContainer(horizontal=False, style=Pack(flex=1))
        content = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#0d0d14'))
        
        # Header
        header = toga.Box(style=Pack(direction=ROW, padding_bottom=20, background_color='#0d0d14'))
        back = toga.Button('← Back', on_press=lambda w: self.show_dashboard(), style=Pack(padding=10, background_color='#1a1a2e'))
        header.add(back)
        header.add(toga.Label('Settings', style=Pack(font_size=20, font_weight=BOLD, color='#ffffff', padding_left=15)))
        content.add(header)
        
        # ============ ANDROID SERVICES ============
        content.add(toga.Label('ANDROID SERVICES', style=Pack(color='#6366f1', font_weight=BOLD, font_size=12, padding_bottom=10)))
        
        acc_btn = toga.Button('Open Accessibility Settings', on_press=self.on_accessibility_click, 
                              style=Pack(padding=14, background_color='#1a1a2e'))
        content.add(acc_btn)
        content.add(toga.Box(style=Pack(height=8, background_color='#0d0d14')))
        
        ime_btn = toga.Button('Open Keyboard Settings', on_press=self.on_keyboard_click,
                              style=Pack(padding=14, background_color='#1a1a2e'))
        content.add(ime_btn)
        
        self.settings_status = toga.Label('', style=Pack(color='#f5a623', font_size=12, padding_top=5))
        content.add(self.settings_status)
        
        content.add(toga.Box(style=Pack(height=25, background_color='#0d0d14')))
        
        # ============ INJECTION SETTINGS ============
        content.add(toga.Label('INJECTION SETTINGS', style=Pack(color='#6366f1', font_weight=BOLD, font_size=12, padding_bottom=10)))
        
        # Show Injections Toggle
        inj_vis_row = toga.Box(style=Pack(direction=ROW, padding=12, background_color='#1a1a2e'))
        inj_vis_col = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#1a1a2e'))
        inj_vis_col.add(toga.Label('Show Invisible Injections', style=Pack(color='#ffffff', font_weight=BOLD, font_size=14)))
        inj_vis_col.add(toga.Label('Display injected context in history', style=Pack(color='#8888aa', font_size=11)))
        inj_vis_row.add(inj_vis_col)
        self.show_injections_switch = toga.Switch('', value=SETTINGS.get('show_injections', False),
                                                   on_change=self.on_show_injections_change,
                                                   style=Pack(padding_left=10))
        inj_vis_row.add(self.show_injections_switch)
        content.add(inj_vis_row)
        
        content.add(toga.Box(style=Pack(height=8, background_color='#0d0d14')))
        
        # Auto Inject Toggle
        auto_inj_row = toga.Box(style=Pack(direction=ROW, padding=12, background_color='#1a1a2e'))
        auto_inj_col = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#1a1a2e'))
        auto_inj_col.add(toga.Label('Auto-Inject Context', style=Pack(color='#ffffff', font_weight=BOLD, font_size=14)))
        auto_inj_col.add(toga.Label('Automatically inject relevant context', style=Pack(color='#8888aa', font_size=11)))
        auto_inj_row.add(auto_inj_col)
        self.auto_inject_switch = toga.Switch('', value=SETTINGS.get('auto_inject', True),
                                               on_change=self.on_auto_inject_change,
                                               style=Pack(padding_left=10))
        auto_inj_row.add(self.auto_inject_switch)
        content.add(auto_inj_row)
        
        content.add(toga.Box(style=Pack(height=15, background_color='#0d0d14')))
        
        # ============ THRESHOLD SETTINGS ============
        content.add(toga.Label('INJECTION THRESHOLD', style=Pack(color='#6366f1', font_weight=BOLD, font_size=12, padding_bottom=10)))
        
        threshold_card = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#1a1a2e'))
        threshold_card.add(toga.Label('Context Relevance Threshold', style=Pack(color='#ffffff', font_weight=BOLD, font_size=14)))
        threshold_card.add(toga.Label('Lower = more injections, Higher = only highly relevant', style=Pack(color='#8888aa', font_size=11, padding_bottom=10)))
        
        # Threshold value display
        current_threshold = SETTINGS.get('injection_threshold', 0.5)
        self.threshold_label = toga.Label(f'{int(current_threshold * 100)}%', 
                                          style=Pack(color='#6366f1', font_size=24, font_weight=BOLD))
        threshold_card.add(self.threshold_label)
        
        # Threshold slider
        self.threshold_slider = toga.Slider(min=0, max=100, value=int(current_threshold * 100),
                                            on_change=self.on_threshold_change,
                                            style=Pack(padding_top=10, flex=1))
        threshold_card.add(self.threshold_slider)
        
        # Threshold presets
        preset_row = toga.Box(style=Pack(direction=ROW, padding_top=10, background_color='#1a1a2e'))
        preset_row.add(toga.Button('Low (25%)', on_press=lambda w: self.set_threshold(25), 
                                   style=Pack(flex=1, padding=8, background_color='#252545')))
        preset_row.add(toga.Box(style=Pack(width=5, background_color='#1a1a2e')))
        preset_row.add(toga.Button('Med (50%)', on_press=lambda w: self.set_threshold(50),
                                   style=Pack(flex=1, padding=8, background_color='#252545')))
        preset_row.add(toga.Box(style=Pack(width=5, background_color='#1a1a2e')))
        preset_row.add(toga.Button('High (75%)', on_press=lambda w: self.set_threshold(75),
                                   style=Pack(flex=1, padding=8, background_color='#252545')))
        threshold_card.add(preset_row)
        
        content.add(threshold_card)
        
        content.add(toga.Box(style=Pack(height=25, background_color='#0d0d14')))
        
        # ============ PLATFORM TOGGLES ============
        content.add(toga.Label('PLATFORM COLLECTION', style=Pack(color='#6366f1', font_weight=BOLD, font_size=12, padding_bottom=10)))
        content.add(toga.Label('Toggle which AI platforms to capture from', style=Pack(color='#8888aa', font_size=11, padding_bottom=10)))
        
        platforms = [
            ('chatgpt', '🤖 ChatGPT', 'OpenAI'),
            ('claude', '🧠 Claude', 'Anthropic'),
            ('perplexity', '🔍 Perplexity', 'Perplexity AI'),
            ('gemini', '✨ Gemini', 'Google'),
            ('copilot', '💻 Copilot', 'Microsoft'),
        ]
        
        self.platform_switches = {}
        
        for platform_id, name, company in platforms:
            row = toga.Box(style=Pack(direction=ROW, padding=12, background_color='#1a1a2e'))
            col = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#1a1a2e'))
            col.add(toga.Label(name, style=Pack(color='#ffffff', font_weight=BOLD, font_size=14)))
            col.add(toga.Label(company, style=Pack(color='#8888aa', font_size=11)))
            row.add(col)
            
            switch = toga.Switch('', value=SETTINGS.is_platform_enabled(platform_id),
                                 on_change=lambda w, pid=platform_id: self.on_platform_toggle(pid, w.value),
                                 style=Pack(padding_left=10))
            self.platform_switches[platform_id] = switch
            row.add(switch)
            content.add(row)
            content.add(toga.Box(style=Pack(height=5, background_color='#0d0d14')))
        
        # All On/Off buttons
        content.add(toga.Box(style=Pack(height=10, background_color='#0d0d14')))
        all_row = toga.Box(style=Pack(direction=ROW, background_color='#0d0d14'))
        all_row.add(toga.Button('Enable All', on_press=self.enable_all_platforms,
                                style=Pack(flex=1, padding=12, background_color='#10b981')))
        all_row.add(toga.Box(style=Pack(width=10, background_color='#0d0d14')))
        all_row.add(toga.Button('Disable All', on_press=self.disable_all_platforms,
                                style=Pack(flex=1, padding=12, background_color='#ef4444')))
        content.add(all_row)
        
        content.add(toga.Box(style=Pack(height=50, background_color='#0d0d14')))
        
        scroll.content = content
        outer.add(scroll)
        self.main_window.content = outer

    def on_show_injections_change(self, widget):
        SETTINGS.set('show_injections', widget.value)
        logger.info(f"Show injections: {widget.value}")

    def on_auto_inject_change(self, widget):
        SETTINGS.set('auto_inject', widget.value)
        logger.info(f"Auto inject: {widget.value}")

    def on_threshold_change(self, widget):
        value = int(widget.value)
        self.threshold_label.text = f'{value}%'
        SETTINGS.set('injection_threshold', value / 100.0)

    def set_threshold(self, value):
        self.threshold_slider.value = value
        self.threshold_label.text = f'{value}%'
        SETTINGS.set('injection_threshold', value / 100.0)

    def on_platform_toggle(self, platform_id, enabled):
        SETTINGS.set_platform_enabled(platform_id, enabled)
        logger.info(f"Platform {platform_id}: {enabled}")

    def enable_all_platforms(self, widget):
        for pid, switch in self.platform_switches.items():
            switch.value = True
            SETTINGS.set_platform_enabled(pid, True)

    def disable_all_platforms(self, widget):
        for pid, switch in self.platform_switches.items():
            switch.value = False
            SETTINGS.set_platform_enabled(pid, False)

    # ========================================================================
    # HISTORY SCREEN
    # ========================================================================
    def show_history(self, widget=None):
        outer = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#0d0d14'))
        scroll = toga.ScrollContainer(horizontal=False, style=Pack(flex=1))
        content = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#0d0d14'))
        
        header = toga.Box(style=Pack(direction=ROW, padding_bottom=20, background_color='#0d0d14'))
        back = toga.Button('← Back', on_press=lambda w: self.show_dashboard(), style=Pack(padding=10, background_color='#1a1a2e'))
        header.add(back)
        header.add(toga.Label('Injection History', style=Pack(font_size=20, font_weight=BOLD, color='#ffffff', padding_left=15)))
        content.add(header)
        
        # Check if show injections is enabled
        if not SETTINGS.get('show_injections', False):
            notice = toga.Box(style=Pack(direction=COLUMN, padding=20, background_color='#1a1a2e'))
            notice.add(toga.Label('👻 Invisible Mode Active', style=Pack(color='#ffffff', font_weight=BOLD, font_size=16, padding_bottom=10)))
            notice.add(toga.Label('Injections are hidden.\nEnable "Show Invisible Injections" in Settings to view.', 
                                  style=Pack(color='#8888aa', font_size=13)))
            notice.add(toga.Box(style=Pack(height=15, background_color='#1a1a2e')))
            notice.add(toga.Button('Go to Settings', on_press=self.show_settings, 
                                   style=Pack(padding=12, background_color='#6366f1')))
            content.add(notice)
        elif len(TRINITY.injection_history) == 0:
            content.add(toga.Label('No injections yet.\n\nUse an AI chat app to see history.', 
                                   style=Pack(color='#8888aa', font_size=14, padding=20)))
        else:
            # Show injection history
            for inj in reversed(TRINITY.injection_history[-20:]):
                card = toga.Box(style=Pack(direction=COLUMN, padding=12, background_color='#1a1a2e'))
                
                head_row = toga.Box(style=Pack(direction=ROW, background_color='#1a1a2e'))
                head_row.add(toga.Label(inj['platform'], style=Pack(color='#6366f1', font_weight=BOLD, flex=1)))
                
                # Format time
                elapsed = int(time.time() - inj['time'])
                if elapsed < 60:
                    time_str = f'{elapsed}s ago'
                elif elapsed < 3600:
                    time_str = f'{elapsed // 60}m ago'
                else:
                    time_str = f'{elapsed // 3600}h ago'
                head_row.add(toga.Label(time_str, style=Pack(color='#8888aa', font_size=11)))
                card.add(head_row)
                
                card.add(toga.Label(inj['text'][:100] + '...' if len(inj['text']) > 100 else inj['text'],
                                    style=Pack(color='#aaaacc', font_size=12, padding_top=5)))
                content.add(card)
                content.add(toga.Box(style=Pack(height=8, background_color='#0d0d14')))
        
        content.add(toga.Box(style=Pack(height=30, background_color='#0d0d14')))
        
        scroll.content = content
        outer.add(scroll)
        self.main_window.content = outer

    # ========================================================================
    # TRADE SCREEN
    # ========================================================================
    def show_trade(self, widget=None):
        outer = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#0d0d14'))
        scroll = toga.ScrollContainer(horizontal=False, style=Pack(flex=1))
        content = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#0d0d14'))
        
        header = toga.Box(style=Pack(direction=ROW, padding_bottom=20, background_color='#0d0d14'))
        back = toga.Button('← Back', on_press=lambda w: self.show_dashboard(), style=Pack(padding=10, background_color='#1a1a2e'))
        header.add(back)
        header.add(toga.Label('💎 Memory Trade', style=Pack(font_size=20, font_weight=BOLD, color='#ffffff', padding_left=15)))
        content.add(header)
        
        info = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#1a1a2e'))
        info.add(toga.Label('How it works', style=Pack(font_weight=BOLD, color='#ffffff', padding_bottom=10)))
        info.add(toga.Label('Trade anonymized patterns for credits.\n\n• Patterns stripped of identifiers\n• Only dimensional signatures\n• 100 patterns = 500 credits', 
                            style=Pack(color='#aaaacc', font_size=12)))
        content.add(info)
        
        content.add(toga.Box(style=Pack(height=20, background_color='#0d0d14')))
        
        trade_btn = toga.Button('EXPORT & GAIN CREDITS', on_press=self.do_trade, style=Pack(padding=16, background_color='#6366f1'))
        content.add(trade_btn)
        
        self.trade_status = toga.Label(f'Credits: {TRINITY.trade_credits}', style=Pack(color='#8888aa', padding_top=10))
        content.add(self.trade_status)
        
        content.add(toga.Box(style=Pack(height=30, background_color='#0d0d14')))
        
        scroll.content = content
        outer.add(scroll)
        self.main_window.content = outer

    def do_trade(self, widget):
        TRINITY.trade_credits += 500
        self.trade_status.text = f'✅ +500 credits! Total: {TRINITY.trade_credits}'
        self.trade_status.style.color = '#10b981'

    # ========================================================================
    # UPGRADE SCREEN
    # ========================================================================
    def show_upgrade(self, widget=None):
        outer = toga.Box(style=Pack(direction=COLUMN, flex=1, background_color='#0d0d14'))
        scroll = toga.ScrollContainer(horizontal=False, style=Pack(flex=1))
        content = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#0d0d14'))
        
        header = toga.Box(style=Pack(direction=ROW, padding_bottom=20, background_color='#0d0d14'))
        back = toga.Button('← Back', on_press=lambda w: self.show_dashboard(), style=Pack(padding=10, background_color='#1a1a2e'))
        header.add(back)
        header.add(toga.Label('⚡ Upgrade', style=Pack(font_size=20, font_weight=BOLD, color='#ffffff', padding_left=15)))
        content.add(header)
        
        tiers = [
            ('FREE', '$0', ['1,000 conversations', '100 crystals', 'Single platform'], True),
            ('PRO', '$9.99/mo', ['10,000 conversations', '1,000 crystals', 'All platforms'], False),
            ('LIFETIME', '$299', ['Everything in Pro', 'Lifetime updates', 'Founding badge'], False),
        ]
        
        for name, price, features, current in tiers:
            card = toga.Box(style=Pack(direction=COLUMN, padding=15, background_color='#252545' if current else '#1a1a2e'))
            row = toga.Box(style=Pack(direction=ROW, background_color='#252545' if current else '#1a1a2e'))
            row.add(toga.Label(name, style=Pack(font_weight=BOLD, font_size=16, color='#6366f1' if current else '#ffffff', flex=1)))
            row.add(toga.Label(price, style=Pack(color='#ffffff', font_weight=BOLD)))
            card.add(row)
            for f in features:
                card.add(toga.Label(f'✓ {f}', style=Pack(color='#aaaacc', font_size=12, padding=3)))
            btn_text = 'CURRENT' if current else f'GET {name}'
            card.add(toga.Button(btn_text, enabled=not current, style=Pack(padding=10, padding_top=12, background_color='#6366f1' if not current else '#333355')))
            content.add(card)
            content.add(toga.Box(style=Pack(height=10, background_color='#0d0d14')))
        
        content.add(toga.Box(style=Pack(height=30, background_color='#0d0d14')))
        
        scroll.content = content
        outer.add(scroll)
        self.main_window.content = outer

    # ========================================================================
    # HANDLERS
    # ========================================================================
    def on_accessibility_click(self, widget):
        success = open_accessibility_settings()
        status_label = getattr(self, 'setup_status', None) or getattr(self, 'settings_status', None)
        if status_label:
            if success:
                status_label.text = '✓ Opening settings...'
                status_label.style.color = '#10b981'
            else:
                status_label.text = 'Manual: Settings → Accessibility → UDAC Continuity'
                status_label.style.color = '#f5a623'

    def on_keyboard_click(self, widget):
        success = open_keyboard_settings()
        status_label = getattr(self, 'setup_status', None) or getattr(self, 'settings_status', None)
        if status_label:
            if success:
                status_label.text = '✓ Opening settings...'
                status_label.style.color = '#10b981'
            else:
                status_label.text = 'Manual: Settings → Language & Input → Keyboards'
                status_label.style.color = '#f5a623'

    def on_start_click(self, widget):
        success = TRINITY.start()
        if success:
            TRINITY.start_udac_listener()
            self.show_dashboard()
        else:
            if hasattr(self, 'setup_status'):
                self.setup_status.text = 'Failed to start - check logs'
                self.setup_status.style.color = '#ff6b6b'

    def run_test(self, widget):
        TRINITY.conversations_processed += 1
        TRINITY.last_capture = "Test capture successful!"
        TRINITY.record_injection("Test", "Sample injected context for testing purposes")
        if hasattr(self, 'activity_text'):
            self.activity_text.text = TRINITY.last_capture

    async def refresh_loop(self, app):
        while TRINITY.running:
            try:
                stats = TRINITY.get_stats()
                if hasattr(self, 'memories_value'):
                    self.memories_value.text = str(stats['memory_nodes'])
                if hasattr(self, 'crystals_value'):
                    self.crystals_value.text = str(stats['crystals'])
                if hasattr(self, 'captured_value'):
                    self.captured_value.text = str(stats['conversations'])
                if hasattr(self, 'injected_value'):
                    self.injected_value.text = str(stats['injections'])
                if hasattr(self, 'uptime_label'):
                    u = stats['uptime']
                    self.uptime_label.text = f'{u}s' if u < 60 else f'{u//60}m'
                if hasattr(self, 'activity_text') and stats['last_capture']:
                    self.activity_text.text = stats['last_capture'][:60]
            except Exception as e:
                logger.error(f"Refresh error: {e}")
            await asyncio.sleep(2)


def main():
    return DimensionalCortexApp('Dimensional Cortex', 'com.dimensionalcortex.dimensional_cortex')

if __name__ == '__main__':
    main().main_loop()
